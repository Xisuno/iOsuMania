import UIKit

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        Paths.prepare()
        Library.ensureDemo()
        let w = UIWindow(frame: UIScreen.main.bounds)
        Theme.install(on: w)
        let nav = UINavigationController(rootViewController: MainMenuViewController())
        nav.navigationBar.prefersLargeTitles = false
        w.rootViewController = nav
        w.makeKeyAndVisible()
        window = w
        return true
    }

    func application(_ application: UIApplication,
                     supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
        .landscape
    }

    // Abrir .osz/.osk pelo "Abrir com…" / Compartilhar
    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey: Any] = [:]) -> Bool {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        let msg = Library.importAny(url)
        let a = UIAlertController(title: "Importação", message: msg, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "OK", style: .default))
        window?.rootViewController?.present(a, animated: true)
        return true
    }
}
