import UIKit
import AVFoundation

final class GameViewController: UIViewController {
    private let map: Beatmap
    private let mods: Mods
    private let engine: GameEngine
    private let skin: Skin
    private var gameView: GameView!
    private var player: AVAudioPlayer?
    private var bank: HitsoundBank?
    private var haptic: UIImpactFeedbackGenerator?
    private var hapticsOn = false
    private var link: CADisplayLink?

    // diagnóstico (FPS)
    private var showFPS = false
    private var fpsLast = 0.0
    private var fpsFrames = 0
    private var fpsWorst = 0.0
    private var fpsPrevTS = 0.0

    private let leadIn = 2000.0
    private var startUptime = 0.0     // uptime em que o tempo de jogo == 0
    private var paused = false
    private var pausedAt = 0.0
    private var finishing = false

    // interface
    private let skipButton = PillButton(title: "Pular intro  ▸▸", color: Theme.pink, fontSize: 15)
    private let countdownLabel = UILabel()
    private let introLabel = UILabel()
    private var pauseOverlay: PauseOverlay?
    private var skipVisible = false
    private var countdownToken = 0

    private var rate: Double { mods.rate }
    private var offsetMs: Double { Settings.shared.audioOffset }

    init(map: Beatmap, mods: Mods) {
        self.map = map
        self.mods = mods
        self.engine = GameEngine(map: map, mods: mods)
        self.skin = Skin.loadActive()
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .fullScreen
    }
    required init?(coder: NSCoder) { fatalError() }

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }

    // MARK: Relógio

    private func time(at uptime: TimeInterval) -> Double {
        (uptime - startUptime) * 1000 * rate - offsetMs
    }
    private func currentTime() -> Double {
        if paused { return time(at: pausedAt) }
        return time(at: ProcessInfo.processInfo.systemUptime)
    }

    // MARK: Ciclo de vida

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        skin.preload(keys: map.keys)
        gameView = GameView(skin: skin, keys: map.keys)
        gameView.translatesAutoresizingMaskIntoConstraints = false
        gameView.engine = engine
        gameView.mods = mods
        gameView.scrollSpeed = Settings.shared.scrollSpeed
        gameView.nowProvider = { [weak self] in self?.currentTime() ?? 0 }
        hapticsOn = Settings.shared.haptics
        if hapticsOn {
            haptic = UIImpactFeedbackGenerator(style: .light)
            haptic?.prepare()
        }
        gameView.onPress = { [weak self] c, ts in
            guard let self = self, !self.paused else { return }
            if self.hapticsOn { self.haptic?.impactOccurred() }
            self.engine.press(c, now: self.time(at: ts))
        }
        gameView.onRelease = { [weak self] c, ts in
            guard let self = self, !self.paused else { return }
            self.engine.release(c, now: self.time(at: ts))
        }
        engine.onHit = { [weak self] note in self?.bank?.play(note.sample) }

        // fundo carregado fora da thread principal
        let useMapBG = Settings.shared.useBeatmapBG
        var bgURL: URL? = nil
        if useMapBG, let u = map.backgroundURL, FileManager.default.fileExists(atPath: u.path) { bgURL = u }
        else if FileManager.default.fileExists(atPath: Paths.background.path) { bgURL = Paths.background }
        if let u = bgURL {
            ImageLoader.load(u, maxSide: 2000) { [weak self] img in self?.gameView.bgImage = img }
        }

        view.addSubview(gameView)
        NSLayoutConstraint.activate([
            gameView.topAnchor.constraint(equalTo: view.topAnchor),
            gameView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            gameView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            gameView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])
        buildOverlayUI()

        NotificationCenter.default.addObserver(self, selector: #selector(appWillResign),
                                               name: UIApplication.willResignActiveNotification, object: nil)
        startSong()
    }

    private func buildOverlayUI() {
        let pauseBtn = UIButton(type: .system)
        pauseBtn.setTitle("  II  ", for: .normal)
        pauseBtn.titleLabel?.font = .boldSystemFont(ofSize: 18)
        pauseBtn.tintColor = UIColor.white.withAlphaComponent(0.8)
        pauseBtn.translatesAutoresizingMaskIntoConstraints = false
        pauseBtn.addTarget(self, action: #selector(pauseTapped), for: .touchUpInside)
        view.addSubview(pauseBtn)

        skipButton.isHidden = true
        skipButton.addTarget(self, action: #selector(skipTapped), for: .touchUpInside)
        view.addSubview(skipButton)

        countdownLabel.font = .systemFont(ofSize: 96, weight: .heavy)
        countdownLabel.textColor = .white
        countdownLabel.shadowColor = UIColor.black.withAlphaComponent(0.6)
        countdownLabel.shadowOffset = CGSize(width: 0, height: 2)
        countdownLabel.textAlignment = .center
        countdownLabel.isHidden = true
        countdownLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(countdownLabel)

        introLabel.numberOfLines = 2
        introLabel.textAlignment = .center
        introLabel.textColor = .white
        introLabel.shadowColor = UIColor.black.withAlphaComponent(0.7)
        introLabel.shadowOffset = CGSize(width: 0, height: 1)
        introLabel.font = .systemFont(ofSize: 16, weight: .semibold)
        introLabel.text = "\(map.artist) – \(map.title)\n[\(map.version)]  ·  \(map.keys)K"
        introLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(introLabel)

        NSLayoutConstraint.activate([
            pauseBtn.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 6),
            pauseBtn.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 6),
            pauseBtn.widthAnchor.constraint(equalToConstant: 52),
            pauseBtn.heightAnchor.constraint(equalToConstant: 40),
            skipButton.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -16),
            skipButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16),
            countdownLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            countdownLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            introLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            introLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 18),
            introLabel.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, constant: -160),
        ])
        // some depois de uns segundos
        UIView.animate(withDuration: 0.6, delay: 3.2, options: [], animations: { self.introLabel.alpha = 0 })
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        UIApplication.shared.isIdleTimerDisabled = true
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        UIApplication.shared.isIdleTimerDisabled = false
    }
    deinit {
        link?.invalidate()
        bank?.stop()
        NotificationCenter.default.removeObserver(self)
    }

    private func startSong() {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback)
        try? session.setPreferredIOBufferDuration(0.005)   // menor latência para os hitsounds
        try? session.setActive(true)

        // hitsounds: carrega tudo antes da música começar
        let b = HitsoundBank(beatmapDir: map.dir, skinDir: skin.dir)
        b.preload(map.objects)
        b.start()
        bank = b

        let s = Settings.shared
        player = try? AVAudioPlayer(contentsOf: map.audioURL)
        player?.enableRate = true
        player?.rate = Float(rate)
        player?.volume = Float(s.masterVolume * s.musicVolume / 10000.0)
        player?.prepareToPlay()
        let delay = leadIn / 1000 / rate
        startUptime = ProcessInfo.processInfo.systemUptime + delay
        if let p = player { _ = p.play(atTime: p.deviceCurrentTime + delay) }

        showFPS = s.showFPS
        let l = CADisplayLink(target: self, selector: #selector(tick(_:)))
        if s.fps120 {
            l.preferredFrameRateRange = CAFrameRateRange(minimum: 60, maximum: 120, preferred: 120)
        } else {
            l.preferredFrameRateRange = CAFrameRateRange(minimum: 60, maximum: 60, preferred: 60)
        }
        l.add(to: .main, forMode: .common)
        link = l
    }

    private func trackFPS(_ ts: CFTimeInterval) {
        if fpsPrevTS > 0 { fpsWorst = max(fpsWorst, ts - fpsPrevTS) }
        fpsPrevTS = ts
        fpsFrames += 1
        if fpsLast == 0 { fpsLast = ts }
        if ts - fpsLast >= 0.5 {
            let fps = Double(fpsFrames) / (ts - fpsLast)
            gameView.setFPS(String(format: "%.0f fps · pior frame %.0f ms", fps, fpsWorst * 1000))
            fpsFrames = 0
            fpsWorst = 0
            fpsLast = ts
        }
    }

    @objc private func tick(_ l: CADisplayLink) {
        if paused || finishing { return }
        if showFPS { trackFPS(l.timestamp) }
        let now = currentTime()
        engine.update(now: now)
        gameView.frameUpdate()

        // botão "Pular intro": só quando falta bastante para a primeira nota
        let canSkip = now > 200 && engine.firstTime - now > 4000
        if canSkip != skipVisible {
            skipVisible = canSkip
            skipButton.isHidden = !canSkip
        }
        if engine.isFinished(now) { finish() }
    }

    // MARK: Pular intro

    @objc private func skipTapped() {
        let now = currentTime()
        let target = engine.firstTime - 2000
        guard target > now, let p = player else { return }
        p.currentTime = (target + offsetMs) / 1000
        startUptime = ProcessInfo.processInfo.systemUptime - (target + offsetMs) / (1000 * rate)
        skipVisible = false
        skipButton.isHidden = true
    }

    // MARK: Pausa

    @objc private func appWillResign() {
        if paused {
            // app saiu durante a contagem: volta ao menu de pausa
            if pauseOverlay == nil && !finishing {
                countdownToken += 1
                countdownLabel.isHidden = true
                showPauseOverlay()
            }
        } else {
            pauseTapped()
        }
    }

    @objc private func pauseTapped() {
        guard !paused, !finishing, currentTime() > 0 else { return }
        gameView.releaseAllTouches()
        paused = true
        pausedAt = ProcessInfo.processInfo.systemUptime
        player?.pause()
        link?.isPaused = true
        showPauseOverlay()
    }

    private func showPauseOverlay() {
        let o = PauseOverlay(speed: Settings.shared.scrollSpeed)
        o.onResume = { [weak self] in self?.requestResume() }
        o.onRestart = { [weak self] in self?.restart() }
        o.onQuit = { [weak self] in self?.quit() }
        o.onSpeedChange = { [weak self] delta in
            let v = max(1, min(40, Settings.shared.scrollSpeed + delta))
            Settings.shared.scrollSpeed = v
            self?.gameView.scrollSpeed = v
            return v
        }
        view.addSubview(o)
        NSLayoutConstraint.activate([
            o.topAnchor.constraint(equalTo: view.topAnchor),
            o.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            o.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            o.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])
        pauseOverlay = o
    }

    private func requestResume() {
        pauseOverlay?.removeFromSuperview()
        pauseOverlay = nil
        if Settings.shared.resumeCountdown {
            countdownToken += 1
            countdownStep(3, token: countdownToken)
        } else {
            resume()
        }
    }

    private func countdownStep(_ n: Int, token: Int) {
        guard token == countdownToken, paused else { return }
        if n == 0 {
            countdownLabel.isHidden = true
            resume()
            return
        }
        countdownLabel.text = "\(n)"
        countdownLabel.isHidden = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) { [weak self] in
            self?.countdownStep(n - 1, token: token)
        }
    }

    private func resume() {
        startUptime += ProcessInfo.processInfo.systemUptime - pausedAt
        paused = false
        fpsPrevTS = 0
        player?.play()
        link?.isPaused = false
    }

    private func stopAll() {
        link?.invalidate()
        link = nil
        player?.stop()
        bank?.stop()
        gameView.releaseAllTouches()
    }

    private func restart() {
        stopAll()
        let presenter = presentingViewController
        let vc = GameViewController(map: map, mods: mods)
        presenter?.dismiss(animated: false) { presenter?.present(vc, animated: false) }
    }

    private func quit() {
        stopAll()
        closeToSongList()
    }

    /// Fecha esta tela (e qualquer coisa por cima, como os resultados) voltando à lista de músicas.
    private func closeToSongList() {
        if let p = presentingViewController {
            p.dismiss(animated: true)
        } else {
            dismiss(animated: true)
        }
    }

    // MARK: Fim

    private func finish() {
        finishing = true
        stopAll()
        let r = ResultsViewController(engine: engine, map: map, mods: mods)
        r.onRetry = { [weak self] in
            guard let self = self else { return }
            let presenter = self.presentingViewController
            let vc = GameViewController(map: self.map, mods: self.mods)
            presenter?.dismiss(animated: false) { presenter?.present(vc, animated: false) }
        }
        r.onClose = { [weak self] in self?.closeToSongList() }
        present(r, animated: true)
    }
}

// MARK: - Menu de pausa (estilo osu!)

final class PauseOverlay: UIView {
    var onResume: (() -> Void)?
    var onRestart: (() -> Void)?
    var onQuit: (() -> Void)?
    /// recebe a variação (+1/-1) e devolve a velocidade final
    var onSpeedChange: ((Double) -> Double)?
    private let speedLabel = UILabel()

    init(speed: Double) {
        super.init(frame: .zero)
        translatesAutoresizingMaskIntoConstraints = false
        backgroundColor = UIColor.black.withAlphaComponent(0.78)

        let title = UILabel()
        title.text = "PAUSADO"
        title.font = .systemFont(ofSize: 30, weight: .heavy)
        title.textColor = .white
        title.textAlignment = .center

        let resume = PillButton(title: "Continuar", color: Theme.pink, fontSize: 20)
        let restart = PillButton(title: "Reiniciar", color: Theme.blue, fontSize: 18)
        let quit = PillButton(title: "Sair", color: UIColor(white: 0.25, alpha: 1), fontSize: 18)
        resume.addAction(UIAction { [weak self] _ in self?.onResume?() }, for: .touchUpInside)
        restart.addAction(UIAction { [weak self] _ in self?.onRestart?() }, for: .touchUpInside)
        quit.addAction(UIAction { [weak self] _ in self?.onQuit?() }, for: .touchUpInside)

        let minus = PillButton(title: "−", color: UIColor(white: 1, alpha: 0.15), fontSize: 20)
        let plus = PillButton(title: "+", color: UIColor(white: 1, alpha: 0.15), fontSize: 20)
        speedLabel.textColor = .white
        speedLabel.font = .monospacedDigitSystemFont(ofSize: 16, weight: .semibold)
        speedLabel.textAlignment = .center
        setSpeedText(speed)
        minus.addAction(UIAction { [weak self] _ in self?.changeSpeed(-1) }, for: .touchUpInside)
        plus.addAction(UIAction { [weak self] _ in self?.changeSpeed(1) }, for: .touchUpInside)
        let speedRow = UIStackView(arrangedSubviews: [minus, speedLabel, plus])
        speedRow.axis = .horizontal
        speedRow.spacing = 10
        speedRow.alignment = .center
        minus.widthAnchor.constraint(equalToConstant: 56).isActive = true
        plus.widthAnchor.constraint(equalToConstant: 56).isActive = true

        let stack = UIStackView(arrangedSubviews: [title, resume, restart, quit, speedRow])
        stack.axis = .vertical
        stack.spacing = 12
        stack.setCustomSpacing(18, after: title)
        stack.setCustomSpacing(20, after: quit)
        stack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stack)
        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: centerYAnchor),
            stack.widthAnchor.constraint(equalToConstant: 300),
        ])
    }
    required init?(coder: NSCoder) { fatalError() }

    private func setSpeedText(_ v: Double) {
        speedLabel.text = "Velocidade de rolagem: \(Int(v))"
    }

    private func changeSpeed(_ d: Double) {
        if let v = onSpeedChange?(d) { setSpeedText(v) }
    }
}

extension NSLayoutConstraint {
    func withPriority(_ p: UILayoutPriority) -> NSLayoutConstraint {
        priority = p
        return self
    }
}
