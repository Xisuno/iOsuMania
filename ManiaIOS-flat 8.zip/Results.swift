import UIKit

/// Tela de resultados no estilo do osu!: rank grande à esquerda, painel com pontuação à direita.
final class ResultsViewController: UIViewController {
    private let engine: GameEngine
    private let map: Beatmap
    private let mods: Mods
    var onRetry: (() -> Void)?
    var onClose: (() -> Void)?

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }
    override var prefersStatusBarHidden: Bool { true }

    init(engine: GameEngine, map: Beatmap, mods: Mods) {
        self.engine = engine
        self.map = map
        self.mods = mods
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .fullScreen
    }
    required init?(coder: NSCoder) { fatalError() }

    // MARK: Pequenos construtores

    private func makeLabel(_ text: String, size: CGFloat, weight: UIFont.Weight, color: UIColor = .white,
                           align: NSTextAlignment = .center) -> UILabel {
        let l = UILabel()
        l.text = text
        l.font = .monospacedDigitSystemFont(ofSize: size, weight: weight)
        l.textColor = color
        l.textAlignment = align
        l.numberOfLines = 0
        return l
    }

    private func makeStat(value: String, title: String, color: UIColor, valueSize: CGFloat) -> UIView {
        let v = makeLabel(value, size: valueSize, weight: .heavy, color: color)
        let t = makeLabel(title, size: 11, weight: .semibold, color: UIColor(white: 1, alpha: 0.6))
        let s = UIStackView(arrangedSubviews: [v, t])
        s.axis = .vertical
        s.spacing = 2
        s.alignment = .fill
        return s
    }

    // MARK: Montagem

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = Theme.base
        let e = engine

        // recorde
        let key = map.key
        let prev = Records.best(key)
        Records.addPlay(key)
        var newBest = false
        if !e.failed && !mods.contains(.auto) {
            let rec = ScoreRecord(score: e.score, accuracy: e.accuracy, grade: e.grade, maxCombo: e.maxCombo, date: Date())
            newBest = Records.saveIfBest(key, rec)
        }

        // fundo
        let bg = BackgroundView(dim: 0.72)
        view.addSubview(bg)
        NSLayoutConstraint.activate([
            bg.topAnchor.constraint(equalTo: view.topAnchor), bg.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            bg.leadingAnchor.constraint(equalTo: view.leadingAnchor), bg.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])
        if let u = map.backgroundURL {
            ImageLoader.load(u, maxSide: 1600) { img in bg.set(img, animated: false) }
        }

        // topo: título do mapa
        let title = makeLabel("\(map.artist) – \(map.title)", size: 19, weight: .bold, align: .left)
        title.numberOfLines = 1
        let sub = makeLabel("[\(map.version)]  ·  \(map.keys)K  ·  mapa de \(map.creator)", size: 13, weight: .regular,
                            color: UIColor(white: 1, alpha: 0.7), align: .left)
        sub.numberOfLines = 1
        let topStack = UIStackView(arrangedSubviews: [title, sub])
        topStack.axis = .vertical
        topStack.spacing = 2
        topStack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(topStack)

        // esquerda: rank
        let ring = UIView()
        ring.translatesAutoresizingMaskIntoConstraints = false
        let gradeColor = Theme.gradeColor(e.grade)
        ring.layer.cornerRadius = 95
        ring.layer.borderWidth = 6
        ring.layer.borderColor = gradeColor.cgColor
        ring.backgroundColor = UIColor.black.withAlphaComponent(0.45)
        ring.layer.shadowColor = gradeColor.cgColor
        ring.layer.shadowOpacity = 0.55
        ring.layer.shadowRadius = 22
        ring.layer.shadowOffset = .zero
        let grade = makeLabel(e.grade, size: 96, weight: .heavy, color: gradeColor)
        grade.translatesAutoresizingMaskIntoConstraints = false
        ring.addSubview(grade)
        view.addSubview(ring)
        let status = makeLabel(e.failed ? "FALHOU" : "CONCLUÍDO", size: 14, weight: .heavy,
                               color: e.failed ? UIColor(red: 1, green: 0.35, blue: 0.35, alpha: 1) : Theme.teal)
        status.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(status)

        // direita: painel
        let card = UIView()
        card.backgroundColor = Theme.card
        card.layer.cornerRadius = 18
        card.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(card)
        let scroll = UIScrollView()
        scroll.translatesAutoresizingMaskIntoConstraints = false
        scroll.showsVerticalScrollIndicator = false
        card.addSubview(scroll)

        let scoreLabel = makeLabel(String(format: "%07d", e.score), size: 46, weight: .heavy)
        var badgeText = ""
        var badgeColor = UIColor(white: 1, alpha: 0.55)
        if newBest {
            badgeText = "★  NOVO RECORDE  ★"
            badgeColor = Theme.gold
        } else if let p = prev {
            badgeText = String(format: "Recorde: %07d", p.score)
        }
        let badge = makeLabel(badgeText, size: 13, weight: .bold, color: badgeColor)

        let accStat = makeStat(value: String(format: "%.2f%%", e.accuracy * 100), title: "PRECISÃO", color: .white, valueSize: 24)
        let comboStat = makeStat(value: "\(e.maxCombo)x", title: "COMBO MÁXIMO", color: .white, valueSize: 24)
        let statsRow = UIStackView(arrangedSubviews: [accStat, comboStat])
        statsRow.axis = .horizontal
        statsRow.distribution = .fillEqually
        statsRow.spacing = 8

        func hitRow(_ idx: [Int]) -> UIStackView {
            var boxes: [UIView] = []
            for i in idx {
                let j = Judgement(rawValue: i) ?? .miss
                boxes.append(makeStat(value: "\(e.counts[i])", title: j.label, color: j.color, valueSize: 22))
            }
            let r = UIStackView(arrangedSubviews: boxes)
            r.axis = .horizontal
            r.distribution = .fillEqually
            r.spacing = 8
            return r
        }
        let modsLabel = makeLabel("Mods: " + mods.acronyms, size: 12, weight: .semibold, color: UIColor(white: 1, alpha: 0.55))

        let content = UIStackView(arrangedSubviews: [scoreLabel, badge, statsRow, hitRow([0, 1, 2]), hitRow([3, 4, 5]), modsLabel])
        content.axis = .vertical
        content.spacing = 12
        content.setCustomSpacing(2, after: scoreLabel)
        content.setCustomSpacing(18, after: badge)
        content.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(content)

        // rodapé: botões
        let back = PillButton(title: "◀  Voltar", color: Theme.pinkDeep, fontSize: 17)
        let retry = PillButton(title: "Tentar de novo", color: Theme.blue, fontSize: 17)
        back.addAction(UIAction { [weak self] _ in self?.onClose?() }, for: .touchUpInside)
        retry.addAction(UIAction { [weak self] _ in self?.onRetry?() }, for: .touchUpInside)
        view.addSubview(back)
        view.addSubview(retry)

        let safe = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            topStack.topAnchor.constraint(equalTo: safe.topAnchor, constant: 14),
            topStack.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 24),
            topStack.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -24),

            ring.widthAnchor.constraint(equalToConstant: 190),
            ring.heightAnchor.constraint(equalToConstant: 190),
            ring.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 36),
            ring.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -8),
            grade.centerXAnchor.constraint(equalTo: ring.centerXAnchor),
            grade.centerYAnchor.constraint(equalTo: ring.centerYAnchor),
            status.centerXAnchor.constraint(equalTo: ring.centerXAnchor),
            status.topAnchor.constraint(equalTo: ring.bottomAnchor, constant: 12),

            card.leadingAnchor.constraint(equalTo: ring.trailingAnchor, constant: 36),
            card.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -24),
            card.topAnchor.constraint(equalTo: topStack.bottomAnchor, constant: 14),
            card.bottomAnchor.constraint(equalTo: back.topAnchor, constant: -14),

            scroll.topAnchor.constraint(equalTo: card.topAnchor, constant: 14),
            scroll.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -14),
            scroll.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 16),
            scroll.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -16),
            content.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor),
            content.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor),
            content.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor),
            content.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor),
            content.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor),

            back.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 24),
            back.bottomAnchor.constraint(equalTo: safe.bottomAnchor, constant: -14),
            retry.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -24),
            retry.bottomAnchor.constraint(equalTo: safe.bottomAnchor, constant: -14),
        ])
    }
}
