import UIKit
import ImageIO

// Identidade visual inspirada no osu! (stable / droid): fundo escuro, rosa de destaque,
// painéis translúcidos e botões arredondados.

enum Theme {
    static let pink = UIColor(red: 1.0, green: 0.40, blue: 0.67, alpha: 1)
    static let pinkDeep = UIColor(red: 0.86, green: 0.22, blue: 0.50, alpha: 1)
    static let purple = UIColor(red: 0.55, green: 0.38, blue: 0.95, alpha: 1)
    static let blue = UIColor(red: 0.30, green: 0.62, blue: 1.0, alpha: 1)
    static let teal = UIColor(red: 0.22, green: 0.80, blue: 0.72, alpha: 1)
    static let gold = UIColor(red: 1.0, green: 0.82, blue: 0.30, alpha: 1)
    static let panel = UIColor(white: 0.0, alpha: 0.55)
    static let card = UIColor(white: 0.06, alpha: 0.78)
    static let base = UIColor(red: 0.07, green: 0.05, blue: 0.12, alpha: 1)

    /// Aplica tema escuro + cor de destaque em toda a janela e nas barras de navegação.
    static func install(on window: UIWindow) {
        window.tintColor = pink
        window.overrideUserInterfaceStyle = .dark
        let nav = UINavigationBarAppearance()
        nav.configureWithOpaqueBackground()
        nav.backgroundColor = UIColor(red: 0.09, green: 0.06, blue: 0.14, alpha: 1)
        nav.titleTextAttributes = [.foregroundColor: UIColor.white]
        UINavigationBar.appearance().standardAppearance = nav
        UINavigationBar.appearance().scrollEdgeAppearance = nav
        UINavigationBar.appearance().compactAppearance = nav
        UINavigationBar.appearance().tintColor = pink
    }

    /// Cor da dificuldade (aproximada pela densidade de notas por segundo).
    static func difficultyColor(nps: Double) -> UIColor {
        switch nps {
        case ..<2.5: return UIColor(red: 0.45, green: 0.85, blue: 0.45, alpha: 1)
        case ..<4.5: return UIColor(red: 0.75, green: 0.9, blue: 0.3, alpha: 1)
        case ..<6.5: return UIColor(red: 1.0, green: 0.75, blue: 0.25, alpha: 1)
        case ..<8.5: return UIColor(red: 1.0, green: 0.45, blue: 0.4, alpha: 1)
        case ..<11: return UIColor(red: 0.9, green: 0.35, blue: 0.7, alpha: 1)
        default: return UIColor(red: 0.6, green: 0.4, blue: 1.0, alpha: 1)
        }
    }

    static func gradeColor(_ g: String) -> UIColor {
        switch g {
        case "SS": return gold
        case "S": return UIColor(red: 1.0, green: 0.85, blue: 0.4, alpha: 1)
        case "A": return UIColor(red: 0.5, green: 0.9, blue: 0.4, alpha: 1)
        case "B": return blue
        case "C": return purple
        case "D": return UIColor(red: 1.0, green: 0.4, blue: 0.4, alpha: 1)
        default: return UIColor(red: 1.0, green: 0.3, blue: 0.3, alpha: 1)
        }
    }
}

// MARK: - Botão arredondado

final class PillButton: UIButton {
    init(title: String, color: UIColor, fontSize: CGFloat = 16) {
        super.init(frame: .zero)
        setTitle(title, for: .normal)
        titleLabel?.font = .systemFont(ofSize: fontSize, weight: .bold)
        setTitleColor(.white, for: .normal)
        backgroundColor = color
        layer.cornerRadius = 12
        contentEdgeInsets = UIEdgeInsets(top: 10, left: 18, bottom: 10, right: 18)
        translatesAutoresizingMaskIntoConstraints = false
    }
    required init?(coder: NSCoder) { fatalError() }

    override var isHighlighted: Bool {
        didSet {
            UIView.animate(withDuration: 0.12) {
                self.alpha = self.isHighlighted ? 0.7 : 1
                self.transform = self.isHighlighted ? CGAffineTransform(scaleX: 0.97, y: 0.97) : .identity
            }
        }
    }
}

// MARK: - Fundo com imagem + escurecimento

final class BackgroundView: UIView {
    private let imageView = UIImageView()
    private let dimView = UIView()
    private let gradient = CAGradientLayer()

    init(dim: CGFloat = 0.45) {
        super.init(frame: .zero)
        translatesAutoresizingMaskIntoConstraints = false
        backgroundColor = Theme.base
        gradient.colors = [UIColor(red: 0.20, green: 0.08, blue: 0.30, alpha: 1).cgColor,
                           UIColor(red: 0.05, green: 0.03, blue: 0.09, alpha: 1).cgColor]
        gradient.startPoint = CGPoint(x: 0, y: 0)
        gradient.endPoint = CGPoint(x: 1, y: 1)
        layer.addSublayer(gradient)
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        addSubview(imageView)
        dimView.backgroundColor = UIColor.black.withAlphaComponent(dim)
        addSubview(dimView)
        clipsToBounds = true
    }
    required init?(coder: NSCoder) { fatalError() }

    override func layoutSubviews() {
        super.layoutSubviews()
        gradient.frame = bounds
        imageView.frame = bounds
        dimView.frame = bounds
    }

    func setDim(_ d: CGFloat) { dimView.backgroundColor = UIColor.black.withAlphaComponent(d) }

    func set(_ img: UIImage?, animated: Bool = true) {
        let apply = { self.imageView.image = img }
        if animated {
            UIView.transition(with: imageView, duration: 0.35, options: .transitionCrossDissolve, animations: apply)
        } else {
            apply()
        }
    }
}

// MARK: - Carregamento de imagem otimizado (fora da thread principal)

enum ImageLoader {
    private static let cache = NSCache<NSString, UIImage>()

    /// Decodifica já reduzida (ImageIO), sem travar a interface.
    static func load(_ url: URL, maxSide: CGFloat, completion: @escaping (UIImage?) -> Void) {
        let key = "\(url.path)|\(Int(maxSide))" as NSString
        if let hit = cache.object(forKey: key) { completion(hit); return }
        DispatchQueue.global(qos: .userInitiated).async {
            var result: UIImage?
            if let src = CGImageSourceCreateWithURL(url as CFURL, nil) {
                let opts: [CFString: Any] = [
                    kCGImageSourceCreateThumbnailFromImageAlways: true,
                    kCGImageSourceCreateThumbnailWithTransform: true,
                    kCGImageSourceShouldCacheImmediately: true,
                    kCGImageSourceThumbnailMaxPixelSize: maxSide,
                ]
                if let cg = CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary) {
                    result = UIImage(cgImage: cg)
                }
            }
            if let r = result { cache.setObject(r, forKey: key) }
            DispatchQueue.main.async { completion(result) }
        }
    }
}
