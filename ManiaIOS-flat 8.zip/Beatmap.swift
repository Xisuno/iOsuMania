import Foundation

// MARK: - Dados de hitsound (formato .osu)

struct SampleInfo {
    var hitSound = 0     // máscara: 2 whistle, 4 finish, 8 clap (o "normal" sempre toca)
    var normalSet = 0    // 1 normal, 2 soft, 3 drum (0 = herdar do timing point)
    var addSet = 0       // conjunto das adições (0 = igual ao normalSet)
    var index = 0        // índice de sample personalizado (0/1 = sem sufixo)
    var volume = 0       // 1...100 (0 = herdar)
    var file = ""        // arquivo personalizado (hitSample)
}

struct HitObject {
    var column: Int
    var time: Double          // ms
    var endTime: Double?      // ms (nil = nota simples)
    var sample = SampleInfo()
}

struct TimingSample {
    var time: Double
    var set: Int
    var index: Int
    var volume: Int
}

// MARK: - Resumo leve de um mapa (vai para o cache da biblioteca)

struct BeatmapInfo: Codable {
    var dirName: String
    var fileName: String
    var title: String
    var artist: String
    var version: String
    var creator: String
    var keys: Int
    var od: Double
    var count: Int
    var lengthMs: Double
    var bpm: Double
    var previewTime: Int
    var audio: String
    var bg: String?
    var mtime: Double
    var size: Int

    var nps: Double { (count == 0 || lengthMs <= 0) ? 0 : Double(count) / (lengthMs / 1000) }
    var key: String { dirName + "/" + fileName }
    var dirURL: URL { Paths.songs.appendingPathComponent(dirName, isDirectory: true) }
    var fileURL: URL { dirURL.appendingPathComponent(fileName) }
    var audioURL: URL { dirURL.appendingPathComponent(audio) }
    var bgURL: URL? { bg.map { dirURL.appendingPathComponent($0) } }

    /// Lê o mapa completo (só quando for jogar).
    func load() -> Beatmap? { Beatmap(file: fileURL) }
}

struct BeatmapSet {
    var dirName: String
    var title: String
    var artist: String
    var creator: String
    var diffs: [BeatmapInfo]
    var addedAt: Double
    var bg: String?

    var dirURL: URL { Paths.songs.appendingPathComponent(dirName, isDirectory: true) }
    var bgURL: URL? { bg.map { dirURL.appendingPathComponent($0) } }
}

// MARK: - Mapa completo

final class Beatmap {
    let dir: URL
    let file: URL
    var title = "Unknown"
    var artist = "Unknown"
    var version = ""
    var creator = ""
    var audioFilename = ""
    var backgroundFilename: String?
    var keys = 4
    var od = 5.0
    var previewTime = -1
    var bpm = 0.0
    var objects: [HitObject] = []

    var audioURL: URL { dir.appendingPathComponent(audioFilename) }
    var backgroundURL: URL? { backgroundFilename.map { dir.appendingPathComponent($0) } }
    var lengthMs: Double { objects.map { $0.endTime ?? $0.time }.max() ?? 0 }
    var key: String { dir.lastPathComponent + "/" + file.lastPathComponent }

    /// Retorna nil se não for um mapa osu!mania válido.
    init?(file: URL) {
        self.file = file
        self.dir = file.deletingLastPathComponent()
        guard let d = try? Data(contentsOf: file),
              let raw = String(data: d, encoding: .utf8) ?? String(data: d, encoding: .isoLatin1) else { return nil }
        var section = ""
        var mode = 0
        var generalSet = 1
        var timing: [TimingSample] = []
        var uninherited: [(Double, Double)] = []

        for rawLine in raw.components(separatedBy: .newlines) {
            let line = rawLine.trimmingCharacters(in: .whitespaces)
            if line.isEmpty || line.hasPrefix("//") { continue }
            if line.hasPrefix("[") && line.hasSuffix("]") {
                section = String(line.dropFirst().dropLast())
                continue
            }
            switch section {
            case "General", "Metadata", "Difficulty":
                guard let c = line.firstIndex(of: ":") else { continue }
                let k = line[line.startIndex..<c].trimmingCharacters(in: .whitespaces)
                let v = line[line.index(after: c)...].trimmingCharacters(in: .whitespaces)
                switch k {
                case "AudioFilename": audioFilename = v
                case "Mode": mode = Int(v) ?? 0
                case "PreviewTime": previewTime = Int(v) ?? -1
                case "SampleSet":
                    switch v.lowercased() {
                    case "soft": generalSet = 2
                    case "drum": generalSet = 3
                    default: generalSet = 1
                    }
                case "Title": title = v
                case "Artist": artist = v
                case "Version": version = v
                case "Creator": creator = v
                case "CircleSize": keys = max(1, min(10, Int(Double(v) ?? 4)))
                case "OverallDifficulty": od = Double(v) ?? 5
                default: break
                }
            case "Events":
                let p = line.split(separator: ",", omittingEmptySubsequences: false).map { $0.trimmingCharacters(in: .whitespaces) }
                if p.count >= 3, p[0] == "0", backgroundFilename == nil {
                    backgroundFilename = p[2].replacingOccurrences(of: "\"", with: "")
                }
            case "TimingPoints":
                let p = line.split(separator: ",", omittingEmptySubsequences: false).map { $0.trimmingCharacters(in: .whitespaces) }
                guard p.count >= 2, let t = Double(p[0]), let beat = Double(p[1]) else { continue }
                let set = p.count > 3 ? (Int(p[3]) ?? 0) : 0
                let idx = p.count > 4 ? (Int(p[4]) ?? 0) : 0
                let vol = p.count > 5 ? (Int(p[5]) ?? 100) : 100
                let isUninherited = p.count > 6 ? (p[6] == "1") : (beat > 0)
                timing.append(TimingSample(time: t, set: set, index: idx, volume: vol))
                if isUninherited && beat > 0 { uninherited.append((t, beat)) }
            case "HitObjects":
                let p = line.split(separator: ",", omittingEmptySubsequences: false).map(String.init)
                guard p.count >= 5, let x = Double(p[0]), let t = Double(p[2]), let type = Int(p[3]) else { continue }
                let col = max(0, min(keys - 1, Int(x * Double(keys) / 512.0)))
                var sample = SampleInfo()
                sample.hitSound = Int(p[4]) ?? 0
                var endTime: Double?
                var comps: [Substring] = []
                if p.count >= 6 { comps = p[5].split(separator: ":", omittingEmptySubsequences: false) }
                var sampleStart = 0
                if type & 128 != 0, !comps.isEmpty {
                    if let e = Double(comps[0]), e > t { endTime = e }
                    sampleStart = 1
                }
                if comps.count >= sampleStart + 4 {
                    sample.normalSet = Int(comps[sampleStart]) ?? 0
                    sample.addSet = Int(comps[sampleStart + 1]) ?? 0
                    sample.index = Int(comps[sampleStart + 2]) ?? 0
                    sample.volume = Int(comps[sampleStart + 3]) ?? 0
                    if comps.count > sampleStart + 4 { sample.file = String(comps[sampleStart + 4]).trimmingCharacters(in: .whitespaces) }
                }
                objects.append(HitObject(column: col, time: t, endTime: endTime, sample: sample))
            default: break
            }
        }
        guard mode == 3, !objects.isEmpty, !audioFilename.isEmpty else { return nil }
        objects.sort { $0.time < $1.time }

        // Resolve os samples de cada nota com os timing points (herança).
        timing.sort { $0.time < $1.time }
        var ti = 0
        for i in 0..<objects.count {
            let t = objects[i].time
            while ti + 1 < timing.count && timing[ti + 1].time <= t { ti += 1 }
            let tp = timing.isEmpty ? TimingSample(time: 0, set: 0, index: 0, volume: 100) : timing[ti]
            var s = objects[i].sample
            if s.normalSet == 0 { s.normalSet = tp.set != 0 ? tp.set : generalSet }
            if s.addSet == 0 { s.addSet = s.normalSet }
            if s.index == 0 { s.index = tp.index }
            if s.volume == 0 { s.volume = tp.volume > 0 ? tp.volume : 100 }
            objects[i].sample = s
        }

        // BPM principal = o que dura mais tempo.
        if !uninherited.isEmpty {
            let endT = max(lengthMs, (uninherited.last?.0 ?? 0) + 1)
            var best = 0.0
            var bestDur = -1.0
            for i in 0..<uninherited.count {
                let t0 = uninherited[i].0
                let t1 = i + 1 < uninherited.count ? uninherited[i + 1].0 : endT
                let dur = max(0, t1 - t0)
                if dur > bestDur { bestDur = dur; best = 60000.0 / uninherited[i].1 }
            }
            bpm = best
        }
    }

    func info(mtime: Double, size: Int) -> BeatmapInfo {
        BeatmapInfo(dirName: dir.lastPathComponent, fileName: file.lastPathComponent,
                    title: title, artist: artist, version: version, creator: creator,
                    keys: keys, od: od, count: objects.count, lengthMs: lengthMs, bpm: bpm,
                    previewTime: previewTime, audio: audioFilename, bg: backgroundFilename,
                    mtime: mtime, size: size)
    }
}

// MARK: - Biblioteca (cache em disco, carregada em segundo plano)

enum Library {
    private static func readCache() -> [String: BeatmapInfo] {
        guard let d = try? Data(contentsOf: Paths.libraryCache),
              let c = try? JSONDecoder().decode([String: BeatmapInfo].self, from: d) else { return [:] }
        return c
    }

    private static func writeCache(_ c: [String: BeatmapInfo]) {
        if let d = try? JSONEncoder().encode(c) { try? d.write(to: Paths.libraryCache) }
    }

    /// Lê todos os sets. Mapas já conhecidos vêm do cache; só os novos/alterados são interpretados.
    static func loadSets(completion: @escaping ([BeatmapSet]) -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            let sets = scan()
            DispatchQueue.main.async { completion(sets) }
        }
    }

    private static func scan() -> [BeatmapSet] {
        let fm = FileManager.default
        let cache = readCache()
        var fresh: [String: BeatmapInfo] = [:]
        var changed = false
        var out: [BeatmapSet] = []
        let dirs = (try? fm.contentsOfDirectory(at: Paths.songs, includingPropertiesForKeys: [.isDirectoryKey])) ?? []
        for d in dirs {
            if (try? d.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) != true { continue }
            let files = ((try? fm.contentsOfDirectory(at: d, includingPropertiesForKeys: nil)) ?? [])
                .filter { $0.pathExtension.lowercased() == "osu" }
            var diffs: [BeatmapInfo] = []
            for f in files {
                let rv = try? f.resourceValues(forKeys: [.contentModificationDateKey, .fileSizeKey])
                let mt = rv?.contentModificationDate?.timeIntervalSince1970 ?? 0
                let sz = rv?.fileSize ?? 0
                let key = d.lastPathComponent + "/" + f.lastPathComponent
                if let c = cache[key], c.mtime == mt, c.size == sz {
                    diffs.append(c)
                    fresh[key] = c
                } else if let m = Beatmap(file: f) {
                    let info = m.info(mtime: mt, size: sz)
                    diffs.append(info)
                    fresh[key] = info
                    changed = true
                }
            }
            if diffs.isEmpty { continue }
            diffs.sort { ($0.keys, $0.nps) < ($1.keys, $1.nps) }
            let first = diffs[0]
            let created = (try? d.resourceValues(forKeys: [.creationDateKey]))?.creationDate?.timeIntervalSince1970 ?? 0
            out.append(BeatmapSet(dirName: d.lastPathComponent, title: first.title, artist: first.artist,
                                  creator: first.creator, diffs: diffs, addedAt: created,
                                  bg: diffs.compactMap { $0.bg }.first))
        }
        if changed || fresh.count != cache.count { writeCache(fresh) }
        return out
    }

    // MARK: Importação

    enum ImportError: LocalizedError {
        case noMania
        var errorDescription: String? { "Nenhum mapa osu!mania (modo 3) encontrado nesse arquivo." }
    }

    @discardableResult
    static func importOSZ(_ url: URL) throws -> String {
        let name = url.deletingPathExtension().lastPathComponent
        let dest = Paths.uniqueDir(in: Paths.songs, name: name)
        let zip = try ZipArchive(url: url)
        try zip.extractAll(to: dest)
        let has = ((try? FileManager.default.contentsOfDirectory(at: dest, includingPropertiesForKeys: nil)) ?? [])
            .filter { $0.pathExtension.lowercased() == "osu" }
            .contains { Beatmap(file: $0) != nil }
        if !has {
            try? FileManager.default.removeItem(at: dest)
            throw ImportError.noMania
        }
        return name
    }

    @discardableResult
    static func importOSK(_ url: URL) throws -> String {
        let name = url.deletingPathExtension().lastPathComponent
        let dest = Paths.uniqueDir(in: Paths.skins, name: name)
        let zip = try ZipArchive(url: url)
        try zip.extractAll(to: dest)
        // Alguns .osk têm tudo dentro de uma subpasta: sobe o conteúdo um nível.
        let fm = FileManager.default
        if !fm.fileExists(atPath: dest.appendingPathComponent("skin.ini").path) {
            let items = (try? fm.contentsOfDirectory(at: dest, includingPropertiesForKeys: nil)) ?? []
            if items.count == 1, fm.fileExists(atPath: items[0].appendingPathComponent("skin.ini").path) {
                for f in (try? fm.contentsOfDirectory(at: items[0], includingPropertiesForKeys: nil)) ?? [] {
                    try? fm.moveItem(at: f, to: dest.appendingPathComponent(f.lastPathComponent))
                }
                try? fm.removeItem(at: items[0])
            }
        }
        return dest.lastPathComponent
    }

    /// Importa .osz ou .osk pela extensão. Retorna mensagem para o usuário.
    static func importAny(_ url: URL) -> String {
        do {
            switch url.pathExtension.lowercased() {
            case "osz": return "Beatmap importado: \(try importOSZ(url))"
            case "osk": return "Skin importada: \(try importOSK(url))"
            default: return "Formato não suportado (use .osz ou .osk)."
            }
        } catch {
            return "Falha ao importar: \(error.localizedDescription)"
        }
    }

    // MARK: Mapa de demonstração (gerado por código)

    static func ensureDemo() {
        let dir = Paths.songs.appendingPathComponent("Demo Beat", isDirectory: true)
        let fm = FileManager.default
        if fm.fileExists(atPath: dir.appendingPathComponent("demo.wav").path) { return }
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        try? makeWav().write(to: dir.appendingPathComponent("demo.wav"))
        for (k, v) in [(4, "4K Easy"), (7, "7K Normal")] {
            try? demoOsu(keys: k, version: v).write(to: dir.appendingPathComponent("demo-\(k)k.osu"), atomically: true, encoding: .utf8)
        }
    }

    private static func le16(_ v: Int) -> [UInt8] { [UInt8(v & 255), UInt8((v >> 8) & 255)] }
    private static func le32(_ v: Int) -> [UInt8] { le16(v & 0xFFFF) + le16((v >> 16) & 0xFFFF) }

    private static func makeWav() -> Data {
        let rate = 44100
        let seconds = 66
        let n = rate * seconds
        var pcm = [Int16](repeating: 0, count: n)
        let beat = 0.5  // 120 BPM
        var seed: UInt32 = 12345
        func noise() -> Double {
            seed = seed &* 1664525 &+ 1013904223
            return Double(seed >> 8) / Double(1 << 24) * 2 - 1
        }
        for i in 0..<n {
            let t = Double(i) / Double(rate)
            let inBeat = t.truncatingRemainder(dividingBy: beat)
            let beatIndex = Int(t / beat)
            var s = 0.0
            // bumbo em todo tempo
            if inBeat < 0.25 {
                let phase = 50 * inBeat + (100.0 / 30.0) * (1 - exp(-30 * inBeat))
                s += sin(2 * Double.pi * phase) * exp(-inBeat * 12) * 0.8
            }
            // caixa nos tempos 2 e 4
            if beatIndex % 2 == 1 && inBeat < 0.2 { s += noise() * exp(-inBeat * 20) * 0.35 }
            // chimbal nos contratempos
            let off = (t + beat / 2).truncatingRemainder(dividingBy: beat)
            if off < 0.05 { s += noise() * exp(-off * 60) * 0.2 }
            pcm[i] = Int16(max(-1, min(1, s)) * 28000)
        }
        var d = Data()
        d.append(contentsOf: Array("RIFF".utf8)); d.append(contentsOf: le32(36 + n * 2))
        d.append(contentsOf: Array("WAVEfmt ".utf8)); d.append(contentsOf: le32(16))
        d.append(contentsOf: le16(1)); d.append(contentsOf: le16(1))
        d.append(contentsOf: le32(rate)); d.append(contentsOf: le32(rate * 2))
        d.append(contentsOf: le16(2)); d.append(contentsOf: le16(16))
        d.append(contentsOf: Array("data".utf8)); d.append(contentsOf: le32(n * 2))
        pcm.withUnsafeBytes { d.append(contentsOf: $0) }
        return d
    }

    private static func demoOsu(keys k: Int, version: String) -> String {
        var out = "osu file format v14\n\n[General]\nAudioFilename: demo.wav\nMode: 3\n\n"
        out += "[Metadata]\nTitle:Demo Beat\nArtist:ManiaIOS\nCreator:built-in\nVersion:\(version)\n\n"
        out += "[Difficulty]\nHPDrainRate:5\nCircleSize:\(k)\nOverallDifficulty:7\nApproachRate:5\n\n"
        out += "[Events]\n\n[TimingPoints]\n0,500,4,1,0,100,1,0\n\n[HitObjects]\n"
        var lastEnd = [Double](repeating: -1000, count: k)
        var seed: UInt32 = UInt32(k) &* 7919
        func rnd(_ m: Int) -> Int {
            seed = seed &* 1664525 &+ 1013904223
            return Int((seed >> 16) % UInt32(m))
        }
        func x(_ c: Int) -> Int { Int((Double(c) + 0.5) * 512.0 / Double(k)) }
        var step = 0
        var t = 2000.0
        while t < 60000 {
            if step % 32 == 0 {
                let c = rnd(k)
                if t > lastEnd[c] + 20 {
                    let end = t + 1000
                    out += "\(x(c)),192,\(Int(t)),128,0,\(Int(end)):0:0:0:0:\n"
                    lastEnd[c] = end
                }
            } else if step % 2 == 0 || rnd(3) == 0 {
                let c = rnd(k)
                if t > lastEnd[c] + 20 {
                    out += "\(x(c)),192,\(Int(t)),1,0,0:0:0:0:\n"
                    lastEnd[c] = t
                }
                if k >= 6 && step % 4 == 0 {
                    let c2 = (c + 3) % k
                    if t > lastEnd[c2] + 20 {
                        out += "\(x(c2)),192,\(Int(t)),1,0,0:0:0:0:\n"
                        lastEnd[c2] = t
                    }
                }
            }
            step += 1
            t += 250
        }
        return out
    }
}
