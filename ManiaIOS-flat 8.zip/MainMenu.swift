import UIKit

/// Menu principal no estilo do osu!: logo grande pulsando à esquerda, barras à direita.
final class MainMenuViewController: UIViewController {
    private let bg = BackgroundView(dim: 0.5)
    private let logo = UIView()

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }
    override var prefersStatusBarHidden: Bool { true }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = Theme.base
        view.addSubview(bg)
        NSLayoutConstraint.activate([
            bg.topAnchor.constraint(equalTo: view.topAnchor), bg.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            bg.leadingAnchor.constraint(equalTo: view.leadingAnchor), bg.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])

        // logo
        logo.backgroundColor = Theme.pink
        logo.layer.cornerRadius = 110
        logo.layer.borderWidth = 8
        logo.layer.borderColor = UIColor.white.cgColor
        logo.layer.shadowColor = Theme.pink.cgColor
        logo.layer.shadowOpacity = 0.7
        logo.layer.shadowRadius = 26
        logo.layer.shadowOffset = .zero
        logo.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(logo)
        let word = UILabel()
        word.text = "mania!"
        word.font = .systemFont(ofSize: 48, weight: .heavy)
        word.textColor = .white
        word.textAlignment = .center
        let sub = UILabel()
        sub.text = "ritmo em 4K – 7K"
        sub.font = .systemFont(ofSize: 13, weight: .semibold)
        sub.textColor = UIColor(white: 1, alpha: 0.85)
        sub.textAlignment = .center
        let logoStack = UIStackView(arrangedSubviews: [word, sub])
        logoStack.axis = .vertical
        logoStack.spacing = 2
        logoStack.translatesAutoresizingMaskIntoConstraints = false
        logo.addSubview(logoStack)
        logo.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(playTapped)))

        // barras
        let bars = UIStackView(arrangedSubviews: [
            bar("Jogar", Theme.pink, #selector(playTapped)),
            bar("Opções", Theme.purple, #selector(optionsTapped)),
            bar("Skins", Theme.blue, #selector(skinsTapped)),
            bar("Importar", Theme.teal, #selector(importTapped)),
        ])
        bars.axis = .vertical
        bars.spacing = 12
        bars.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bars)

        let safe = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            logo.widthAnchor.constraint(equalToConstant: 220),
            logo.heightAnchor.constraint(equalToConstant: 220),
            logo.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 60),
            logo.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            logoStack.centerXAnchor.constraint(equalTo: logo.centerXAnchor),
            logoStack.centerYAnchor.constraint(equalTo: logo.centerYAnchor),
            logoStack.leadingAnchor.constraint(equalTo: logo.leadingAnchor, constant: 12),
            logoStack.trailingAnchor.constraint(equalTo: logo.trailingAnchor, constant: -12),

            bars.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -40),
            bars.widthAnchor.constraint(equalToConstant: 300),
            bars.centerYAnchor.constraint(equalTo: view.centerYAnchor),
        ])

        NotificationCenter.default.addObserver(self, selector: #selector(refreshBG), name: .backgroundChanged, object: nil)
        refreshBG()
    }

    private func bar(_ t: String, _ color: UIColor, _ sel: Selector) -> UIButton {
        let b = PillButton(title: t, color: color, fontSize: 22)
        b.heightAnchor.constraint(equalToConstant: 56).isActive = true
        b.addTarget(self, action: sel, for: .touchUpInside)
        return b
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
        refreshBG()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        startPulse()
    }

    private func startPulse() {
        logo.layer.removeAnimation(forKey: "pulse")
        let a = CABasicAnimation(keyPath: "transform.scale")
        a.fromValue = 1.0
        a.toValue = 1.045
        a.duration = 0.5
        a.autoreverses = true
        a.repeatCount = .infinity
        a.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        logo.layer.add(a, forKey: "pulse")
    }

    @objc private func refreshBG() { bg.set(BackgroundStore.current(), animated: false) }

    @objc private func playTapped() { navigationController?.pushViewController(SongSelectViewController(), animated: true) }
    @objc private func optionsTapped() { navigationController?.pushViewController(OptionsViewController(), animated: true) }
    @objc private func skinsTapped() { navigationController?.pushViewController(OptionsViewController(start: 4), animated: true) }
    @objc private func importTapped() { ImportUI.importArchives(from: self) {} }
}

// MARK: - Opções com barra lateral (estilo osu!droid)

final class OptionsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    private let titles = ["Jogabilidade", "Áudio", "Fundo", "Layout & skin.ini", "Skins", "Mods"]
    private let table = UITableView(frame: .zero, style: .plain)
    private let container = UIView()
    private var current: UIViewController?
    private var index: Int

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }
    override var prefersStatusBarHidden: Bool { true }

    init(start: Int = 0) {
        index = start
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = Theme.base
        let safe = view.safeAreaLayoutGuide

        let head = UILabel()
        head.text = "Opções"
        head.font = .systemFont(ofSize: 26, weight: .heavy)
        head.textColor = .white
        head.translatesAutoresizingMaskIntoConstraints = false
        let back = PillButton(title: "◀  Voltar", color: Theme.pinkDeep, fontSize: 15)
        back.addAction(UIAction { [weak self] _ in self?.navigationController?.popViewController(animated: true) }, for: .touchUpInside)
        back.translatesAutoresizingMaskIntoConstraints = false

        table.backgroundColor = Theme.panel
        table.layer.cornerRadius = 14
        table.separatorStyle = .none
        table.dataSource = self
        table.delegate = self
        table.register(SongCardCell.self, forCellReuseIdentifier: "c")
        table.translatesAutoresizingMaskIntoConstraints = false
        container.translatesAutoresizingMaskIntoConstraints = false
        container.layer.cornerRadius = 14
        container.clipsToBounds = true
        container.backgroundColor = Theme.base

        view.addSubview(head)
        view.addSubview(back)
        view.addSubview(table)
        view.addSubview(container)
        NSLayoutConstraint.activate([
            head.topAnchor.constraint(equalTo: safe.topAnchor, constant: 10),
            head.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 20),
            back.centerYAnchor.constraint(equalTo: head.centerYAnchor),
            back.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -20),
            table.topAnchor.constraint(equalTo: head.bottomAnchor, constant: 10),
            table.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 16),
            table.bottomAnchor.constraint(equalTo: safe.bottomAnchor, constant: -10),
            table.widthAnchor.constraint(equalToConstant: 220),
            container.topAnchor.constraint(equalTo: table.topAnchor),
            container.bottomAnchor.constraint(equalTo: table.bottomAnchor),
            container.leadingAnchor.constraint(equalTo: table.trailingAnchor, constant: 12),
            container.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -16),
        ])
        show(index)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }

    private func makeChild(_ i: Int) -> UIViewController {
        switch i {
        case 0: return SettingsViewController(category: .gameplay)
        case 1: return SettingsViewController(category: .audio)
        case 2: return SettingsViewController(category: .background)
        case 3: return GameplayLayoutViewController()
        case 4: return SkinsViewController()
        default: return ModsViewController()
        }
    }

    private func show(_ i: Int) {
        index = i
        if let c = current {
            c.willMove(toParent: nil)
            c.view.removeFromSuperview()
            c.removeFromParent()
        }
        let vc = makeChild(i)
        addChild(vc)
        vc.view.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(vc.view)
        NSLayoutConstraint.activate([
            vc.view.topAnchor.constraint(equalTo: container.topAnchor),
            vc.view.bottomAnchor.constraint(equalTo: container.bottomAnchor),
            vc.view.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            vc.view.trailingAnchor.constraint(equalTo: container.trailingAnchor),
        ])
        vc.didMove(toParent: self)
        current = vc
        table.reloadData()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { titles.count }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat { 52 }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "c", for: indexPath) as! SongCardCell
        let t = NSAttributedString(string: titles[indexPath.row], attributes: [
            .font: UIFont.systemFont(ofSize: 15, weight: .bold), .foregroundColor: UIColor.white])
        cell.configure(title: t, subtitle: "", tag: nil, selected: indexPath.row == index, indent: 0, stripeColor: Theme.pink)
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        if indexPath.row != index { show(indexPath.row) }
    }
}
