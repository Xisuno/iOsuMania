import UIKit

struct StageLayout {
    var colX: [CGFloat] = []
    var colW: [CGFloat] = []
    var lineW: [CGFloat] = []
    var hitY: CGFloat = 0
    var scale: CGFloat = 1          // pontos por unidade osu (vertical)
    var left: CGFloat = 0
    var right: CGFloat = 0
    var noteHeightMul: CGFloat = 1
    var upscroll = false
    var touchTop: CGFloat = 0
    var touchBottom: CGFloat = 0

    static func make(size: CGSize, cfg: ManiaConfig, settings s: Settings) -> StageLayout {
        var L = StageLayout()
        let k = cfg.keys
        let sy = size.height / 480
        let wMul = CGFloat(s.columnWidthPct / 100)
        var widths = cfg.columnWidth.map { CGFloat($0) * sy * wMul }
        var total = widths.reduce(0, +)
        let maxW = size.width * 0.98
        if total > maxW {
            let f = maxW / total
            widths = widths.map { $0 * f }
            total = maxW
        }
        let oscTotal = CGFloat(cfg.columnWidth.reduce(0, +))
        var center = size.width / 2
        if let cs = cfg.columnStart {
            center += (CGFloat(cs) + oscTotal / 2 - 320) * sy
        }
        center += CGFloat(s.stageXOffset)
        var left = center - total / 2
        left = max(0, min(size.width - total, left))
        var x = left
        for i in 0..<k {
            L.colX.append(x)
            L.colW.append(widths[i])
            L.lineW.append(CGFloat(cfg.columnLineWidth[i]) * sy)
            x += widths[i]
        }
        L.lineW.append(CGFloat(cfg.columnLineWidth[k]) * sy)
        L.left = left
        L.right = left + total
        let basePos = s.useSkinHitPosition ? cfg.hitPosition : 402
        let hp = max(100, min(480, basePos + s.hitPositionOffset))
        L.hitY = CGFloat(hp) * size.height / 480
        L.scale = sy
        L.noteHeightMul = CGFloat(s.noteHeightPct / 100)
        switch s.scrollDirection {
        case 1: L.upscroll = false
        case 2: L.upscroll = true
        default: L.upscroll = cfg.upsideDown
        }
        let zh = size.height * CGFloat(max(10, min(100, s.touchZoneHeight)) / 100)
        let free = size.height - zh
        L.touchBottom = size.height - free * CGFloat(max(0, min(100, s.touchZonePos)) / 100)
        L.touchTop = L.touchBottom - zh
        return L
    }

    func column(at x: CGFloat) -> Int {
        if colX.isEmpty { return 0 }
        if x <= left { return 0 }
        if x >= right { return colX.count - 1 }
        for i in 0..<colX.count where x < colX[i] + colW[i] { return i }
        return colX.count - 1
    }
}

struct DrawNote {
    var column: Int
    var time: Double
    var endTime: Double?
    var holding: Bool
}

/// Camada com imagem: só troca o `contents` quando a imagem muda (a GPU faz o resto).
final class SpriteLayer: CALayer {
    var imageID: ObjectIdentifier?

    override init() { super.init() }
    override init(layer: Any) {
        super.init(layer: layer)
        if let o = layer as? SpriteLayer { imageID = o.imageID }
    }
    required init?(coder: NSCoder) { super.init(coder: coder) }

    func setImage(_ img: UIImage?) {
        let id = img.map { ObjectIdentifier($0) }
        if id == imageID { return }
        imageID = id
        contents = img?.cgImage
        if let i = img { contentsScale = i.scale }
    }
}

/// Tela de jogo composta por camadas (Core Animation): tudo é desenhado pela GPU,
/// a cada frame só mudam posições. Sem redesenho por CPU.
final class GameView: UIView {
    var skin: Skin
    let keys: Int
    var cfg: ManiaConfig
    var engine: GameEngine?
    var nowProvider: () -> Double = { 0 }
    var previewNotes: [DrawNote] = [] {
        didSet {
            var cols = [[Note]](repeating: [], count: keys)
            for d in previewNotes where d.column >= 0 && d.column < keys {
                let n = Note(column: d.column, time: d.time, endTime: d.endTime)
                n.holding = d.holding
                cols[d.column].append(n)
            }
            for i in 0..<keys { cols[i].sort { $0.time < $1.time } }
            previewColumns = cols
            scanStart = []
        }
    }
    private var previewColumns: [[Note]] = []
    private var scanStart: [Int] = []
    private var bodyCursor = 0
    private var headCursor = 0
    private var keyState: [Int8] = []
    var pressedPreview: [Bool] = []
    var bgImage: UIImage? {
        didSet {
            bgCache = nil
            if bounds.width > 0 { relayout() }
        }
    }
    var layout = StageLayout()
    var mods: Mods = []
    var scrollSpeed: Double = 22

    var onPress: ((Int, TimeInterval) -> Void)?
    var onRelease: ((Int, TimeInterval) -> Void)?
    private var touchCol: [ObjectIdentifier: Int] = [:]

    // Camadas
    private let bgLayer = CALayer()
    private let dimLayer = CALayer()
    private let stage = CALayer()
    private let stageBG = CALayer()
    private var lineLayers: [CALayer] = []
    private let stageLeft = SpriteLayer()
    private let stageRight = SpriteLayer()
    private let hintLayer = SpriteLayer()
    private var lightLayers: [SpriteLayer] = []
    private var lightGrad: [CAGradientLayer] = []
    private let bodyContainer = CALayer()
    private let headContainer = CALayer()
    private var bodyPool: [SpriteLayer] = []
    private var headPool: [SpriteLayer] = []
    private var bodyShown = 0
    private var headShown = 0
    private var keyLayers: [SpriteLayer] = []
    private let guideLayer = CALayer()
    private var padLayers: [CALayer] = []
    private let healthBG = CALayer()
    private let healthFill = CALayer()
    private let judgeImage = SpriteLayer()
    private let scoreLabel = UILabel()
    private let accLabel = UILabel()
    private let modsLabel = UILabel()
    private let comboLabel = UILabel()
    private let judgeLabel = UILabel()
    private let fpsLabel = UILabel()
    private var noteCG: [CGColor] = []
    private var bodyCG: [CGColor] = []
    private var keyDownCG: [CGColor] = []
    private let keyUpCG = UIColor(white: 0.12, alpha: 0.85).cgColor

    // Imagens já resolvidas (evita consultar a skin a cada frame)
    private var noteImgs: [[UIImage?]] = []     // [coluna][0 "", 1 H, 2 L, 3 T]
    private var keyImgUp: [UIImage?] = []
    private var keyImgDown: [UIImage?] = []
    private var lightImg: UIImage?
    private var noteAnchor = 0
    private var padBase: CGFloat = 0
    private var padPressed: CGFloat = 0
    private var padFull = true
    private var showJudgeImages = true
    private var bgCache: UIImage?
    private var bgCacheSize: CGSize = .zero

    init(skin: Skin, keys: Int) {
        self.skin = skin
        self.keys = keys
        self.cfg = skin.config(keys: keys)
        super.init(frame: .zero)
        isMultipleTouchEnabled = true
        isOpaque = true
        backgroundColor = .black
        clipsToBounds = true
        buildLayers()
    }
    required init?(coder: NSCoder) { fatalError() }

    // MARK: Montagem das camadas

    private func styleLabel(_ l: UILabel, size: CGFloat, weight: UIFont.Weight, color: UIColor) {
        l.font = .monospacedDigitSystemFont(ofSize: size, weight: weight)
        l.textColor = color
        l.shadowColor = UIColor.black.withAlphaComponent(0.7)
        l.shadowOffset = CGSize(width: 0, height: 1)
        l.isHidden = true
    }

    private func buildLayers() {
        layer.addSublayer(bgLayer)
        dimLayer.backgroundColor = UIColor.black.cgColor
        layer.addSublayer(dimLayer)
        layer.addSublayer(stage)

        stageBG.backgroundColor = UIColor.black.withAlphaComponent(0.55).cgColor
        stage.addSublayer(stageBG)
        for _ in 0...keys {
            let l = CALayer()
            l.backgroundColor = UIColor.white.withAlphaComponent(0.25).cgColor
            stage.addSublayer(l)
            lineLayers.append(l)
        }
        stage.addSublayer(stageLeft)
        stage.addSublayer(stageRight)
        stage.addSublayer(hintLayer)
        for _ in 0..<keys {
            let g = CAGradientLayer()
            g.colors = [UIColor.white.withAlphaComponent(0).cgColor, UIColor.white.withAlphaComponent(0.28).cgColor]
            g.startPoint = CGPoint(x: 0.5, y: 0)
            g.endPoint = CGPoint(x: 0.5, y: 1)
            g.isHidden = true
            stage.addSublayer(g)
            lightGrad.append(g)
            let s = SpriteLayer()
            s.isHidden = true
            stage.addSublayer(s)
            lightLayers.append(s)
        }
        stage.addSublayer(bodyContainer)
        stage.addSublayer(headContainer)
        for _ in 0..<keys {
            let k = SpriteLayer()
            stage.addSublayer(k)
            keyLayers.append(k)
        }
        guideLayer.backgroundColor = UIColor(red: 1, green: 0.25, blue: 0.4, alpha: 1).cgColor
        stage.addSublayer(guideLayer)

        for _ in 0..<keys {
            let p = CALayer()
            p.cornerRadius = 8
            p.isHidden = true
            layer.addSublayer(p)
            padLayers.append(p)
        }
        healthBG.backgroundColor = UIColor.white.withAlphaComponent(0.15).cgColor
        layer.addSublayer(healthBG)
        layer.addSublayer(healthFill)
        judgeImage.isHidden = true
        layer.addSublayer(judgeImage)

        styleLabel(scoreLabel, size: 24, weight: .bold, color: .white)
        styleLabel(accLabel, size: 15, weight: .semibold, color: .white)
        styleLabel(modsLabel, size: 12, weight: .semibold, color: .systemYellow)
        styleLabel(comboLabel, size: 40, weight: .bold, color: .white)
        styleLabel(judgeLabel, size: 22, weight: .bold, color: .white)
        styleLabel(fpsLabel, size: 11, weight: .medium, color: .green)
        for l in [scoreLabel, accLabel, modsLabel, comboLabel, judgeLabel, fpsLabel] { addSubview(l) }
    }

    /// Texto de diagnóstico (FPS). nil esconde.
    func setFPS(_ t: String?) {
        guard let t = t else { fpsLabel.isHidden = true; return }
        fpsLabel.isHidden = false
        if fpsLabel.text != t {
            fpsLabel.text = t
            fpsLabel.sizeToFit()
            fpsLabel.frame.origin = CGPoint(x: safeAreaInsets.left + 66, y: 12)
        }
    }

    private func headLayer(_ i: Int) -> SpriteLayer {
        while headPool.count <= i {
            let l = SpriteLayer()
            l.isHidden = true
            headContainer.addSublayer(l)
            headPool.append(l)
        }
        return headPool[i]
    }

    private func bodyLayer(_ i: Int) -> SpriteLayer {
        while bodyPool.count <= i {
            let l = SpriteLayer()
            l.isHidden = true
            bodyContainer.addSublayer(l)
            bodyPool.append(l)
        }
        return bodyPool[i]
    }

    // MARK: Layout

    override func layoutSubviews() {
        super.layoutSubviews()
        relayout()
    }

    override func safeAreaInsetsDidChange() {
        super.safeAreaInsetsDidChange()
        relayout()
    }

    func reloadSkin(_ s: Skin) {
        skin = s
        relayout()
    }

    func relayout() {
        cfg = skin.config(keys: keys)
        layout = StageLayout.make(size: bounds.size, cfg: cfg, settings: Settings.shared)
        applyStatic()
        frameUpdate()
    }

    private func drawAspectFill(_ img: UIImage, in rect: CGRect) {
        let iw = img.size.width, ih = img.size.height
        guard iw > 0, ih > 0 else { return }
        let s = max(rect.width / iw, rect.height / ih)
        let w = iw * s, h = ih * s
        img.draw(in: CGRect(x: rect.midX - w / 2, y: rect.midY - h / 2, width: w, height: h))
    }

    /// Posiciona tudo o que só muda quando o layout/skin/ajustes mudam.
    private func applyStatic() {
        let L = layout
        guard L.colX.count == keys, bounds.width > 0, bounds.height > 0 else { return }
        let size = bounds.size
        let s = Settings.shared

        CATransaction.begin()
        CATransaction.setDisableActions(true)

        // fundo (redimensionado uma única vez)
        bgLayer.frame = bounds
        if let bg = bgImage {
            if bgCache == nil || bgCacheSize != size {
                bgCache = UIGraphicsImageRenderer(size: size).image { _ in
                    drawAspectFill(bg, in: CGRect(origin: .zero, size: size))
                }
                bgCacheSize = size
            }
            bgLayer.contents = bgCache?.cgImage
        } else {
            bgLayer.contents = nil
        }
        dimLayer.frame = bounds
        dimLayer.backgroundColor = UIColor.black.withAlphaComponent(CGFloat(s.backgroundDim)).cgColor

        // palco (em upscroll vira na vertical; o HUD fica fora e não vira)
        stage.transform = CATransform3DIdentity
        stage.frame = bounds
        if L.upscroll { stage.transform = CATransform3DMakeScale(1, -1, 1) }
        bodyContainer.frame = CGRect(origin: .zero, size: size)
        headContainer.frame = CGRect(origin: .zero, size: size)
        stageBG.frame = CGRect(x: L.left, y: 0, width: L.right - L.left, height: size.height)
        for i in 0...keys {
            let x = i < keys ? L.colX[i] : L.right
            let lw = max(1, i < L.lineW.count ? L.lineW[i] : 1)
            lineLayers[i].frame = CGRect(x: x - lw / 2, y: 0, width: lw, height: size.height)
        }

        let leftImg = skin.stageImage("StageLeft", default: "mania-stage-left", keys: keys)
        stageLeft.setImage(leftImg)
        stageLeft.isHidden = leftImg == nil
        if let img = leftImg, img.size.height > 0 {
            let h = size.height, w = img.size.width / img.size.height * h
            stageLeft.frame = CGRect(x: L.left - w, y: 0, width: w, height: h)
        }
        let rightImg = skin.stageImage("StageRight", default: "mania-stage-right", keys: keys)
        stageRight.setImage(rightImg)
        stageRight.isHidden = rightImg == nil
        if let img = rightImg, img.size.height > 0 {
            let h = size.height, w = img.size.width / img.size.height * h
            stageRight.frame = CGRect(x: L.right, y: 0, width: w, height: h)
        }

        // linha de acerto (a arte é só visual; o julgamento usa sempre hitY)
        let hintShift = CGFloat(s.hintOffset)
        if let hint = skin.stageImage("StageHint", default: "mania-stage-hint", keys: keys), hint.size.width > 0 {
            let w = L.right - L.left
            let h = w * hint.size.height / hint.size.width
            let top: CGFloat
            switch s.hintAnchor {
            case 1: top = L.hitY            // topo da imagem na linha
            case 2: top = L.hitY - h        // base da imagem na linha
            default: top = L.hitY - h / 2   // centro da imagem na linha
            }
            hintLayer.setImage(hint)
            hintLayer.backgroundColor = nil
            hintLayer.frame = CGRect(x: L.left, y: top + hintShift, width: w, height: h)
        } else {
            hintLayer.setImage(nil)
            hintLayer.backgroundColor = UIColor(red: 1, green: 0.35, blue: 0.5, alpha: 0.9).cgColor
            hintLayer.frame = CGRect(x: L.left, y: L.hitY - 1.5 + hintShift, width: L.right - L.left, height: 3)
        }

        // imagens resolvidas uma vez
        let suffixes = ["", "H", "L", "T"]
        var notes: [[UIImage?]] = []
        var up: [UIImage?] = []
        var down: [UIImage?] = []
        for c in 0..<keys {
            notes.append(suffixes.map { skin.noteImage(col: c, keys: keys, suffix: $0) })
            let u = skin.keyImage(col: c, keys: keys, pressed: false)
            up.append(u)
            down.append(skin.keyImage(col: c, keys: keys, pressed: true) ?? u)
        }
        noteImgs = notes
        keyState = [Int8](repeating: -1, count: keys)
        scanStart = []
        noteCG = (0..<keys).map { noteColor($0).cgColor }
        bodyCG = (0..<keys).map { noteColor($0).withAlphaComponent(0.55).cgColor }
        keyDownCG = (0..<keys).map { noteColor($0).withAlphaComponent(0.9).cgColor }
        keyImgUp = up
        keyImgDown = down
        lightImg = skin.stageImage("StageLight", default: "mania-stage-light", keys: keys)

        for c in 0..<keys {
            let r = CGRect(x: L.colX[c], y: L.hitY * 0.45 + hintShift, width: L.colW[c], height: L.hitY * 0.55)
            lightLayers[c].frame = r
            lightLayers[c].setImage(lightImg)
            lightGrad[c].frame = r
        }

        guideLayer.frame = CGRect(x: L.left, y: L.hitY - 1, width: L.right - L.left, height: 2)
        guideLayer.opacity = Float(s.guideLineOpacity / 100)
        guideLayer.isHidden = s.guideLineOpacity <= 0

        // valores de ajustes usados a cada frame (lidos só aqui)
        noteAnchor = s.noteAnchor
        padBase = CGFloat(s.touchPadOpacity / 100)
        padPressed = CGFloat(s.touchPadPressedOpacity / 100)
        padFull = s.touchFullScreen
        showJudgeImages = s.showJudgementImages

        // HUD
        healthBG.frame = CGRect(x: 0, y: 0, width: size.width, height: 4)
        comboLabel.font = .monospacedDigitSystemFont(ofSize: max(30, 40 * L.scale), weight: .bold)
        for l in [scoreLabel, accLabel, modsLabel, comboLabel, judgeLabel] { l.text = nil }

        CATransaction.commit()
    }

    // MARK: Toque

    private func inTouchZone(_ p: CGPoint) -> Bool {
        if padFull { return true }
        return p.y >= layout.touchTop && p.y <= layout.touchBottom
    }

    /// Coluna do toque: em "tela toda" a largura inteira é dividida igualmente.
    private func touchColumn(at x: CGFloat) -> Int {
        if padFull, bounds.width > 0 {
            return max(0, min(keys - 1, Int(x / bounds.width * CGFloat(keys))))
        }
        return layout.column(at: x)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            let p = t.location(in: self)
            guard inTouchZone(p) else { continue }
            let c = touchColumn(at: p.x)
            touchCol[ObjectIdentifier(t)] = c
            onPress?(c, t.timestamp)
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            let id = ObjectIdentifier(t)
            let p = t.location(in: self)
            let old = touchCol[id]
            if !inTouchZone(p) {
                if let o = old {
                    onRelease?(o, t.timestamp)
                    touchCol[id] = nil
                }
                continue
            }
            let c = touchColumn(at: p.x)
            if let o = old {
                if o != c {
                    onRelease?(o, t.timestamp)
                    touchCol[id] = c
                    onPress?(c, t.timestamp)
                }
            } else {
                touchCol[id] = c
                onPress?(c, t.timestamp)
            }
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) { endTouches(touches) }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) { endTouches(touches) }

    private func endTouches(_ touches: Set<UITouch>) {
        for t in touches {
            let id = ObjectIdentifier(t)
            if let c = touchCol[id] { onRelease?(c, t.timestamp) }
            touchCol[id] = nil
        }
    }

    func releaseAllTouches() {
        let t = ProcessInfo.processInfo.systemUptime
        for (_, c) in touchCol { onRelease?(c, t) }
        touchCol.removeAll()
    }

    // MARK: Atualização por frame

    private func noteColor(_ col: Int) -> UIColor {
        switch skin.columnType(col: col, keys: keys) {
        case "1": return UIColor(white: 0.95, alpha: 1)
        case "2": return UIColor(red: 0.45, green: 0.72, blue: 1.0, alpha: 1)
        default: return UIColor(red: 1.0, green: 0.8, blue: 0.3, alpha: 1)
        }
    }

    private func visibility(_ y: CGFloat) -> CGFloat {
        let f = layout.hitY > 0 ? y / layout.hitY : 1
        var a: CGFloat = 1
        if mods.contains(.hidden) { a = min(a, f < 0.55 ? 1 : max(0, 1 - (f - 0.55) / 0.3)) }
        if mods.contains(.fadeIn) { a = min(a, f < 0.35 ? 0 : min(1, (f - 0.35) / 0.25)) }
        return a
    }

    /// Espelha uma posição Y do HUD quando está em upscroll.
    private func hy(_ y: CGFloat) -> CGFloat { layout.upscroll ? bounds.height - y : y }

    private func isDown(_ c: Int, now: Double) -> Bool {
        if let e = engine { return e.isKeyDown(c, now: now) }
        return c < pressedPreview.count ? pressedPreview[c] : false
    }

    /// Chamado a cada frame pelo CADisplayLink: só move camadas.
    func frameUpdate() {
        guard layout.colX.count == keys, bounds.width > 0, keyLayers.count == keys, noteCG.count == keys else { return }
        let now = nowProvider()
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        updateKeys(now: now)
        updateNotes(now: now)
        updatePads(now: now)
        updateHUD(now: now)
        CATransaction.commit()
    }

    private func updateKeys(now: Double) {
        let L = layout
        let H = bounds.height
        if keyState.count != keys { keyState = [Int8](repeating: -1, count: keys) }
        for c in 0..<keys {
            let down = isDown(c, now: now)
            let st: Int8 = down ? 1 : 0
            if keyState[c] == st { continue }
            keyState[c] = st
            let kl = keyLayers[c]
            let img = down ? keyImgDown[c] : keyImgUp[c]
            if let img = img, img.size.width > 0 {
                // proporção natural, colada na borda da tela (não estica com o HitPosition)
                let nh = min(L.colW[c] * img.size.height / img.size.width, H * 0.5)
                kl.setImage(img)
                kl.backgroundColor = nil
                kl.frame = CGRect(x: L.colX[c], y: H - nh, width: L.colW[c], height: nh)
            } else {
                kl.setImage(nil)
                kl.backgroundColor = down ? keyDownCG[c] : keyUpCG
                kl.frame = CGRect(x: L.colX[c] + 1, y: L.hitY, width: max(0, L.colW[c] - 2), height: max(0, H - L.hitY))
            }
            lightLayers[c].isHidden = !(down && lightImg != nil)
            lightGrad[c].isHidden = !(down && lightImg == nil)
        }
    }

    private func noteHeight(_ img: UIImage?, _ w: CGFloat, _ mul: CGFloat) -> CGFloat {
        if let i = img, i.size.width > 0 { return w * i.size.height / i.size.width * mul }
        return w * 0.45 * mul
    }

    private func placeHead(c: Int, x: CGFloat, w: CGFloat, mul: CGFloat, bottom: CGFloat, idx: Int, alpha: CGFloat) {
        let img = noteImgs[c][idx]
        let h = noteHeight(img, w, mul)
        let l = headLayer(headCursor)
        headCursor += 1
        l.isHidden = false
        l.opacity = Float(alpha)
        if let i = img {
            l.setImage(i)
            l.backgroundColor = nil
            l.cornerRadius = 0
            l.frame = CGRect(x: x, y: bottom - h, width: w, height: h)
        } else {
            l.setImage(nil)
            l.backgroundColor = noteCG[c]
            l.cornerRadius = min(6, h / 3)
            l.frame = CGRect(x: x + 2, y: bottom - h + 1, width: max(0, w - 4), height: max(0, h - 2))
        }
    }

    private func placeNote(_ n: Note, c: Int, now: Double, ppm: Double, L: StageLayout, H: CGFloat) {
        guard c < noteImgs.count else { return }
        let imgs = noteImgs[c]
        let x = L.colX[c]
        let w = L.colW[c]
        let mul = L.noteHeightMul

        // qual parte da nota representa o instante do acerto (0 base, 1 centro, 2 topo)
        let refH = noteHeight(n.endTime == nil ? imgs[0] : imgs[1], w, mul)
        let shift: CGFloat = noteAnchor == 1 ? refH / 2 : (noteAnchor == 2 ? refH : 0)
        let headBottom = (n.holding ? L.hitY : L.hitY - CGFloat((n.time - now) * ppm)) + shift

        if let end = n.endTime {
            let tailBottom = L.hitY - CGFloat((end - now) * ppm) + shift
            let hH = noteHeight(imgs[1], w, mul)
            let bodyY = tailBottom - hH / 2
            let bodyH = max(0, headBottom - tailBottom)
            if bodyY + bodyH > 0 && bodyY < H {
                let a = visibility(bodyY + bodyH / 2)
                let l = bodyLayer(bodyCursor)
                bodyCursor += 1
                l.isHidden = false
                if let body = imgs[2] {
                    l.setImage(body)
                    l.backgroundColor = nil
                    l.frame = CGRect(x: x, y: bodyY, width: w, height: bodyH)
                    l.opacity = Float(a * (n.holding ? 1 : 0.9))
                } else {
                    l.setImage(nil)
                    l.backgroundColor = bodyCG[c]
                    l.frame = CGRect(x: x + w * 0.12, y: bodyY, width: w * 0.76, height: bodyH)
                    l.opacity = Float(a)
                }
            }
            if tailBottom > -60 && tailBottom < H + 60 {
                placeHead(c: c, x: x, w: w, mul: mul, bottom: tailBottom, idx: 3, alpha: visibility(tailBottom))
            }
            if headBottom > -60 && headBottom < H + 60 {
                placeHead(c: c, x: x, w: w, mul: mul, bottom: headBottom, idx: 1, alpha: visibility(headBottom))
            }
        } else if headBottom > -60 && headBottom < H + 60 {
            placeHead(c: c, x: x, w: w, mul: mul, bottom: headBottom, idx: 0, alpha: visibility(headBottom))
        }
    }

    private func updateNotes(now: Double) {
        let L = layout
        let H = bounds.height
        let timeRange = 11485.0 / max(1.0, scrollSpeed)
        let ppm = Double(H) / timeRange   // velocidade fixa: não depende do HitPosition
        let behind = 400.0
        let horizon = now + timeRange * 1.1
        bodyCursor = 0
        headCursor = 0
        let cols: [[Note]] = engine?.byColumn ?? previewColumns
        if scanStart.count != keys { scanStart = [Int](repeating: 0, count: keys) }

        for c in 0..<min(keys, cols.count) {
            let col = cols[c]
            var i = scanStart[c]
            while i < col.count {
                let n = col[i]
                if n.done || (n.endTime ?? n.time) < now - behind {
                    // notas já passadas ficam para trás: o próximo frame começa depois delas
                    if i == scanStart[c] { scanStart[c] = i + 1 }
                    i += 1
                    continue
                }
                if n.time > horizon { break }
                placeNote(n, c: c, now: now, ppm: ppm, L: L, H: H)
                i += 1
            }
        }

        // esconde as camadas que sobraram
        if bodyCursor < bodyShown { for i in bodyCursor..<bodyShown { bodyPool[i].isHidden = true } }
        bodyShown = bodyCursor
        if headCursor < headShown { for i in headCursor..<headShown { headPool[i].isHidden = true } }
        headShown = headCursor
    }

    /// Almofadas translúcidas mostrando a zona de toque de cada coluna.
    private func updatePads(now: Double) {
        let L = layout
        if (padBase <= 0 && padPressed <= 0) || L.touchBottom <= L.touchTop {
            for p in padLayers where !p.isHidden { p.isHidden = true }
            return
        }
        for c in 0..<keys {
            let a = isDown(c, now: now) ? padPressed : padBase
            let p = padLayers[c]
            if a <= 0 { p.isHidden = true; continue }
            let r: CGRect
            if padFull {
                let w = bounds.width / CGFloat(keys)
                r = CGRect(x: CGFloat(c) * w, y: 0, width: w, height: bounds.height).insetBy(dx: 2, dy: 2)
            } else {
                r = CGRect(x: L.colX[c], y: L.touchTop, width: L.colW[c], height: L.touchBottom - L.touchTop).insetBy(dx: 2, dy: 2)
            }
            p.frame = r
            p.backgroundColor = noteColor(c).withAlphaComponent(a).cgColor
            p.isHidden = false
        }
    }

    private func setRight(_ l: UILabel, _ t: String, y: CGFloat) {
        l.isHidden = false
        if l.text != t {
            l.text = t
            l.sizeToFit()
            l.frame.origin = CGPoint(x: bounds.width - safeAreaInsets.right - l.bounds.width - 14, y: y)
        }
    }

    private func updateHUD(now: Double) {
        guard let e = engine else {
            healthBG.isHidden = true
            healthFill.isHidden = true
            judgeImage.isHidden = true
            for l in [scoreLabel, accLabel, modsLabel, comboLabel, judgeLabel] { l.isHidden = true }
            return
        }
        let L = layout
        let midX = (L.left + L.right) / 2
        let safeTop = max(safeAreaInsets.top, 8)

        // vida
        healthBG.isHidden = false
        healthFill.isHidden = false
        healthFill.frame = CGRect(x: 0, y: 0, width: bounds.width * CGFloat(e.health), height: 4)
        healthFill.backgroundColor = (e.health > 0.3 ? UIColor.systemGreen : UIColor.systemRed).cgColor

        // pontos / precisão / mods
        setRight(scoreLabel, String(format: "%07d", e.score), y: safeTop + 6)
        setRight(accLabel, String(format: "%.2f%%", e.accuracy * 100), y: safeTop + 34)
        if mods != [] { setRight(modsLabel, mods.acronyms, y: safeTop + 54) }

        // combo
        if e.combo > 1 {
            let t = "\(e.combo)"
            if comboLabel.text != t {
                comboLabel.text = t
                comboLabel.sizeToFit()
            }
            comboLabel.center = CGPoint(x: midX, y: hy(L.hitY * 0.38))
            comboLabel.isHidden = false
        } else {
            comboLabel.isHidden = true
        }

        // julgamento
        if let j = e.lastJudgement {
            let age = now - e.lastJudgementTime
            if age >= 0 && age < 500 {
                let pop = 1 + CGFloat(max(0, 1 - age / 90)) * 0.25
                let alpha = CGFloat(min(1, (500 - age) / 150))
                let y = hy(L.hitY * 0.62)
                if showJudgeImages, let img = skin.judgementImage(j) {
                    judgeLabel.isHidden = true
                    let w = min((L.right - L.left) * 0.8, 220) * pop
                    let h = w * img.size.height / max(1, img.size.width)
                    judgeImage.setImage(img)
                    judgeImage.frame = CGRect(x: midX - w / 2, y: y - h / 2, width: w, height: h)
                    judgeImage.opacity = Float(alpha)
                    judgeImage.isHidden = false
                } else {
                    judgeImage.isHidden = true
                    if judgeLabel.text != j.label {
                        judgeLabel.transform = .identity
                        judgeLabel.text = j.label
                        judgeLabel.textColor = j.color
                        judgeLabel.sizeToFit()
                    }
                    judgeLabel.center = CGPoint(x: midX, y: y)
                    judgeLabel.transform = CGAffineTransform(scaleX: pop, y: pop)
                    judgeLabel.alpha = alpha
                    judgeLabel.isHidden = false
                }
                return
            }
        }
        judgeLabel.isHidden = true
        judgeImage.isHidden = true
    }
}
