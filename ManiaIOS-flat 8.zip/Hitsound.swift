import Foundation
import AVFoundation

/// Toca os hitsounds das skins/beatmaps com baixa latência:
/// todos os sons ficam decodificados na memória e saem por um conjunto de AVAudioPlayerNode.
///
/// Ordem de busca de cada som (ex.: "soft-hitnormal"):
///   1. pasta do beatmap   2. pasta da skin   3. som sintetizado interno (se ligado)
final class HitsoundBank {
    private let engine = AVAudioEngine()
    private var players: [AVAudioPlayerNode] = []
    private var cursor = 0
    private let format: AVAudioFormat
    private var buffers: [String: AVAudioPCMBuffer] = [:]
    private var missing = Set<String>()
    private var defaults: [String: AVAudioPCMBuffer] = [:]
    private let mapFiles: [String: URL]
    private let skinFiles: [String: URL]
    private let useMap: Bool
    private let useSkin: Bool
    private let useDefault: Bool
    private var running = false
    private var configObserver: NSObjectProtocol?

    private static let exts: Set<String> = ["wav", "mp3", "aif", "aiff", "caf", "m4a", "aac"]

    init(beatmapDir: URL?, skinDir: URL?) {
        format = AVAudioFormat(standardFormatWithSampleRate: 44100, channels: 2)!
        let s = Settings.shared
        useMap = s.useBeatmapSamples
        useSkin = s.useSkinSamples
        useDefault = s.useDefaultSamples
        mapFiles = s.useBeatmapSamples ? HitsoundBank.index(beatmapDir) : [:]
        skinFiles = s.useSkinSamples ? HitsoundBank.index(skinDir) : [:]
    }

    deinit { stop() }

    /// nome em minúsculas (sem extensão) -> arquivo. Ignora maiúsculas/minúsculas.
    private static func index(_ dir: URL?) -> [String: URL] {
        guard let dir = dir else { return [:] }
        let items = (try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil)) ?? []
        var map: [String: URL] = [:]
        for u in items {
            guard exts.contains(u.pathExtension.lowercased()) else { continue }
            let name = u.deletingPathExtension().lastPathComponent.lowercased()
            if let old = map[name], old.pathExtension.lowercased() == "wav" { continue }
            map[name] = u
        }
        return map
    }

    // MARK: Ciclo de vida

    func start() {
        guard !running else { return }
        for _ in 0..<24 {
            let p = AVAudioPlayerNode()
            engine.attach(p)
            engine.connect(p, to: engine.mainMixerNode, format: format)
            players.append(p)
        }
        applyVolume()
        engine.prepare()
        do { try engine.start() } catch { return }
        for p in players { p.play() }
        running = true
        configObserver = NotificationCenter.default.addObserver(
            forName: .AVAudioEngineConfigurationChange, object: engine, queue: .main) { [weak self] _ in
            guard let self = self else { return }
            try? self.engine.start()
            for p in self.players { p.play() }
        }
    }

    func stop() {
        guard running else { return }
        running = false
        if let o = configObserver { NotificationCenter.default.removeObserver(o) }
        configObserver = nil
        for p in players { p.stop() }
        engine.stop()
    }

    func applyVolume() {
        let s = Settings.shared
        engine.mainMixerNode.outputVolume = Float(s.masterVolume * s.hitsoundVolume / 10000.0)
    }

    // MARK: Nomes dos sons de uma nota

    private static func setName(_ n: Int) -> String {
        switch n {
        case 2: return "soft"
        case 3: return "drum"
        default: return "normal"
        }
    }

    /// (nome do arquivo, tipo) de cada som que a nota toca.
    private func sounds(for s: SampleInfo) -> [(String, String)] {
        if !s.file.isEmpty {
            let n = (s.file as NSString).deletingPathExtension
            return [(n, "custom")]
        }
        let suffix = s.index > 1 ? String(s.index) : ""
        let nset = HitsoundBank.setName(s.normalSet)
        let aset = HitsoundBank.setName(s.addSet == 0 ? s.normalSet : s.addSet)
        var out: [(String, String)] = [("\(nset)-hitnormal\(suffix)", "hitnormal")]
        if s.hitSound & 2 != 0 { out.append(("\(aset)-hitwhistle\(suffix)", "hitwhistle")) }
        if s.hitSound & 4 != 0 { out.append(("\(aset)-hitfinish\(suffix)", "hitfinish")) }
        if s.hitSound & 8 != 0 { out.append(("\(aset)-hitclap\(suffix)", "hitclap")) }
        return out
    }

    // MARK: Carregamento

    private func buffer(named name: String, kind: String) -> AVAudioPCMBuffer? {
        let key = name.lowercased()
        if let b = buffers[key] { return b }
        if missing.contains(key) { return nil }

        var url: URL? = mapFiles[key]
        if url == nil { url = skinFiles[key] }
        var buf: AVAudioPCMBuffer?
        if let u = url { buf = loadBuffer(u) }

        // sem o sample indexado (ex.: "normal-hitnormal2"), usa o sem número
        if buf == nil {
            let trimmed = key.trimmingCharacters(in: CharacterSet.decimalDigits)
            if trimmed != key, !trimmed.isEmpty { buf = buffer(named: trimmed, kind: kind) }
        }
        if buf == nil && useDefault && kind != "custom" { buf = defaultBuffer(kind) }

        if let b = buf { buffers[key] = b } else { missing.insert(key) }
        return buf
    }

    private func loadBuffer(_ url: URL) -> AVAudioPCMBuffer? {
        guard let file = try? AVAudioFile(forReading: url) else { return nil }
        let inFmt = file.processingFormat
        let frames = AVAudioFrameCount(file.length)
        guard frames > 0, Double(frames) < inFmt.sampleRate * 8 else { return nil }
        guard let inBuf = AVAudioPCMBuffer(pcmFormat: inFmt, frameCapacity: frames) else { return nil }
        do { try file.read(into: inBuf) } catch { return nil }

        if inFmt.sampleRate == format.sampleRate && inFmt.channelCount == format.channelCount
            && inFmt.commonFormat == format.commonFormat {
            return inBuf
        }
        guard let conv = AVAudioConverter(from: inFmt, to: format) else { return nil }
        let ratio = format.sampleRate / inFmt.sampleRate
        let cap = AVAudioFrameCount(Double(frames) * ratio) + 1024
        guard let out = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: cap) else { return nil }
        var consumed = false
        var err: NSError?
        let status = conv.convert(to: out, error: &err) { _, outStatus in
            if consumed {
                outStatus.pointee = .endOfStream
                return nil
            }
            consumed = true
            outStatus.pointee = .haveData
            return inBuf
        }
        if status == .error || out.frameLength == 0 { return nil }
        return out
    }

    /// Carrega antes da música começar, para não haver engasgo no primeiro acerto.
    func preload(_ objects: [HitObject]) {
        var seen = Set<String>()
        for o in objects {
            let s = o.sample
            let k = "\(s.normalSet)|\(s.addSet)|\(s.index)|\(s.hitSound & 14)|\(s.file)"
            if !seen.insert(k).inserted { continue }
            for (n, kind) in sounds(for: s) { _ = buffer(named: n, kind: kind) }
        }
    }

    // MARK: Reprodução

    func play(_ s: SampleInfo) {
        guard running else { return }
        for (n, kind) in sounds(for: s) {
            if let b = buffer(named: n, kind: kind) { fire(b, volume: s.volume) }
        }
    }

    private func fire(_ buf: AVAudioPCMBuffer, volume: Int) {
        let p = players[cursor]
        cursor = (cursor + 1) % players.count
        p.volume = Float(max(1, min(100, volume))) / 100.0
        p.scheduleBuffer(buf, at: nil, options: .interrupts, completionHandler: nil)
        if !p.isPlaying { p.play() }
    }

    // MARK: Sons internos (usados quando a skin/beatmap não traz o arquivo)

    private func defaultBuffer(_ kind: String) -> AVAudioPCMBuffer? {
        if let b = defaults[kind] { return b }
        let sr = 44100.0
        let dur: Double
        switch kind {
        case "hitwhistle": dur = 0.22
        case "hitfinish": dur = 0.45
        case "hitclap": dur = 0.16
        default: dur = 0.12
        }
        let n = AVAudioFrameCount(sr * dur)
        guard let buf = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: n),
              let ch = buf.floatChannelData else { return nil }
        buf.frameLength = n
        var seed: UInt32 = 12345
        var prev: Double = 0
        for i in 0..<Int(n) {
            let t = Double(i) / sr
            seed = seed &* 1664525 &+ 1013904223
            let noise: Double = Double(seed >> 8) / Double(1 << 24) * 2.0 - 1.0
            var v: Double
            switch kind {
            case "hitwhistle":
                let freq: Double = 2200.0 + 500.0 * t
                v = sin(2.0 * Double.pi * freq * t) * exp(-t * 14.0) * 0.35
            case "hitfinish":
                let hp: Double = noise - prev
                prev = noise
                v = hp * exp(-t * 8.0) * 0.45
            case "hitclap":
                var burst: Double = exp(-t * 60.0)
                if t > 0.015 { burst += 0.7 * exp(-(t - 0.015) * 60.0) }
                v = noise * burst * 0.5
            default:
                let tone: Double = sin(2.0 * Double.pi * 1100.0 * t) * exp(-t * 55.0) * 0.5
                let click: Double = noise * exp(-t * 220.0) * 0.3
                v = tone + click
            }
            let f = Float(max(-1.0, min(1.0, v)))
            ch[0][i] = f
            ch[1][i] = f
        }
        defaults[kind] = buf
        return buf
    }

    // MARK: Teste (tela de opções)

    private static var testBank: HitsoundBank?

    /// Toca um acerto de exemplo com a skin ativa e os volumes atuais.
    static func playTest() {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback)
        try? session.setActive(true)
        testBank?.stop()
        let bank = HitsoundBank(beatmapDir: nil, skinDir: Skin.loadActive().dir)
        bank.start()
        testBank = bank
        var s = SampleInfo()
        s.normalSet = 1
        s.addSet = 1
        s.volume = 100
        bank.play(s)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
            var c = SampleInfo()
            c.hitSound = 8
            c.normalSet = 1
            c.addSet = 1
            c.volume = 100
            bank.play(c)
        }
    }
}
