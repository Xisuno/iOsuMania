import UIKit
import AVFoundation

// MARK: - Prévia de áudio ao selecionar (como no osu!)

final class PreviewPlayer {
    static let shared = PreviewPlayer()
    private var player: AVAudioPlayer?
    private var token = 0

    func play(_ info: BeatmapInfo) {
        guard Settings.shared.songPreview else { stop(); return }
        token += 1
        let t = token
        let url = info.audioURL
        let start: Double = info.previewTime > 0 ? Double(info.previewTime) / 1000.0 : max(0, info.lengthMs / 1000.0 * 0.4)
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let p = try? AVAudioPlayer(contentsOf: url)
            p?.prepareToPlay()
            DispatchQueue.main.async {
                guard let self = self, t == self.token, let p = p else { return }
                self.player?.stop()
                let s = Settings.shared
                try? AVAudioSession.sharedInstance().setCategory(.playback)
                try? AVAudioSession.sharedInstance().setActive(true)
                p.currentTime = min(start, max(0, p.duration - 1))
                p.volume = 0
                p.play()
                p.setVolume(Float(s.masterVolume * s.musicVolume / 10000.0), fadeDuration: 0.6)
                self.player = p
            }
        }
    }

    func stop() {
        token += 1
        player?.stop()
        player = nil
    }
}

// MARK: - Modelo da lista

private struct VSet {
    var set: BeatmapSet
    var diffs: [BeatmapInfo]
}

private enum SongRow {
    case set(Int)
    case diff(Int, Int)
}

// MARK: - Célula em formato de cartão

final class SongCardCell: UITableViewCell {
    private let card = UIView()
    private let stripe = UIView()
    private let titleLabel = UILabel()
    private let subLabel = UILabel()
    private let tagLabel = UILabel()
    private var leadingC: NSLayoutConstraint!

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        selectionStyle = .none

        card.layer.cornerRadius = 12
        card.layer.borderWidth = 2
        card.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(card)

        stripe.layer.cornerRadius = 2
        stripe.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(stripe)

        titleLabel.font = .systemFont(ofSize: 16, weight: .bold)
        titleLabel.textColor = .white
        subLabel.font = .systemFont(ofSize: 12, weight: .regular)
        subLabel.textColor = UIColor(white: 1, alpha: 0.65)
        tagLabel.font = .systemFont(ofSize: 12, weight: .bold)
        tagLabel.textAlignment = .right
        tagLabel.setContentHuggingPriority(.required, for: .horizontal)
        tagLabel.setContentCompressionResistancePriority(.required, for: .horizontal)

        let texts = UIStackView(arrangedSubviews: [titleLabel, subLabel])
        texts.axis = .vertical
        texts.spacing = 2
        let row = UIStackView(arrangedSubviews: [texts, tagLabel])
        row.axis = .horizontal
        row.spacing = 8
        row.alignment = .center
        row.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(row)

        leadingC = card.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 6)
        NSLayoutConstraint.activate([
            leadingC,
            card.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -4),
            card.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 3),
            card.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -3),
            stripe.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 6),
            stripe.topAnchor.constraint(equalTo: card.topAnchor, constant: 8),
            stripe.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -8),
            stripe.widthAnchor.constraint(equalToConstant: 4),
            row.leadingAnchor.constraint(equalTo: stripe.trailingAnchor, constant: 10),
            row.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -12),
            row.centerYAnchor.constraint(equalTo: card.centerYAnchor),
        ])
    }
    required init?(coder: NSCoder) { fatalError() }

    func configure(title: NSAttributedString, subtitle: String, tag: NSAttributedString?,
                   selected: Bool, indent: CGFloat, stripeColor: UIColor) {
        titleLabel.attributedText = title
        subLabel.text = subtitle
        tagLabel.attributedText = tag
        leadingC.constant = 6 + indent
        stripe.backgroundColor = stripeColor
        card.backgroundColor = selected ? Theme.pink.withAlphaComponent(0.38) : Theme.card
        card.layer.borderColor = selected ? Theme.pink.cgColor : UIColor.clear.cgColor
    }
}

// MARK: - Tela de seleção

final class SongSelectViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate {
    private var allSets: [BeatmapSet] = []
    private var visible: [VSet] = []
    private var rows: [SongRow] = []
    private var expandedDir: String?
    private var selected: BeatmapInfo?
    private var loading = true

    // interface
    private let bg = BackgroundView(dim: 0.5)
    private let table = UITableView(frame: .zero, style: .plain)
    private let search = UITextField()
    private let filterSeg = UISegmentedControl(items: ["Todos", "4K", "5K", "6K", "7K+"])
    private let sortButton = UIButton(type: .system)
    private let spinner = UIActivityIndicatorView(style: .large)
    private let emptyLabel = UILabel()
    private let titleLabel = UILabel()
    private let artistLabel = UILabel()
    private let creatorLabel = UILabel()
    private let statsLabel = UILabel()
    private let statsLabel2 = UILabel()
    private let diffBar = UIProgressView(progressViewStyle: .bar)
    private let gradeLabel = UILabel()
    private let bestLabel = UILabel()
    private let bestDetail = UILabel()
    private let modsButton = PillButton(title: "Mods", color: Theme.purple, fontSize: 15)

    private let filterValues = [0, 4, 5, 6, 7]
    private let sortNames = ["Título", "Artista", "Recentes"]

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }
    override var prefersStatusBarHidden: Bool { true }

    // MARK: Montagem

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = Theme.base
        buildUI()
        filterSeg.selectedSegmentIndex = filterValues.firstIndex(of: Settings.shared.keyFilter) ?? 0
        refreshSortTitle()
        reload()
    }

    private func label(_ l: UILabel, size: CGFloat, weight: UIFont.Weight, color: UIColor = .white, lines: Int = 1) {
        l.font = .systemFont(ofSize: size, weight: weight)
        l.textColor = color
        l.numberOfLines = lines
    }

    private func buildUI() {
        view.addSubview(bg)
        let safe = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            bg.topAnchor.constraint(equalTo: view.topAnchor), bg.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            bg.leadingAnchor.constraint(equalTo: view.leadingAnchor), bg.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])

        // --- barra inferior ---
        let back = PillButton(title: "◀  Voltar", color: Theme.pinkDeep, fontSize: 15)
        let random = PillButton(title: "Aleatório", color: Theme.teal, fontSize: 15)
        let add = PillButton(title: "Importar", color: Theme.blue, fontSize: 15)
        let play = PillButton(title: "Jogar  ▶", color: Theme.pink, fontSize: 19)
        back.addAction(UIAction { [weak self] _ in self?.goBack() }, for: .touchUpInside)
        random.addAction(UIAction { [weak self] _ in self?.pickRandom() }, for: .touchUpInside)
        add.addAction(UIAction { [weak self] _ in self?.importTapped() }, for: .touchUpInside)
        play.addAction(UIAction { [weak self] _ in self?.startGame() }, for: .touchUpInside)
        modsButton.addAction(UIAction { [weak self] _ in self?.openMods() }, for: .touchUpInside)
        let spacer = UIView()
        let bar = UIStackView(arrangedSubviews: [back, modsButton, random, add, spacer, play])
        bar.axis = .horizontal
        bar.spacing = 10
        bar.alignment = .fill
        bar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bar)

        // --- painel esquerdo ---
        let panel = UIView()
        panel.backgroundColor = Theme.panel
        panel.layer.cornerRadius = 18
        panel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(panel)

        label(titleLabel, size: 22, weight: .heavy, lines: 2)
        label(artistLabel, size: 15, weight: .semibold, color: Theme.pink, lines: 1)
        label(creatorLabel, size: 12, weight: .regular, color: UIColor(white: 1, alpha: 0.6), lines: 1)
        label(statsLabel, size: 13, weight: .semibold, lines: 1)
        label(statsLabel2, size: 12, weight: .regular, color: UIColor(white: 1, alpha: 0.7), lines: 1)
        diffBar.trackTintColor = UIColor(white: 1, alpha: 0.15)
        diffBar.translatesAutoresizingMaskIntoConstraints = false
        diffBar.heightAnchor.constraint(equalToConstant: 6).isActive = true
        bestLabel.text = "MELHOR RESULTADO"
        label(bestLabel, size: 10, weight: .heavy, color: UIColor(white: 1, alpha: 0.5))
        gradeLabel.font = .systemFont(ofSize: 44, weight: .heavy)
        gradeLabel.textAlignment = .center
        gradeLabel.setContentHuggingPriority(.required, for: .horizontal)
        label(bestDetail, size: 12, weight: .semibold, color: UIColor(white: 1, alpha: 0.85), lines: 3)

        let gradeRow = UIStackView(arrangedSubviews: [gradeLabel, bestDetail])
        gradeRow.axis = .horizontal
        gradeRow.spacing = 12
        gradeRow.alignment = .center
        let info = UIStackView(arrangedSubviews: [titleLabel, artistLabel, creatorLabel, statsLabel, statsLabel2,
                                                  diffBar, bestLabel, gradeRow])
        info.axis = .vertical
        info.spacing = 5
        info.setCustomSpacing(10, after: creatorLabel)
        info.setCustomSpacing(10, after: diffBar)
        info.translatesAutoresizingMaskIntoConstraints = false
        panel.addSubview(info)

        // --- lado direito: busca + filtros + lista ---
        search.placeholder = "Buscar título, artista, mapper…"
        search.attributedPlaceholder = NSAttributedString(string: "Buscar título, artista, mapper…",
                                                          attributes: [.foregroundColor: UIColor(white: 1, alpha: 0.4)])
        search.textColor = .white
        search.font = .systemFont(ofSize: 14)
        search.backgroundColor = UIColor(white: 0, alpha: 0.5)
        search.layer.cornerRadius = 10
        search.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: 10))
        search.leftViewMode = .always
        search.clearButtonMode = .whileEditing
        search.returnKeyType = .done
        search.autocorrectionType = .no
        search.autocapitalizationType = .none
        search.delegate = self
        search.addTarget(self, action: #selector(filtersChanged), for: .editingChanged)
        search.translatesAutoresizingMaskIntoConstraints = false
        search.heightAnchor.constraint(equalToConstant: 34).isActive = true

        sortButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .bold)
        sortButton.setTitleColor(.white, for: .normal)
        sortButton.backgroundColor = UIColor(white: 1, alpha: 0.15)
        sortButton.layer.cornerRadius = 10
        sortButton.contentEdgeInsets = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        sortButton.addTarget(self, action: #selector(cycleSort), for: .touchUpInside)

        filterSeg.addTarget(self, action: #selector(filtersChanged), for: .valueChanged)
        filterSeg.selectedSegmentTintColor = Theme.pink
        filterSeg.setTitleTextAttributes([.foregroundColor: UIColor.white], for: .normal)
        filterSeg.setTitleTextAttributes([.foregroundColor: UIColor.white], for: .selected)

        let topRow = UIStackView(arrangedSubviews: [search, sortButton])
        topRow.axis = .horizontal
        topRow.spacing = 8
        let header = UIStackView(arrangedSubviews: [topRow, filterSeg])
        header.axis = .vertical
        header.spacing = 8
        header.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(header)

        table.backgroundColor = .clear
        table.separatorStyle = .none
        table.dataSource = self
        table.delegate = self
        table.showsVerticalScrollIndicator = false
        table.keyboardDismissMode = .onDrag
        table.register(SongCardCell.self, forCellReuseIdentifier: "card")
        table.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(table)

        spinner.color = .white
        spinner.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(spinner)

        emptyLabel.text = "Nenhum beatmap encontrado.\nToque em “Importar” para adicionar um .osz\nou coloque os arquivos em Arquivos › ManiaIOS › Songs."
        label(emptyLabel, size: 14, weight: .medium, color: UIColor(white: 1, alpha: 0.7), lines: 0)
        emptyLabel.textAlignment = .center
        emptyLabel.isHidden = true
        emptyLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(emptyLabel)

        NSLayoutConstraint.activate([
            bar.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 16),
            bar.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -16),
            bar.bottomAnchor.constraint(equalTo: safe.bottomAnchor, constant: -10),

            panel.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 16),
            panel.topAnchor.constraint(equalTo: safe.topAnchor, constant: 12),
            panel.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.38),
            panel.bottomAnchor.constraint(lessThanOrEqualTo: bar.topAnchor, constant: -12),
            info.topAnchor.constraint(equalTo: panel.topAnchor, constant: 16),
            info.bottomAnchor.constraint(equalTo: panel.bottomAnchor, constant: -16),
            info.leadingAnchor.constraint(equalTo: panel.leadingAnchor, constant: 16),
            info.trailingAnchor.constraint(equalTo: panel.trailingAnchor, constant: -16),

            header.topAnchor.constraint(equalTo: safe.topAnchor, constant: 12),
            header.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -16),
            header.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.52),
            table.topAnchor.constraint(equalTo: header.bottomAnchor, constant: 8),
            table.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -10),
            table.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.54),
            table.bottomAnchor.constraint(equalTo: bar.topAnchor, constant: -8),

            spinner.centerXAnchor.constraint(equalTo: table.centerXAnchor),
            spinner.centerYAnchor.constraint(equalTo: table.centerYAnchor),
            emptyLabel.centerXAnchor.constraint(equalTo: table.centerXAnchor),
            emptyLabel.centerYAnchor.constraint(equalTo: table.centerYAnchor),
            emptyLabel.widthAnchor.constraint(equalTo: table.widthAnchor, constant: -30),
        ])
    }

    // MARK: Ciclo de vida

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
        refreshModsTitle()
        if !loading { updateInfo() }
        table.reloadData()
        if let s = selected { PreviewPlayer.shared.play(s) }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
        PreviewPlayer.shared.stop()
    }

    private func refreshModsTitle() {
        let m = Settings.shared.mods
        modsButton.setTitle(m == [] ? "Mods" : "Mods · \(m.acronyms)", for: .normal)
    }

    private func reload() {
        loading = true
        spinner.startAnimating()
        emptyLabel.isHidden = true
        Library.loadSets { [weak self] sets in
            guard let self = self else { return }
            self.allSets = sets
            self.loading = false
            self.spinner.stopAnimating()
            self.applyFilters(restore: true)
        }
    }

    // MARK: Filtros e ordenação

    @objc private func filtersChanged() {
        Settings.shared.keyFilter = filterValues[max(0, filterSeg.selectedSegmentIndex)]
        applyFilters(restore: false)
    }

    @objc private func cycleSort() {
        Settings.shared.sortMode = (Settings.shared.sortMode + 1) % sortNames.count
        refreshSortTitle()
        applyFilters(restore: false)
    }

    private func refreshSortTitle() {
        sortButton.setTitle("Ordenar: \(sortNames[Settings.shared.sortMode])", for: .normal)
    }

    private func matchesKeys(_ info: BeatmapInfo) -> Bool {
        let f = Settings.shared.keyFilter
        if f == 0 { return true }
        return f == 7 ? info.keys >= 7 : info.keys == f
    }

    private func matchesText(_ set: BeatmapSet, _ info: BeatmapInfo, _ q: String) -> Bool {
        let opts: String.CompareOptions = [.caseInsensitive, .diacriticInsensitive]
        return set.title.range(of: q, options: opts) != nil
            || set.artist.range(of: q, options: opts) != nil
            || set.creator.range(of: q, options: opts) != nil
            || info.version.range(of: q, options: opts) != nil
    }

    private func applyFilters(restore: Bool) {
        let q = (search.text ?? "").trimmingCharacters(in: .whitespaces)
        var list: [VSet] = []
        for s in allSets {
            let d = s.diffs.filter { matchesKeys($0) && (q.isEmpty || matchesText(s, $0, q)) }
            if !d.isEmpty { list.append(VSet(set: s, diffs: d)) }
        }
        switch Settings.shared.sortMode {
        case 1: list.sort { $0.set.artist.localizedCaseInsensitiveCompare($1.set.artist) == .orderedAscending }
        case 2: list.sort { $0.set.addedAt > $1.set.addedAt }
        default: list.sort { $0.set.title.localizedCaseInsensitiveCompare($1.set.title) == .orderedAscending }
        }
        visible = list

        if restore, let key = Settings.shared.lastMapKey,
           let found = list.flatMap({ $0.diffs }).first(where: { $0.key == key }) {
            selected = found
        }
        // mantém a seleção se ainda estiver visível; senão escolhe o primeiro
        if let s = selected, !list.contains(where: { $0.diffs.contains { $0.key == s.key } }) { selected = nil }
        if selected == nil, let first = list.first?.diffs.first { selected = first }
        expandedDir = selected?.dirName

        rebuildRows()
        emptyLabel.isHidden = !(allSets.isEmpty && !loading)
        if let s = selected { didSelect(s, scroll: restore, startPreview: restore) } else { updateInfo() }
    }

    private func rebuildRows() {
        var r: [SongRow] = []
        for (i, vs) in visible.enumerated() {
            r.append(.set(i))
            if vs.set.dirName == expandedDir {
                for d in 0..<vs.diffs.count { r.append(.diff(i, d)) }
            }
        }
        rows = r
        table.reloadData()
    }

    // MARK: Seleção

    private func didSelect(_ info: BeatmapInfo, scroll: Bool, startPreview: Bool) {
        let changedSet = expandedDir != info.dirName
        let changedMap = selected?.key != info.key
        selected = info
        Settings.shared.lastMapKey = info.key
        if changedSet {
            expandedDir = info.dirName
            rebuildRows()
        } else {
            table.reloadData()
        }
        updateInfo()
        if changedMap || startPreview { PreviewPlayer.shared.play(info) }
        if scroll || changedSet, let ip = indexPath(of: info) {
            table.scrollToRow(at: ip, at: .middle, animated: true)
        }
    }

    private func indexPath(of info: BeatmapInfo) -> IndexPath? {
        for (n, r) in rows.enumerated() {
            if case let .diff(si, di) = r, visible[si].diffs[di].key == info.key { return IndexPath(row: n, section: 0) }
        }
        return nil
    }

    private func updateInfo() {
        guard let m = selected else {
            titleLabel.text = loading ? "Carregando…" : "Selecione um beatmap"
            artistLabel.text = ""
            creatorLabel.text = ""
            statsLabel.text = ""
            statsLabel2.text = ""
            diffBar.progress = 0
            gradeLabel.text = ""
            bestDetail.text = ""
            bestLabel.isHidden = true
            bg.set(BackgroundStore.current(), animated: false)
            return
        }
        titleLabel.text = m.title
        artistLabel.text = m.artist
        creatorLabel.text = "[\(m.version)]  ·  mapa de \(m.creator)"
        let secs = Int(m.lengthMs / 1000)
        statsLabel.text = String(format: "%dK   ·   %.0f BPM   ·   %d:%02d", m.keys, m.bpm, secs / 60, secs % 60)
        statsLabel2.text = String(format: "%d notas   ·   %.1f notas/s   ·   OD %.1f", m.count, m.nps, m.od)
        diffBar.progressTintColor = Theme.difficultyColor(nps: m.nps)
        diffBar.progress = Float(min(1, m.nps / 12.0))

        bestLabel.isHidden = false
        if let r = Records.best(m.key) {
            gradeLabel.text = r.grade
            gradeLabel.textColor = Theme.gradeColor(r.grade)
            bestDetail.text = String(format: "%07d\n%.2f%%  ·  %dx\nJogadas: %d", r.score, r.accuracy * 100, r.maxCombo, Records.plays(m.key))
        } else {
            gradeLabel.text = "–"
            gradeLabel.textColor = UIColor(white: 1, alpha: 0.3)
            bestDetail.text = "Ainda sem resultado\nJogadas: \(Records.plays(m.key))"
        }

        // fundo do mapa (carregado fora da thread principal)
        let key = m.key
        if let u = m.bgURL {
            ImageLoader.load(u, maxSide: 1600) { [weak self] img in
                guard let self = self, self.selected?.key == key else { return }
                self.bg.set(img ?? BackgroundStore.current())
            }
        } else {
            bg.set(BackgroundStore.current())
        }
    }

    // MARK: Ações

    private func goBack() {
        navigationController?.popViewController(animated: true)
    }

    private func openMods() {
        navigationController?.pushViewController(ModsViewController(), animated: true)
    }

    private func importTapped() {
        ImportUI.importArchives(from: self) { [weak self] in self?.reload() }
    }

    private func pickRandom() {
        let all = visible.flatMap { $0.diffs }
        guard let pick = all.randomElement() else { return }
        didSelect(pick, scroll: true, startPreview: true)
    }

    private func startGame() {
        guard let info = selected else { return }
        guard let map = info.load() else {
            showAlert("Não foi possível abrir", "O arquivo do mapa está inválido ou foi removido.")
            return
        }
        view.endEditing(true)
        present(GameViewController(map: map, mods: Settings.shared.mods), animated: true)
    }

    // MARK: Tabela

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { rows.count }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if case .set = rows[indexPath.row] { return 66 }
        return 54
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "card", for: indexPath) as! SongCardCell
        switch rows[indexPath.row] {
        case let .set(i):
            let vs = visible[i]
            let isOpen = vs.set.dirName == expandedDir
            let title = NSAttributedString(string: vs.set.title, attributes: [
                .font: UIFont.systemFont(ofSize: 16, weight: .bold), .foregroundColor: UIColor.white])
            // bolinhas coloridas, uma por dificuldade
            let dots = NSMutableAttributedString()
            for d in vs.diffs.prefix(8) {
                dots.append(NSAttributedString(string: "● ", attributes: [
                    .font: UIFont.systemFont(ofSize: 11), .foregroundColor: Theme.difficultyColor(nps: d.nps)]))
            }
            cell.configure(title: title, subtitle: "\(vs.set.artist)  ·  mapa de \(vs.set.creator)", tag: dots,
                           selected: isOpen, indent: 0, stripeColor: Theme.pink)
        case let .diff(si, di):
            let d = visible[si].diffs[di]
            let color = Theme.difficultyColor(nps: d.nps)
            let t = NSMutableAttributedString(string: "\(d.keys)K  ", attributes: [
                .font: UIFont.systemFont(ofSize: 14, weight: .heavy), .foregroundColor: color])
            t.append(NSAttributedString(string: d.version, attributes: [
                .font: UIFont.systemFont(ofSize: 15, weight: .semibold), .foregroundColor: UIColor.white]))
            var tag: NSAttributedString?
            if let r = Records.best(d.key) {
                tag = NSAttributedString(string: r.grade, attributes: [
                    .font: UIFont.systemFont(ofSize: 18, weight: .heavy), .foregroundColor: Theme.gradeColor(r.grade)])
            }
            cell.configure(title: t, subtitle: String(format: "%.1f notas/s  ·  %.0f BPM  ·  %d notas", d.nps, d.bpm, d.count),
                           tag: tag, selected: selected?.key == d.key, indent: 26, stripeColor: color)
        }
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        switch rows[indexPath.row] {
        case let .set(i):
            let vs = visible[i]
            var pick = vs.diffs[0]
            if let key = Settings.shared.lastMapKey, let m = vs.diffs.first(where: { $0.key == key }) { pick = m }
            didSelect(pick, scroll: true, startPreview: false)
        case let .diff(si, di):
            let d = visible[si].diffs[di]
            if selected?.key == d.key {
                startGame()           // tocar de novo no mapa selecionado inicia o jogo
            } else {
                didSelect(d, scroll: false, startPreview: false)
            }
        }
    }

    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        guard case let .set(i) = rows[indexPath.row] else { return nil }
        let set = visible[i].set
        let del = UIContextualAction(style: .destructive, title: "Apagar") { [weak self] _, _, done in
            guard let self = self else { done(false); return }
            let a = UIAlertController(title: "Apagar “\(set.title)”?", message: "Todas as dificuldades deste beatmap serão removidas.", preferredStyle: .alert)
            a.addAction(UIAlertAction(title: "Cancelar", style: .cancel) { _ in done(false) })
            a.addAction(UIAlertAction(title: "Apagar", style: .destructive) { _ in
                if self.selected?.dirName == set.dirName { self.selected = nil; PreviewPlayer.shared.stop() }
                try? FileManager.default.removeItem(at: set.dirURL)
                done(true)
                self.reload()
            })
            self.present(a, animated: true)
        }
        return UISwipeActionsConfiguration(actions: [del])
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
