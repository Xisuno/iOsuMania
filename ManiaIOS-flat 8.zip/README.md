# ManiaIOS – osu!mania-like para iOS (Swift/UIKit, sem dependências)

## Gerar o .ipa (sem assinatura)
Precisa de macOS + Xcode (swiftc), ou use o GitHub Actions:
- Mac: `./build_ipa.sh` → `build/ManiaIOS.ipa`
- GitHub: suba esta pasta num repositório → aba Actions → "Build IPA" → baixe o artifact.
Instale com Sideloadly / AltStore / TrollStore (eles assinam por você).

## Recursos
- Menu: Jogar, Mods, Layout & skin.ini, Skins, Importar, Configurações & fundo
- Importa .osz (mapas osu!mania 4K–10K) e .osk (skins); também pelo app Arquivos (pasta ManiaIOS/Songs e /Skins)
- Fundo: galeria ou Arquivos; escurecimento; fundo do beatmap opcional
- Layout: largura das colunas, altura das notas, HitPosition, deslocamento do palco (por cima da skin)
  + gravação direta no skin.ini (ColumnWidth, HitPosition) e editor de texto do skin.ini
- Desempenho: renderização por camadas na GPU (Core Animation), imagens da skin pré-carregadas e limitadas a 1024px, ini lido uma vez, fundo pré-renderizado
- Linha de acerto: velocidade independente do HitPosition, alinhamento nota/hint ajustável, linha-guia
- Orientação: somente horizontal; FPS opcional em Configurações (diagnóstico)
- Toque: zona de toque (altura/posição) e opacidade das almofadas por coluna
- Upscroll: segue UpsideDown do skin.ini ou força Down/Up no app
- Skin: lê mania-note1/2/S(H/L/T), mania-key*, stage-*, hit300/200/100/50/0, NoteImageN, KeyImageN etc.
- Mods: EZ NF HT HR DT SD PF MR RD HD FI NLN AT
- Mapa demo embutido (4K e 7K) para testar de imediato
