import UIKit

// Mini-framework de formulário (sliders, switches, botões, segmentos) para as telas de configuração.

enum FormRow {
    case slider(title: String, min: Float, max: Float, step: Float, unit: String,
                get: () -> Double, set: (Double) -> Void)
    case toggle(title: String, get: () -> Bool, set: (Bool) -> Void)
    case button(title: String, destructive: Bool, action: () -> Void)
    case segment(titles: [String], get: () -> Int, set: (Int) -> Void)
    case info(String)
}

struct FormSection {
    var title: String?
    var footer: String?
    var rows: [FormRow]
}

final class SliderCell: UITableViewCell {
    private let titleLabel = UILabel()
    private let valueLabel = UILabel()
    private let slider = UISlider()
    private var step: Float = 1
    private var unit = ""
    private var onChange: ((Double) -> Void)?

    init(title: String, min: Float, max: Float, step: Float, unit: String, value: Double, onChange: @escaping (Double) -> Void) {
        super.init(style: .default, reuseIdentifier: nil)
        selectionStyle = .none
        self.step = step
        self.unit = unit
        self.onChange = onChange
        titleLabel.text = title
        titleLabel.font = .systemFont(ofSize: 15)
        valueLabel.font = .monospacedDigitSystemFont(ofSize: 15, weight: .medium)
        valueLabel.textColor = .secondaryLabel
        valueLabel.textAlignment = .right
        slider.minimumValue = min
        slider.maximumValue = max
        slider.value = Float(value)
        slider.addTarget(self, action: #selector(changed), for: .valueChanged)
        refreshValue()

        let top = UIStackView(arrangedSubviews: [titleLabel, valueLabel])
        top.distribution = .fill
        valueLabel.setContentHuggingPriority(.required, for: .horizontal)
        let v = UIStackView(arrangedSubviews: [top, slider])
        v.axis = .vertical
        v.spacing = 6
        v.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(v)
        NSLayoutConstraint.activate([
            v.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            v.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10),
            v.leadingAnchor.constraint(equalTo: contentView.layoutMarginsGuide.leadingAnchor),
            v.trailingAnchor.constraint(equalTo: contentView.layoutMarginsGuide.trailingAnchor),
        ])
    }
    required init?(coder: NSCoder) { fatalError() }

    private func refreshValue() {
        let v = (slider.value / step).rounded() * step
        valueLabel.text = (step < 1 ? String(format: "%.1f", v) : String(format: "%.0f", v)) + unit
    }

    @objc private func changed() {
        let v = (slider.value / step).rounded() * step
        refreshValue()
        onChange?(Double(v))
    }
}

final class SegmentCell: UITableViewCell {
    private let seg: UISegmentedControl
    private var onChange: ((Int) -> Void)?

    init(titles: [String], selected: Int, onChange: @escaping (Int) -> Void) {
        seg = UISegmentedControl(items: titles)
        super.init(style: .default, reuseIdentifier: nil)
        selectionStyle = .none
        self.onChange = onChange
        seg.selectedSegmentIndex = selected
        seg.addTarget(self, action: #selector(changed), for: .valueChanged)
        seg.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(seg)
        NSLayoutConstraint.activate([
            seg.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
            seg.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -8),
            seg.leadingAnchor.constraint(equalTo: contentView.layoutMarginsGuide.leadingAnchor),
            seg.trailingAnchor.constraint(equalTo: contentView.layoutMarginsGuide.trailingAnchor),
        ])
    }
    required init?(coder: NSCoder) { fatalError() }

    @objc private func changed() { onChange?(seg.selectedSegmentIndex) }
}

final class ToggleCell: UITableViewCell {
    private let sw = UISwitch()
    private var onChange: ((Bool) -> Void)?

    init(title: String, on: Bool, onChange: @escaping (Bool) -> Void) {
        super.init(style: .default, reuseIdentifier: nil)
        selectionStyle = .none
        self.onChange = onChange
        textLabel?.text = title
        textLabel?.numberOfLines = 0
        textLabel?.font = .systemFont(ofSize: 15)
        sw.isOn = on
        sw.addTarget(self, action: #selector(changed), for: .valueChanged)
        accessoryView = sw
    }
    required init?(coder: NSCoder) { fatalError() }

    @objc private func changed() { onChange?(sw.isOn) }
}

class FormViewController: UITableViewController {
    var sections: [FormSection] = []

    init() { super.init(style: .insetGrouped) }
    required init?(coder: NSCoder) { fatalError() }

    /// Subclasses sobrescrevem.
    func build() -> [FormSection] { [] }

    func reload() {
        sections = build()
        tableView.reloadData()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.keyboardDismissMode = .onDrag
        reload()
    }

    override func numberOfSections(in tableView: UITableView) -> Int { sections.count }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { sections[section].rows.count }
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? { sections[section].title }
    override func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? { sections[section].footer }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch sections[indexPath.section].rows[indexPath.row] {
        case let .slider(title, mn, mx, step, unit, get, set):
            return SliderCell(title: title, min: mn, max: mx, step: step, unit: unit, value: get(), onChange: set)
        case let .toggle(title, get, set):
            return ToggleCell(title: title, on: get(), onChange: set)
        case let .segment(titles, get, set):
            return SegmentCell(titles: titles, selected: get(), onChange: set)
        case let .button(title, destructive, _):
            let c = UITableViewCell(style: .default, reuseIdentifier: nil)
            c.textLabel?.text = title
            c.textLabel?.textColor = destructive ? .systemRed : view.tintColor
            return c
        case let .info(text):
            let c = UITableViewCell(style: .default, reuseIdentifier: nil)
            c.textLabel?.text = text
            c.textLabel?.numberOfLines = 0
            c.textLabel?.font = .systemFont(ofSize: 13)
            c.textLabel?.textColor = .secondaryLabel
            c.selectionStyle = .none
            return c
        }
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if case let .button(_, _, action) = sections[indexPath.section].rows[indexPath.row] { action() }
    }
}

extension UIViewController {
    func showAlert(_ title: String, _ message: String? = nil, then: (() -> Void)? = nil) {
        let a = UIAlertController(title: title, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in then?() })
        present(a, animated: true)
    }
}
