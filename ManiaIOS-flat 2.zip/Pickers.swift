import UIKit
import UniformTypeIdentifiers
import PhotosUI

// MARK: - Escolher arquivos (.osz / .osk / imagens)

final class FilePicker: NSObject, UIDocumentPickerDelegate {
    private static var current: FilePicker?
    private let handler: ([URL]) -> Void

    private init(handler: @escaping ([URL]) -> Void) { self.handler = handler }

    static func present(on vc: UIViewController, types: [UTType], multiple: Bool, handler: @escaping ([URL]) -> Void) {
        let p = FilePicker(handler: handler)
        current = p
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: true)
        picker.allowsMultipleSelection = multiple
        picker.delegate = p
        vc.present(picker, animated: true)
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        FilePicker.current = nil
        handler(urls)
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        FilePicker.current = nil
    }
}

// MARK: - Galeria de fotos

final class PhotoPicker: NSObject, PHPickerViewControllerDelegate {
    private static var current: PhotoPicker?
    private let handler: (UIImage?) -> Void

    private init(handler: @escaping (UIImage?) -> Void) { self.handler = handler }

    static func present(on vc: UIViewController, handler: @escaping (UIImage?) -> Void) {
        let p = PhotoPicker(handler: handler)
        current = p
        var cfg = PHPickerConfiguration()
        cfg.filter = .images
        cfg.selectionLimit = 1
        let picker = PHPickerViewController(configuration: cfg)
        picker.delegate = p
        vc.present(picker, animated: true)
    }

    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)
        guard let item = results.first?.itemProvider, item.canLoadObject(ofClass: UIImage.self) else {
            PhotoPicker.current = nil
            return
        }
        item.loadObject(ofClass: UIImage.self) { obj, _ in
            DispatchQueue.main.async {
                PhotoPicker.current = nil
                self.handler(obj as? UIImage)
            }
        }
    }
}

// MARK: - Fundo do app

enum BackgroundStore {
    static func current() -> UIImage? { UIImage(contentsOfFile: Paths.background.path) }

    static func set(_ img: UIImage) {
        let maxSide: CGFloat = 2000
        var out = img
        let m = max(img.size.width, img.size.height)
        if m > maxSide {
            let s = maxSide / m
            let sz = CGSize(width: img.size.width * s, height: img.size.height * s)
            out = UIGraphicsImageRenderer(size: sz).image { _ in img.draw(in: CGRect(origin: .zero, size: sz)) }
        }
        try? out.jpegData(compressionQuality: 0.85)?.write(to: Paths.background)
    }

    static func remove() { try? FileManager.default.removeItem(at: Paths.background) }
}

// MARK: - Importação de .osz / .osk

enum ImportUI {
    static func archiveTypes() -> [UTType] {
        var types: [UTType] = [.zip, .data]
        if let t = UTType(filenameExtension: "osz") { types.append(t) }
        if let t = UTType(filenameExtension: "osk") { types.append(t) }
        return types
    }

    static func importArchives(from vc: UIViewController, done: @escaping () -> Void) {
        FilePicker.present(on: vc, types: archiveTypes(), multiple: true) { urls in
            var msgs: [String] = []
            for u in urls { msgs.append(Library.importAny(u)) }
            done()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                vc.showAlert("Importação", msgs.joined(separator: "\n"))
            }
        }
    }

    static func pickBackgroundFromFiles(from vc: UIViewController, done: @escaping () -> Void) {
        FilePicker.present(on: vc, types: [.image], multiple: false) { urls in
            if let u = urls.first, let img = UIImage(contentsOfFile: u.path) {
                BackgroundStore.set(img)
            }
            done()
        }
    }

    static func pickBackgroundFromPhotos(from vc: UIViewController, done: @escaping () -> Void) {
        PhotoPicker.present(on: vc) { img in
            if let img = img { BackgroundStore.set(img) }
            done()
        }
    }
}
