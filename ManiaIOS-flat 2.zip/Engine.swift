import Foundation
import UIKit

enum Judgement: Int {
    case max = 0, j300, j200, j100, j50, miss

    var label: String { ["MAX", "300", "200", "100", "50", "MISS"][rawValue] }
    var color: UIColor {
        [UIColor(red: 0.6, green: 0.9, blue: 1.0, alpha: 1), UIColor(red: 1.0, green: 0.85, blue: 0.3, alpha: 1),
         UIColor(red: 0.4, green: 0.9, blue: 0.4, alpha: 1), UIColor(red: 0.3, green: 0.6, blue: 1.0, alpha: 1),
         UIColor(red: 0.8, green: 0.5, blue: 0.9, alpha: 1), UIColor(red: 1.0, green: 0.3, blue: 0.3, alpha: 1)][rawValue]
    }
    var scoreWeight: Double { [320, 300, 200, 100, 50, 0][rawValue] }
    var accWeight: Double { [300, 300, 200, 100, 50, 0][rawValue] }
    var health: Double { [0.008, 0.005, 0.0, -0.03, -0.06, -0.12][rawValue] }
}

final class Note {
    let column: Int
    let time: Double
    let endTime: Double?
    var headJudgement: Judgement = .miss
    var holding = false
    var done = false
    init(column: Int, time: Double, endTime: Double?) {
        self.column = column; self.time = time; self.endTime = endTime
    }
}

final class GameEngine {
    let keys: Int
    let mods: Mods
    private(set) var byColumn: [[Note]]
    private var nextIdx: [Int]
    private(set) var holdingNote: [Note?]
    private(set) var keyDown: [Bool]
    private var lastAutoHit: [Double]

    private(set) var counts = [Int](repeating: 0, count: 6)
    private(set) var combo = 0
    private(set) var maxCombo = 0
    private(set) var health = 1.0
    private(set) var failed = false
    private(set) var lastJudgement: Judgement?
    private(set) var lastJudgementTime = -99999.0
    private(set) var judged = 0
    private var scoreSum = 0.0
    private var accSum = 0.0
    let totalJudgements: Int
    let lastTime: Double

    // janelas de acerto (ms): [max, 300, 200, 100, 50, miss]
    let w: [Double]

    init(map: Beatmap, mods: Mods) {
        self.keys = map.keys
        self.mods = mods
        var od = map.od
        if mods.contains(.hardRock) { od = min(10, od * 1.4) }
        if mods.contains(.easy) { od = od * 0.5 }
        w = [16, 64 - 3 * od, 97 - 3 * od, 127 - 3 * od, 151 - 3 * od, 188 - 3 * od]

        var cols = Array(0..<map.keys)
        if mods.contains(.mirror) { cols.reverse() }
        if mods.contains(.random) { cols.shuffle() }

        var per = [[Note]](repeating: [], count: map.keys)
        var total = 0
        var last = 0.0
        for o in map.objects {
            let c = cols[o.column]
            let end = mods.contains(.noHolds) ? nil : o.endTime
            per[c].append(Note(column: c, time: o.time, endTime: end))
            total += end == nil ? 1 : 2
            last = max(last, end ?? o.time)
        }
        for i in 0..<per.count { per[i].sort { $0.time < $1.time } }
        byColumn = per
        nextIdx = [Int](repeating: 0, count: map.keys)
        holdingNote = [Note?](repeating: nil, count: map.keys)
        keyDown = [Bool](repeating: false, count: map.keys)
        lastAutoHit = [Double](repeating: -99999, count: map.keys)
        totalJudgements = total
        lastTime = last
    }

    // MARK: Estatísticas

    var score: Int { Int(1_000_000 * scoreSum / (320 * Double(max(1, totalJudgements)))) }
    var accuracy: Double { judged == 0 ? 1 : accSum / (300 * Double(judged)) }
    var grade: String {
        let a = accuracy
        if failed { return "F" }
        if a >= 1.0 { return "SS" }
        if a >= 0.95 { return "S" }
        if a >= 0.90 { return "A" }
        if a >= 0.80 { return "B" }
        if a >= 0.70 { return "C" }
        return "D"
    }
    func isFinished(_ now: Double) -> Bool { failed || now > lastTime + 1200 }

    func isKeyDown(_ c: Int, now: Double) -> Bool {
        if keyDown[c] { return true }
        if mods.contains(.auto) { return holdingNote[c] != nil || now - lastAutoHit[c] < 90 }
        return false
    }

    // MARK: Julgamento

    private func judge(_ ad: Double) -> Judgement {
        if ad <= w[0] { return .max }
        if ad <= w[1] { return .j300 }
        if ad <= w[2] { return .j200 }
        if ad <= w[3] { return .j100 }
        if ad <= w[4] { return .j50 }
        return .miss
    }

    private func register(_ j: Judgement, now: Double) {
        counts[j.rawValue] += 1
        judged += 1
        scoreSum += j.scoreWeight
        accSum += j.accWeight
        lastJudgement = j
        lastJudgementTime = now
        if j == .miss { combo = 0 } else { combo += 1 }
        maxCombo = max(maxCombo, combo)
        health = min(1, max(0, health + j.health))
        if mods.contains(.noFail) || mods.contains(.auto) { return }
        if health <= 0 { failed = true }
        if mods.contains(.suddenDeath) && j == .miss { failed = true }
        if mods.contains(.perfect) && j.rawValue > Judgement.j300.rawValue { failed = true }
    }

    // MARK: Entrada

    func press(_ c: Int, now: Double) {
        guard c >= 0, c < keys else { return }
        keyDown[c] = true
        guard !failed, nextIdx[c] < byColumn[c].count else { return }
        let n = byColumn[c][nextIdx[c]]
        let delta = now - n.time
        if delta < -w[5] { return }
        let j = judge(abs(delta))
        nextIdx[c] += 1
        register(j, now: now)
        if n.endTime != nil {
            if j == .miss {
                n.done = true
                register(.miss, now: now)
            } else {
                n.headJudgement = j
                n.holding = true
                holdingNote[c] = n
            }
        } else {
            n.done = true
        }
    }

    func release(_ c: Int, now: Double) {
        guard c >= 0, c < keys else { return }
        keyDown[c] = false
        guard !failed, let n = holdingNote[c], let end = n.endTime else { return }
        holdingNote[c] = nil
        n.holding = false
        n.done = true
        let ad = abs(now - end)
        // janelas de soltar são 1.5x maiores
        let j = (now < end && ad > w[4] * 1.5) ? Judgement.miss : judge(ad / 1.5)
        register(j, now: now)
    }

    // MARK: Atualização por frame

    func update(now: Double) {
        guard !failed else { return }
        if mods.contains(.auto) { runAuto(now) }
        for c in 0..<keys {
            while nextIdx[c] < byColumn[c].count {
                let n = byColumn[c][nextIdx[c]]
                if now - n.time > w[5] {
                    nextIdx[c] += 1
                    n.done = true
                    register(.miss, now: now)
                    if n.endTime != nil { register(.miss, now: now) }
                } else { break }
            }
            // segurou até o fim: tail acerta automaticamente
            if let h = holdingNote[c], let end = h.endTime, now >= end + 1 {
                holdingNote[c] = nil
                h.holding = false
                h.done = true
                register(h.headJudgement == .max ? .max : .j300, now: now)
            }
            if failed { return }
        }
    }

    private func runAuto(_ now: Double) {
        for c in 0..<keys {
            if let h = holdingNote[c], let end = h.endTime, now >= end {
                release(c, now: end)
            }
            if nextIdx[c] < byColumn[c].count {
                let n = byColumn[c][nextIdx[c]]
                if now >= n.time {
                    press(c, now: n.time)
                    lastAutoHit[c] = now
                    if n.endTime == nil { keyDown[c] = false }
                }
            }
        }
    }
}
