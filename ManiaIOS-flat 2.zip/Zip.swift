import Foundation
import Compression

// Leitor mínimo de ZIP (.osz / .osk), usando o framework Compression (deflate cru).

struct ZipEntry {
    let name: String
    let method: UInt16
    let compSize: Int
    let uncompSize: Int
    let localOffset: Int
}

enum ZipError: Error { case invalid, unsupported }

final class ZipArchive {
    private let data: Data
    private(set) var entries: [ZipEntry] = []

    init(url: URL) throws {
        data = try Data(contentsOf: url, options: .alwaysMapped)
        try readDirectory()
    }

    private func u16(_ i: Int) -> Int { Int(data[i]) | (Int(data[i + 1]) << 8) }
    private func u32(_ i: Int) -> Int { u16(i) | (u16(i + 2) << 16) }

    private func readDirectory() throws {
        let n = data.count
        guard n >= 22 else { throw ZipError.invalid }
        var eocd = -1
        var i = n - 22
        let lowest = max(0, n - 22 - 65535)
        while i >= lowest {
            if data[i] == 0x50, data[i + 1] == 0x4B, data[i + 2] == 0x05, data[i + 3] == 0x06 { eocd = i; break }
            i -= 1
        }
        guard eocd >= 0 else { throw ZipError.invalid }
        let total = u16(eocd + 10)
        var p = u32(eocd + 16)
        for _ in 0..<total {
            guard p + 46 <= n, u32(p) == 0x02014b50 else { throw ZipError.invalid }
            let method = UInt16(u16(p + 10))
            let comp = u32(p + 20)
            let uncomp = u32(p + 24)
            let nameLen = u16(p + 28)
            let extraLen = u16(p + 30)
            let commentLen = u16(p + 32)
            let off = u32(p + 42)
            guard p + 46 + nameLen <= n else { throw ZipError.invalid }
            let nameData = data.subdata(in: (p + 46)..<(p + 46 + nameLen))
            let name = String(data: nameData, encoding: .utf8) ?? String(data: nameData, encoding: .isoLatin1) ?? ""
            entries.append(ZipEntry(name: name, method: method, compSize: comp, uncompSize: uncomp, localOffset: off))
            p += 46 + nameLen + extraLen + commentLen
        }
    }

    func read(_ e: ZipEntry) throws -> Data {
        let o = e.localOffset
        guard o + 30 <= data.count, u32(o) == 0x04034b50 else { throw ZipError.invalid }
        let start = o + 30 + u16(o + 26) + u16(o + 28)
        guard start + e.compSize <= data.count else { throw ZipError.invalid }
        if e.compSize == 0 { return Data() }
        let comp = data.subdata(in: start..<(start + e.compSize))
        if e.method == 0 { return comp }
        guard e.method == 8 else { throw ZipError.unsupported }
        if e.uncompSize == 0 { return Data() }
        var out = Data(count: e.uncompSize)
        let size = e.uncompSize
        let csize = e.compSize
        let produced: Int = out.withUnsafeMutableBytes { (dst: UnsafeMutableRawBufferPointer) -> Int in
            comp.withUnsafeBytes { (src: UnsafeRawBufferPointer) -> Int in
                guard let d = dst.bindMemory(to: UInt8.self).baseAddress,
                      let s = src.bindMemory(to: UInt8.self).baseAddress else { return 0 }
                return compression_decode_buffer(d, size, s, csize, nil, COMPRESSION_ZLIB)
            }
        }
        guard produced == size else { throw ZipError.invalid }
        return out
    }

    /// Extrai tudo para `dir`, ignorando caminhos suspeitos ("..").
    func extractAll(to dir: URL) throws {
        let fm = FileManager.default
        try fm.createDirectory(at: dir, withIntermediateDirectories: true)
        for e in entries {
            let clean = e.name.replacingOccurrences(of: "\\", with: "/")
            if clean.hasSuffix("/") || clean.hasPrefix("__MACOSX") { continue }
            let parts = clean.split(separator: "/").map(String.init)
            if parts.isEmpty || parts.contains("..") { continue }
            var dest = dir
            for part in parts { dest.appendPathComponent(part) }
            try fm.createDirectory(at: dest.deletingLastPathComponent(), withIntermediateDirectories: true)
            let bytes = try read(e)
            try bytes.write(to: dest)
        }
    }
}
