#!/bin/bash
# Gera um .ipa SEM ASSINATURA (rode num Mac com Xcode instalado).
# Uso: ./build_ipa.sh   ->  build/ManiaIOS.ipa
set -euo pipefail
cd "$(dirname "$0")"

SDK=$(xcrun --sdk iphoneos --show-sdk-path)
OUT=build
APP=$OUT/Payload/ManiaIOS.app
rm -rf "$OUT"; mkdir -p "$APP"

xcrun --sdk iphoneos swiftc \
  -target arm64-apple-ios15.0 \
  -sdk "$SDK" \
  -O -parse-as-library \
  -module-name ManiaIOS \
  -o "$APP/ManiaIOS" \
  *.swift

cp Info.plist "$APP/Info.plist"
printf 'APPL????' > "$APP/PkgInfo"

# Pseudo-assinatura ad-hoc (opcional, ajuda alguns instaladores como TrollStore/AltStore/Sideloadly)
codesign -f -s - "$APP" 2>/dev/null || true

(cd "$OUT" && zip -qry ManiaIOS.ipa Payload)
echo "OK -> $OUT/ManiaIOS.ipa"
