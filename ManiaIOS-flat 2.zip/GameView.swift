import UIKit

struct StageLayout {
    var colX: [CGFloat] = []
    var colW: [CGFloat] = []
    var lineW: [CGFloat] = []
    var hitY: CGFloat = 0
    var scale: CGFloat = 1          // pontos por unidade osu (vertical)
    var left: CGFloat = 0
    var right: CGFloat = 0
    var noteHeightMul: CGFloat = 1
    var upscroll = false

    static func make(size: CGSize, cfg: ManiaConfig, settings s: Settings) -> StageLayout {
        var L = StageLayout()
        let k = cfg.keys
        let sy = size.height / 480
        let wMul = CGFloat(s.columnWidthPct / 100)
        var widths = cfg.columnWidth.map { CGFloat($0) * sy * wMul }
        var total = widths.reduce(0, +)
        let maxW = size.width * 0.98
        if total > maxW {
            let f = maxW / total
            widths = widths.map { $0 * f }
            total = maxW
        }
        let oscTotal = CGFloat(cfg.columnWidth.reduce(0, +))
        var center = size.width / 2
        if let cs = cfg.columnStart {
            center += (CGFloat(cs) + oscTotal / 2 - 320) * sy
        }
        center += CGFloat(s.stageXOffset)
        var left = center - total / 2
        left = max(0, min(size.width - total, left))
        var x = left
        for i in 0..<k {
            L.colX.append(x)
            L.colW.append(widths[i])
            L.lineW.append(CGFloat(cfg.columnLineWidth[i]) * sy)
            x += widths[i]
        }
        L.lineW.append(CGFloat(cfg.columnLineWidth[k]) * sy)
        L.left = left
        L.right = left + total
        let basePos = s.useSkinHitPosition ? cfg.hitPosition : 402
        let hp = max(100, min(480, basePos + s.hitPositionOffset))
        L.hitY = CGFloat(hp) * size.height / 480
        L.scale = sy
        L.noteHeightMul = CGFloat(s.noteHeightPct / 100)
        switch s.scrollDirection {
        case 1: L.upscroll = false
        case 2: L.upscroll = true
        default: L.upscroll = cfg.upsideDown
        }
        return L
    }

    func column(at x: CGFloat) -> Int {
        if colX.isEmpty { return 0 }
        if x <= left { return 0 }
        if x >= right { return colX.count - 1 }
        for i in 0..<colX.count where x < colX[i] + colW[i] { return i }
        return colX.count - 1
    }
}

struct DrawNote {
    var column: Int
    var time: Double
    var endTime: Double?
    var holding: Bool
}

final class GameView: UIView {
    var skin: Skin
    let keys: Int
    var cfg: ManiaConfig
    var engine: GameEngine?
    var nowProvider: () -> Double = { 0 }
    var previewNotes: [DrawNote] = []
    var pressedPreview: [Bool] = []
    var bgImage: UIImage?
    var layout = StageLayout()
    var mods: Mods = []
    var scrollSpeed: Double = 22

    var onPress: ((Int, TimeInterval) -> Void)?
    var onRelease: ((Int, TimeInterval) -> Void)?
    private var touchCol: [ObjectIdentifier: Int] = [:]

    init(skin: Skin, keys: Int) {
        self.skin = skin
        self.keys = keys
        self.cfg = skin.config(keys: keys)
        super.init(frame: .zero)
        isMultipleTouchEnabled = true
        isOpaque = true
        backgroundColor = .black
        contentMode = .redraw
    }
    required init?(coder: NSCoder) { fatalError() }

    override func layoutSubviews() {
        super.layoutSubviews()
        relayout()
    }

    func reloadSkin(_ s: Skin) {
        skin = s
        relayout()
    }

    func relayout() {
        cfg = skin.config(keys: keys)
        layout = StageLayout.make(size: bounds.size, cfg: cfg, settings: Settings.shared)
        setNeedsDisplay()
    }

    // MARK: Toque

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            let c = layout.column(at: t.location(in: self).x)
            touchCol[ObjectIdentifier(t)] = c
            onPress?(c, t.timestamp)
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            let id = ObjectIdentifier(t)
            let c = layout.column(at: t.location(in: self).x)
            if let old = touchCol[id], old != c {
                onRelease?(old, t.timestamp)
                touchCol[id] = c
                onPress?(c, t.timestamp)
            }
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) { endTouches(touches) }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) { endTouches(touches) }

    private func endTouches(_ touches: Set<UITouch>) {
        for t in touches {
            let id = ObjectIdentifier(t)
            if let c = touchCol[id] { onRelease?(c, t.timestamp) }
            touchCol[id] = nil
        }
    }

    func releaseAllTouches() {
        let t = ProcessInfo.processInfo.systemUptime
        for (_, c) in touchCol { onRelease?(c, t) }
        touchCol.removeAll()
    }

    // MARK: Desenho

    private func noteColor(_ col: Int) -> UIColor {
        switch skin.columnType(col: col, keys: keys) {
        case "1": return UIColor(white: 0.95, alpha: 1)
        case "2": return UIColor(red: 0.45, green: 0.72, blue: 1.0, alpha: 1)
        default: return UIColor(red: 1.0, green: 0.8, blue: 0.3, alpha: 1)
        }
    }

    private func drawAspectFill(_ img: UIImage, in rect: CGRect) {
        let iw = img.size.width, ih = img.size.height
        guard iw > 0, ih > 0 else { return }
        let s = max(rect.width / iw, rect.height / ih)
        let w = iw * s, h = ih * s
        img.draw(in: CGRect(x: rect.midX - w / 2, y: rect.midY - h / 2, width: w, height: h))
    }

    private func visibility(_ y: CGFloat) -> CGFloat {
        let f = layout.hitY > 0 ? y / layout.hitY : 1
        var a: CGFloat = 1
        if mods.contains(.hidden) { a = min(a, f < 0.55 ? 1 : max(0, 1 - (f - 0.55) / 0.3)) }
        if mods.contains(.fadeIn) { a = min(a, f < 0.35 ? 0 : min(1, (f - 0.35) / 0.25)) }
        return a
    }

    override func draw(_ rect: CGRect) {
        guard let ctx = UIGraphicsGetCurrentContext() else { return }
        let size = bounds.size
        let now = nowProvider()
        let L = layout
        guard L.colX.count == keys else { return }

        // fundo
        UIColor.black.setFill(); ctx.fill(bounds)
        if let bg = bgImage { drawAspectFill(bg, in: bounds) }
        UIColor.black.withAlphaComponent(CGFloat(Settings.shared.backgroundDim)).setFill()
        ctx.fill(bounds)

        // Upscroll: vira o palco na vertical (HUD é desenhado depois, sem virar)
        ctx.saveGState()
        if L.upscroll {
            ctx.translateBy(x: 0, y: size.height)
            ctx.scaleBy(x: 1, y: -1)
        }

        // palco
        let stageRect = CGRect(x: L.left, y: 0, width: L.right - L.left, height: size.height)
        UIColor.black.withAlphaComponent(0.55).setFill(); ctx.fill(stageRect)

        // linhas das colunas
        UIColor.white.withAlphaComponent(0.25).setFill()
        for i in 0...keys {
            let x = i < keys ? L.colX[i] : L.right
            let lw = max(1, i < L.lineW.count ? L.lineW[i] : 1)
            ctx.fill(CGRect(x: x - lw / 2, y: 0, width: lw, height: size.height))
        }
        if let img = skin.stageImage("StageLeft", default: "mania-stage-left", keys: keys) {
            let h = size.height, w = img.size.width / img.size.height * h
            img.draw(in: CGRect(x: L.left - w, y: 0, width: w, height: h))
        }
        if let img = skin.stageImage("StageRight", default: "mania-stage-right", keys: keys) {
            let h = size.height, w = img.size.width / img.size.height * h
            img.draw(in: CGRect(x: L.right, y: 0, width: w, height: h))
        }

        // linha de acerto
        if let hint = skin.stageImage("StageHint", default: "mania-stage-hint", keys: keys) {
            let w = L.right - L.left
            let h = min(w * hint.size.height / max(1, hint.size.width), 80)
            hint.draw(in: CGRect(x: L.left, y: L.hitY - h / 2, width: w, height: h))
        } else {
            UIColor(red: 1, green: 0.35, blue: 0.5, alpha: 0.9).setFill()
            ctx.fill(CGRect(x: L.left, y: L.hitY - 1.5, width: L.right - L.left, height: 3))
        }

        // luz das colunas pressionadas
        for c in 0..<keys where isDown(c, now: now) {
            let r = CGRect(x: L.colX[c], y: L.hitY * 0.45, width: L.colW[c], height: L.hitY * 0.55)
            if let light = skin.stageImage("StageLight", default: "mania-stage-light", keys: keys) {
                light.draw(in: r)
            } else {
                let colors = [UIColor.white.withAlphaComponent(0).cgColor, UIColor.white.withAlphaComponent(0.28).cgColor] as CFArray
                if let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: [0, 1]) {
                    ctx.saveGState()
                    ctx.clip(to: r)
                    ctx.drawLinearGradient(g, start: CGPoint(x: 0, y: r.minY), end: CGPoint(x: 0, y: r.maxY), options: [])
                    ctx.restoreGState()
                }
            }
        }

        // notas
        let timeRange = 11485.0 / max(1.0, scrollSpeed)
        let ppm = Double(L.hitY) / timeRange
        for n in visibleNotes(now: now, timeRange: timeRange) {
            drawNote(n, now: now, ppm: ppm, ctx: ctx)
        }

        // teclas
        let keyTop = L.hitY
        for c in 0..<keys {
            let r = CGRect(x: L.colX[c], y: keyTop, width: L.colW[c], height: max(0, size.height - keyTop))
            let down = isDown(c, now: now)
            if let img = skin.keyImage(col: c, keys: keys, pressed: down) ?? (down ? skin.keyImage(col: c, keys: keys, pressed: false) : nil) {
                img.draw(in: r)
            } else {
                (down ? noteColor(c).withAlphaComponent(0.9) : UIColor(white: 0.12, alpha: 0.85)).setFill()
                ctx.fill(r.insetBy(dx: 1, dy: 0))
            }
        }

        ctx.restoreGState()
        drawHUD(ctx: ctx, now: now)
    }

    /// Espelha uma posição Y do HUD quando está em upscroll.
    private func hy(_ y: CGFloat) -> CGFloat { layout.upscroll ? bounds.height - y : y }

    private func isDown(_ c: Int, now: Double) -> Bool {
        if let e = engine { return e.isKeyDown(c, now: now) }
        return c < pressedPreview.count ? pressedPreview[c] : false
    }

    private func visibleNotes(now: Double, timeRange: Double) -> [DrawNote] {
        guard let e = engine else { return previewNotes }
        var out: [DrawNote] = []
        let behind = 400.0
        for col in e.byColumn {
            for n in col {
                if n.done { continue }
                let end = n.endTime ?? n.time
                if end < now - behind { continue }
                if n.time > now + timeRange * 1.1 { break }
                out.append(DrawNote(column: n.column, time: n.time, endTime: n.endTime, holding: n.holding))
            }
        }
        return out
    }

    private func drawNote(_ n: DrawNote, now: Double, ppm: Double, ctx: CGContext) {
        let L = layout
        let c = n.column
        let x = L.colX[c], w = L.colW[c]
        let color = noteColor(c)

        func noteHeight(_ img: UIImage?) -> CGFloat {
            if let i = img, i.size.width > 0 { return w * i.size.height / i.size.width * L.noteHeightMul }
            return w * 0.45 * L.noteHeightMul
        }
        func drawHead(bottom: CGFloat, suffix: String, alpha: CGFloat) {
            let img = skin.noteImage(col: c, keys: keys, suffix: suffix)
            let h = noteHeight(img)
            let r = CGRect(x: x, y: bottom - h, width: w, height: h)
            if let i = img { i.draw(in: r, blendMode: .normal, alpha: alpha) }
            else {
                color.withAlphaComponent(alpha).setFill()
                UIBezierPath(roundedRect: r.insetBy(dx: 2, dy: 1), cornerRadius: min(6, h / 3)).fill()
            }
        }

        let headBottom = n.holding ? L.hitY : L.hitY - CGFloat((n.time - now) * ppm)
        if let end = n.endTime {
            let tailBottom = L.hitY - CGFloat((end - now) * ppm)
            let hH = noteHeight(skin.noteImage(col: c, keys: keys, suffix: "H"))
            let bodyRect = CGRect(x: x + w * 0.12, y: tailBottom - hH / 2, width: w * 0.76, height: max(0, headBottom - tailBottom))
            if bodyRect.maxY > 0, bodyRect.minY < bounds.height {
                let a = visibility(bodyRect.midY)
                if let body = skin.noteImage(col: c, keys: keys, suffix: "L") {
                    body.draw(in: CGRect(x: x, y: bodyRect.minY, width: w, height: bodyRect.height), blendMode: .normal, alpha: a * (n.holding ? 1 : 0.9))
                } else {
                    color.withAlphaComponent(0.55 * a).setFill()
                    ctx.fill(bodyRect)
                }
            }
            if tailBottom > -60 && tailBottom < bounds.height + 60 { drawHead(bottom: tailBottom, suffix: "T", alpha: visibility(tailBottom)) }
            if headBottom > -60 && headBottom < bounds.height + 60 { drawHead(bottom: headBottom, suffix: "H", alpha: visibility(headBottom)) }
        } else if headBottom > -60 && headBottom < bounds.height + 60 {
            drawHead(bottom: headBottom, suffix: "", alpha: visibility(headBottom))
        }
    }

    private func text(_ s: String, size: CGFloat, color: UIColor = .white, weight: UIFont.Weight = .bold) -> NSAttributedString {
        let shadow = NSShadow()
        shadow.shadowColor = UIColor.black.withAlphaComponent(0.7)
        shadow.shadowOffset = CGSize(width: 0, height: 1)
        shadow.shadowBlurRadius = 3
        return NSAttributedString(string: s, attributes: [
            .font: UIFont.monospacedDigitSystemFont(ofSize: size, weight: weight),
            .foregroundColor: color, .shadow: shadow])
    }

    private func drawCentered(_ a: NSAttributedString, x: CGFloat, y: CGFloat) {
        let s = a.size()
        a.draw(at: CGPoint(x: x - s.width / 2, y: y - s.height / 2))
    }

    private func drawHUD(ctx: CGContext, now: Double) {
        guard let e = engine else { return }
        let L = layout
        let size = bounds.size
        let midX = (L.left + L.right) / 2
        let safeTop = max(safeAreaInsets.top, 8)

        // vida
        UIColor.white.withAlphaComponent(0.15).setFill()
        ctx.fill(CGRect(x: 0, y: 0, width: size.width, height: 4))
        (e.health > 0.3 ? UIColor.systemGreen : UIColor.systemRed).setFill()
        ctx.fill(CGRect(x: 0, y: 0, width: size.width * CGFloat(e.health), height: 4))

        // pontos / precisão
        let sc = text(String(format: "%07d", e.score), size: 24)
        sc.draw(at: CGPoint(x: size.width - sc.size().width - 14, y: safeTop + 6))
        let ac = text(String(format: "%.2f%%", e.accuracy * 100), size: 15, weight: .semibold)
        ac.draw(at: CGPoint(x: size.width - ac.size().width - 14, y: safeTop + 34))
        if mods != [] {
            let m = text(mods.acronyms, size: 12, color: UIColor.systemYellow, weight: .semibold)
            m.draw(at: CGPoint(x: size.width - m.size().width - 14, y: safeTop + 54))
        }

        // combo
        if e.combo > 1 {
            drawCentered(text("\(e.combo)", size: max(30, 40 * L.scale)), x: midX, y: hy(L.hitY * 0.38))
        }

        // julgamento
        if let j = e.lastJudgement {
            let age = now - e.lastJudgementTime
            if age >= 0 && age < 500 {
                let pop = 1 + CGFloat(max(0, 1 - age / 90)) * 0.25
                let alpha = CGFloat(min(1, (500 - age) / 150))
                let y = hy(L.hitY * 0.62)
                if Settings.shared.showJudgementImages, let img = skin.judgementImage(j) {
                    let w = min((L.right - L.left) * 0.8, 220) * pop
                    let h = w * img.size.height / max(1, img.size.width)
                    img.draw(in: CGRect(x: midX - w / 2, y: y - h / 2, width: w, height: h), blendMode: .normal, alpha: alpha)
                } else {
                    drawCentered(text(j.label, size: 22 * pop, color: j.color.withAlphaComponent(alpha)), x: midX, y: y)
                }
            }
        }
    }
}
