import Foundation

struct HitObject {
    var column: Int
    var time: Double          // ms
    var endTime: Double?      // ms (nil = nota simples)
}

final class Beatmap {
    let dir: URL
    let file: URL
    var title = "Unknown"
    var artist = "Unknown"
    var version = ""
    var creator = ""
    var audioFilename = ""
    var backgroundFilename: String?
    var keys = 4
    var od = 5.0
    var objects: [HitObject] = []

    var audioURL: URL { dir.appendingPathComponent(audioFilename) }
    var backgroundURL: URL? { backgroundFilename.map { dir.appendingPathComponent($0) } }
    var lengthMs: Double { objects.map { $0.endTime ?? $0.time }.max() ?? 0 }

    /// Retorna nil se não for um mapa osu!mania válido.
    init?(file: URL) {
        self.file = file
        self.dir = file.deletingLastPathComponent()
        guard let d = try? Data(contentsOf: file),
              let raw = String(data: d, encoding: .utf8) ?? String(data: d, encoding: .isoLatin1) else { return nil }
        var section = ""
        var mode = 0
        for rawLine in raw.components(separatedBy: .newlines) {
            let line = rawLine.trimmingCharacters(in: .whitespaces)
            if line.isEmpty || line.hasPrefix("//") { continue }
            if line.hasPrefix("[") && line.hasSuffix("]") {
                section = String(line.dropFirst().dropLast())
                continue
            }
            switch section {
            case "General", "Metadata", "Difficulty":
                guard let c = line.firstIndex(of: ":") else { continue }
                let k = line[line.startIndex..<c].trimmingCharacters(in: .whitespaces)
                let v = line[line.index(after: c)...].trimmingCharacters(in: .whitespaces)
                switch k {
                case "AudioFilename": audioFilename = v
                case "Mode": mode = Int(v) ?? 0
                case "Title": title = v
                case "Artist": artist = v
                case "Version": version = v
                case "Creator": creator = v
                case "CircleSize": keys = max(1, min(10, Int(Double(v) ?? 4)))
                case "OverallDifficulty": od = Double(v) ?? 5
                default: break
                }
            case "Events":
                let p = line.split(separator: ",", omittingEmptySubsequences: false).map { $0.trimmingCharacters(in: .whitespaces) }
                if p.count >= 3, p[0] == "0", backgroundFilename == nil {
                    backgroundFilename = p[2].replacingOccurrences(of: "\"", with: "")
                }
            case "HitObjects":
                let p = line.split(separator: ",", omittingEmptySubsequences: false).map(String.init)
                guard p.count >= 5, let x = Double(p[0]), let t = Double(p[2]), let type = Int(p[3]) else { continue }
                let col = max(0, min(keys - 1, Int(x * Double(keys) / 512.0)))
                if type & 128 != 0, p.count >= 6 {
                    let endStr = p[5].split(separator: ":").first.map(String.init) ?? ""
                    if let e = Double(endStr), e > t { objects.append(HitObject(column: col, time: t, endTime: e)); continue }
                }
                objects.append(HitObject(column: col, time: t, endTime: nil))
            default: break
            }
        }
        guard mode == 3, !objects.isEmpty, !audioFilename.isEmpty else { return nil }
        objects.sort { $0.time < $1.time }
    }
}

struct BeatmapSet {
    let dir: URL
    var title: String
    var artist: String
    var diffs: [Beatmap]
}

enum Library {
    static func sets() -> [BeatmapSet] {
        let fm = FileManager.default
        let dirs = (try? fm.contentsOfDirectory(at: Paths.songs, includingPropertiesForKeys: nil)) ?? []
        var result: [BeatmapSet] = []
        for d in dirs.sorted(by: { $0.lastPathComponent < $1.lastPathComponent }) {
            let files = ((try? fm.contentsOfDirectory(at: d, includingPropertiesForKeys: nil)) ?? [])
                .filter { $0.pathExtension.lowercased() == "osu" }
            let maps = files.compactMap { Beatmap(file: $0) }.sorted { ($0.keys, $0.objects.count) < ($1.keys, $1.objects.count) }
            if let f = maps.first {
                result.append(BeatmapSet(dir: d, title: f.title, artist: f.artist, diffs: maps))
            }
        }
        return result
    }

    // MARK: Importação

    enum ImportError: LocalizedError {
        case noMania
        var errorDescription: String? { "Nenhum mapa osu!mania (modo 3) encontrado nesse arquivo." }
    }

    @discardableResult
    static func importOSZ(_ url: URL) throws -> String {
        let name = url.deletingPathExtension().lastPathComponent
        let dest = Paths.uniqueDir(in: Paths.songs, name: name)
        let zip = try ZipArchive(url: url)
        try zip.extractAll(to: dest)
        let has = ((try? FileManager.default.contentsOfDirectory(at: dest, includingPropertiesForKeys: nil)) ?? [])
            .filter { $0.pathExtension.lowercased() == "osu" }
            .contains { Beatmap(file: $0) != nil }
        if !has {
            try? FileManager.default.removeItem(at: dest)
            throw ImportError.noMania
        }
        return name
    }

    @discardableResult
    static func importOSK(_ url: URL) throws -> String {
        let name = url.deletingPathExtension().lastPathComponent
        let dest = Paths.uniqueDir(in: Paths.skins, name: name)
        let zip = try ZipArchive(url: url)
        try zip.extractAll(to: dest)
        // Alguns .osk têm tudo dentro de uma subpasta: sobe o conteúdo um nível.
        let fm = FileManager.default
        if !fm.fileExists(atPath: dest.appendingPathComponent("skin.ini").path) {
            let items = (try? fm.contentsOfDirectory(at: dest, includingPropertiesForKeys: nil)) ?? []
            if items.count == 1, fm.fileExists(atPath: items[0].appendingPathComponent("skin.ini").path) {
                for f in (try? fm.contentsOfDirectory(at: items[0], includingPropertiesForKeys: nil)) ?? [] {
                    try? fm.moveItem(at: f, to: dest.appendingPathComponent(f.lastPathComponent))
                }
                try? fm.removeItem(at: items[0])
            }
        }
        return dest.lastPathComponent
    }

    /// Importa .osz ou .osk pela extensão. Retorna mensagem para o usuário.
    static func importAny(_ url: URL) -> String {
        do {
            switch url.pathExtension.lowercased() {
            case "osz": return "Beatmap importado: \(try importOSZ(url))"
            case "osk": return "Skin importada: \(try importOSK(url))"
            default: return "Formato não suportado (use .osz ou .osk)."
            }
        } catch {
            return "Falha ao importar: \(error.localizedDescription)"
        }
    }

    // MARK: Mapa de demonstração (gerado por código)

    static func ensureDemo() {
        let dir = Paths.songs.appendingPathComponent("Demo Beat", isDirectory: true)
        let fm = FileManager.default
        if fm.fileExists(atPath: dir.appendingPathComponent("demo.wav").path) { return }
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        try? makeWav().write(to: dir.appendingPathComponent("demo.wav"))
        for (k, v) in [(4, "4K Easy"), (7, "7K Normal")] {
            try? demoOsu(keys: k, version: v).write(to: dir.appendingPathComponent("demo-\(k)k.osu"), atomically: true, encoding: .utf8)
        }
    }

    private static func le16(_ v: Int) -> [UInt8] { [UInt8(v & 255), UInt8((v >> 8) & 255)] }
    private static func le32(_ v: Int) -> [UInt8] { le16(v & 0xFFFF) + le16((v >> 16) & 0xFFFF) }

    private static func makeWav() -> Data {
        let rate = 44100
        let seconds = 66
        let n = rate * seconds
        var pcm = [Int16](repeating: 0, count: n)
        let beat = 0.5  // 120 BPM
        var seed: UInt32 = 12345
        func noise() -> Double {
            seed = seed &* 1664525 &+ 1013904223
            return Double(seed >> 8) / Double(1 << 24) * 2 - 1
        }
        for i in 0..<n {
            let t = Double(i) / Double(rate)
            let inBeat = t.truncatingRemainder(dividingBy: beat)
            let beatIndex = Int(t / beat)
            var s = 0.0
            // bumbo em todo tempo
            if inBeat < 0.25 {
                let phase = 50 * inBeat + (100.0 / 30.0) * (1 - exp(-30 * inBeat))
                s += sin(2 * Double.pi * phase) * exp(-inBeat * 12) * 0.8
            }
            // caixa nos tempos 2 e 4
            if beatIndex % 2 == 1 && inBeat < 0.2 { s += noise() * exp(-inBeat * 20) * 0.35 }
            // chimbal nos contratempos
            let off = (t + beat / 2).truncatingRemainder(dividingBy: beat)
            if off < 0.05 { s += noise() * exp(-off * 60) * 0.2 }
            pcm[i] = Int16(max(-1, min(1, s)) * 28000)
        }
        var d = Data()
        d.append(contentsOf: Array("RIFF".utf8)); d.append(contentsOf: le32(36 + n * 2))
        d.append(contentsOf: Array("WAVEfmt ".utf8)); d.append(contentsOf: le32(16))
        d.append(contentsOf: le16(1)); d.append(contentsOf: le16(1))
        d.append(contentsOf: le32(rate)); d.append(contentsOf: le32(rate * 2))
        d.append(contentsOf: le16(2)); d.append(contentsOf: le16(16))
        d.append(contentsOf: Array("data".utf8)); d.append(contentsOf: le32(n * 2))
        pcm.withUnsafeBytes { d.append(contentsOf: $0) }
        return d
    }

    private static func demoOsu(keys k: Int, version: String) -> String {
        var out = "osu file format v14\n\n[General]\nAudioFilename: demo.wav\nMode: 3\n\n"
        out += "[Metadata]\nTitle:Demo Beat\nArtist:ManiaIOS\nCreator:built-in\nVersion:\(version)\n\n"
        out += "[Difficulty]\nHPDrainRate:5\nCircleSize:\(k)\nOverallDifficulty:7\nApproachRate:5\n\n"
        out += "[Events]\n\n[TimingPoints]\n0,500,4,1,0,100,1,0\n\n[HitObjects]\n"
        var lastEnd = [Double](repeating: -1000, count: k)
        var seed: UInt32 = UInt32(k) &* 7919
        func rnd(_ m: Int) -> Int {
            seed = seed &* 1664525 &+ 1013904223
            return Int((seed >> 16) % UInt32(m))
        }
        func x(_ c: Int) -> Int { Int((Double(c) + 0.5) * 512.0 / Double(k)) }
        var step = 0
        var t = 2000.0
        while t < 60000 {
            if step % 32 == 0 {
                let c = rnd(k)
                if t > lastEnd[c] + 20 {
                    let end = t + 1000
                    out += "\(x(c)),192,\(Int(t)),128,0,\(Int(end)):0:0:0:0:\n"
                    lastEnd[c] = end
                }
            } else if step % 2 == 0 || rnd(3) == 0 {
                let c = rnd(k)
                if t > lastEnd[c] + 20 {
                    out += "\(x(c)),192,\(Int(t)),1,0,0:0:0:0:\n"
                    lastEnd[c] = t
                }
                if k >= 6 && step % 4 == 0 {
                    let c2 = (c + 3) % k
                    if t > lastEnd[c2] + 20 {
                        out += "\(x(c2)),192,\(Int(t)),1,0,0:0:0:0:\n"
                        lastEnd[c2] = t
                    }
                }
            }
            step += 1
            t += 250
        }
        return out
    }
}
