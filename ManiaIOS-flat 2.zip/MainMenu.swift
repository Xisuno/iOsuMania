import UIKit

final class MainMenuViewController: UIViewController {
    private let bg = UIImageView()
    private let dim = UIView()

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.08, green: 0.05, blue: 0.14, alpha: 1)

        bg.contentMode = .scaleAspectFill
        bg.clipsToBounds = true
        bg.translatesAutoresizingMaskIntoConstraints = false
        dim.backgroundColor = UIColor.black.withAlphaComponent(0.45)
        dim.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bg)
        view.addSubview(dim)

        let title = UILabel()
        title.text = "mania!"
        title.font = .systemFont(ofSize: 54, weight: .heavy)
        title.textColor = UIColor(red: 1, green: 0.4, blue: 0.65, alpha: 1)
        title.textAlignment = .center
        let sub = UILabel()
        sub.text = "4K – 7K rhythm game"
        sub.font = .systemFont(ofSize: 14, weight: .medium)
        sub.textColor = UIColor(white: 1, alpha: 0.7)
        sub.textAlignment = .center

        let play = menuButton("Jogar", #selector(playTapped), primary: true)
        let mods = menuButton("Mods", #selector(modsTapped))
        let layout = menuButton("Layout & skin.ini", #selector(layoutTapped))
        let skins = menuButton("Skins", #selector(skinsTapped))
        let imp = menuButton("Importar .osz / .osk", #selector(importTapped))
        let set = menuButton("Configurações & fundo", #selector(settingsTapped))

        let stack = UIStackView(arrangedSubviews: [title, sub, play, mods, layout, skins, imp, set])
        stack.axis = .vertical
        stack.spacing = 10
        stack.setCustomSpacing(26, after: sub)
        stack.translatesAutoresizingMaskIntoConstraints = false

        let scroll = UIScrollView()
        scroll.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scroll)
        scroll.addSubview(stack)

        NSLayoutConstraint.activate([
            bg.topAnchor.constraint(equalTo: view.topAnchor), bg.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            bg.leadingAnchor.constraint(equalTo: view.leadingAnchor), bg.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            dim.topAnchor.constraint(equalTo: view.topAnchor), dim.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            dim.leadingAnchor.constraint(equalTo: view.leadingAnchor), dim.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scroll.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scroll.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scroll.contentLayoutGuide.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor),
            stack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor, constant: 24),
            stack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -24),
            stack.centerXAnchor.constraint(equalTo: scroll.contentLayoutGuide.centerXAnchor),
            stack.widthAnchor.constraint(lessThanOrEqualToConstant: 340),
            stack.leadingAnchor.constraint(greaterThanOrEqualTo: scroll.contentLayoutGuide.leadingAnchor, constant: 24),
            stack.trailingAnchor.constraint(lessThanOrEqualTo: scroll.contentLayoutGuide.trailingAnchor, constant: -24),
            stack.widthAnchor.constraint(equalToConstant: 340).withPriority(.defaultHigh),
        ])

        NotificationCenter.default.addObserver(self, selector: #selector(refreshBG), name: .backgroundChanged, object: nil)
        refreshBG()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
        refreshBG()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }

    @objc private func refreshBG() { bg.image = BackgroundStore.current() }

    private func menuButton(_ t: String, _ sel: Selector, primary: Bool = false) -> UIButton {
        let b = UIButton(type: .system)
        b.setTitle(t, for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: primary ? 22 : 17, weight: .semibold)
        b.setTitleColor(.white, for: .normal)
        b.backgroundColor = primary ? UIColor(red: 1, green: 0.35, blue: 0.6, alpha: 0.95) : UIColor(white: 1, alpha: 0.14)
        b.layer.cornerRadius = 12
        b.heightAnchor.constraint(equalToConstant: primary ? 60 : 48).isActive = true
        b.addTarget(self, action: sel, for: .touchUpInside)
        return b
    }

    @objc private func playTapped() { navigationController?.pushViewController(SongSelectViewController(), animated: true) }
    @objc private func modsTapped() { navigationController?.pushViewController(ModsViewController(), animated: true) }
    @objc private func layoutTapped() { navigationController?.pushViewController(GameplayLayoutViewController(), animated: true) }
    @objc private func skinsTapped() { navigationController?.pushViewController(SkinsViewController(), animated: true) }
    @objc private func settingsTapped() { navigationController?.pushViewController(SettingsViewController(), animated: true) }
    @objc private func importTapped() {
        ImportUI.importArchives(from: self) {}
    }
}
