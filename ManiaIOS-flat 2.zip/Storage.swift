import Foundation
import UIKit

// MARK: - Pastas do app (visíveis no app Arquivos > Neste iPhone > ManiaIOS)

enum Paths {
    static var docs: URL { FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0] }
    static var songs: URL { docs.appendingPathComponent("Songs", isDirectory: true) }
    static var skins: URL { docs.appendingPathComponent("Skins", isDirectory: true) }
    static var background: URL { docs.appendingPathComponent("background.jpg") }

    static func prepare() {
        let fm = FileManager.default
        for u in [songs, skins] {
            try? fm.createDirectory(at: u, withIntermediateDirectories: true)
        }
        // Skin padrão (só skin.ini; imagens ausentes são desenhadas por código)
        let def = skins.appendingPathComponent("Default", isDirectory: true)
        if !fm.fileExists(atPath: def.path) {
            try? fm.createDirectory(at: def, withIntermediateDirectories: true)
            var ini = "[General]\nName: Default\nVersion: 2.5\n\n"
            for k in 4...7 {
                ini += "[Mania]\nKeys: \(k)\nColumnWidth: " +
                    Array(repeating: "30", count: k).joined(separator: ",") +
                    "\nHitPosition: 402\nColumnLineWidth: " +
                    Array(repeating: "2", count: k + 1).joined(separator: ",") + "\n\n"
            }
            try? ini.write(to: def.appendingPathComponent("skin.ini"), atomically: true, encoding: .utf8)
        }
    }

    static func uniqueDir(in parent: URL, name: String) -> URL {
        let clean = name.replacingOccurrences(of: "/", with: "_")
        var url = parent.appendingPathComponent(clean, isDirectory: true)
        var i = 2
        while FileManager.default.fileExists(atPath: url.path) {
            url = parent.appendingPathComponent("\(clean) (\(i))", isDirectory: true)
            i += 1
        }
        return url
    }
}

// MARK: - Mods

struct Mods: OptionSet {
    let rawValue: Int
    static let noFail      = Mods(rawValue: 1 << 0)
    static let easy        = Mods(rawValue: 1 << 1)
    static let halfTime    = Mods(rawValue: 1 << 2)
    static let hardRock    = Mods(rawValue: 1 << 3)
    static let doubleTime  = Mods(rawValue: 1 << 4)
    static let suddenDeath = Mods(rawValue: 1 << 5)
    static let perfect     = Mods(rawValue: 1 << 6)
    static let mirror      = Mods(rawValue: 1 << 7)
    static let random      = Mods(rawValue: 1 << 8)
    static let hidden      = Mods(rawValue: 1 << 9)
    static let fadeIn      = Mods(rawValue: 1 << 10)
    static let auto        = Mods(rawValue: 1 << 11)
    static let noHolds     = Mods(rawValue: 1 << 12) // "No LN": segura vira nota simples

    static let all: [(Mods, String, String)] = [
        (.easy, "EZ", "Easy – janelas de acerto mais folgadas"),
        (.noFail, "NF", "No Fail – não morre"),
        (.halfTime, "HT", "Half Time – 0.75x"),
        (.hardRock, "HR", "Hard Rock – janelas mais apertadas"),
        (.doubleTime, "DT", "Double Time – 1.5x"),
        (.suddenDeath, "SD", "Sudden Death – morre ao errar"),
        (.perfect, "PF", "Perfect – morre se não for 300+"),
        (.mirror, "MR", "Mirror – espelha as colunas"),
        (.random, "RD", "Random – embaralha as colunas"),
        (.hidden, "HD", "Hidden – notas somem perto da linha"),
        (.fadeIn, "FI", "Fade In – notas só aparecem perto da linha"),
        (.noHolds, "NLN", "No LN – notas longas viram simples"),
        (.auto, "AT", "Auto – o jogo joga sozinho"),
    ]

    var rate: Double {
        if contains(.doubleTime) { return 1.5 }
        if contains(.halfTime) { return 0.75 }
        return 1.0
    }
    var acronyms: String {
        let s = Mods.all.filter { contains($0.0) }.map { $0.1 }.joined(separator: " ")
        return s.isEmpty ? "—" : s
    }
}

// MARK: - Configurações do usuário

final class Settings {
    static let shared = Settings()
    private let d = UserDefaults.standard

    private func num(_ key: String, _ def: Double) -> Double {
        d.object(forKey: key) == nil ? def : d.double(forKey: key)
    }

    var scrollSpeed: Double { get { num("scrollSpeed", 22) } set { d.set(newValue, forKey: "scrollSpeed") } }   // 1...40
    var audioOffset: Double { get { num("audioOffset", 0) } set { d.set(newValue, forKey: "audioOffset") } }   // ms
    var backgroundDim: Double { get { num("bgDim", 0.6) } set { d.set(newValue, forKey: "bgDim") } }           // 0...1
    var useBeatmapBG: Bool { get { d.object(forKey: "useMapBG") == nil ? true : d.bool(forKey: "useMapBG") } set { d.set(newValue, forKey: "useMapBG") } }
    var activeSkin: String { get { d.string(forKey: "activeSkin") ?? "Default" } set { d.set(newValue, forKey: "activeSkin") } }

    // Ajustes de layout aplicados POR CIMA do skin.ini (em %, 100 = igual ao skin)
    var columnWidthPct: Double { get { num("colWidthPct", 160) } set { d.set(newValue, forKey: "colWidthPct") } }
    var noteHeightPct: Double { get { num("noteHeightPct", 100) } set { d.set(newValue, forKey: "noteHeightPct") } }
    var hitPositionOffset: Double { get { num("hitPosOffset", 0) } set { d.set(newValue, forKey: "hitPosOffset") } } // unidades osu (480p)
    var stageXOffset: Double { get { num("stageXOff", 0) } set { d.set(newValue, forKey: "stageXOff") } }          // pontos
    var useSkinHitPosition: Bool { get { d.object(forKey: "useSkinHP") == nil ? true : d.bool(forKey: "useSkinHP") } set { d.set(newValue, forKey: "useSkinHP") } }
    // 0 = seguir o skin.ini (UpsideDown), 1 = downscroll, 2 = upscroll
    var scrollDirection: Int { get { d.integer(forKey: "scrollDir") } set { d.set(newValue, forKey: "scrollDir") } }
    var showJudgementImages: Bool { get { d.object(forKey: "judgeImgs") == nil ? true : d.bool(forKey: "judgeImgs") } set { d.set(newValue, forKey: "judgeImgs") } }

    var mods: Mods { get { Mods(rawValue: d.integer(forKey: "mods")) } set { d.set(newValue.rawValue, forKey: "mods") } }
}
