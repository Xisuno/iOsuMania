import Foundation
import UIKit

// MARK: - skin.ini (preserva o arquivo original ao salvar)

final class IniFile {
    var lines: [String]

    init(text: String) {
        var t = text
        if t.hasPrefix("\u{FEFF}") { t.removeFirst() }
        t = t.replacingOccurrences(of: "\r\n", with: "\n").replacingOccurrences(of: "\r", with: "\n")
        lines = t.components(separatedBy: "\n")
    }

    struct Block { let header: Int; let end: Int; let name: String }

    func blocks() -> [Block] {
        var result: [Block] = []
        var i = 0
        while i < lines.count {
            let l = lines[i].trimmingCharacters(in: .whitespaces)
            if l.hasPrefix("["), let close = l.firstIndex(of: "]") {
                let name = String(l[l.index(after: l.startIndex)..<close])
                var j = i + 1
                while j < lines.count, !lines[j].trimmingCharacters(in: .whitespaces).hasPrefix("[") { j += 1 }
                result.append(Block(header: i, end: j, name: name))
                i = j
            } else {
                i += 1
            }
        }
        return result
    }

    static func parse(_ line: String) -> (String, String)? {
        var l = line
        if let r = l.range(of: "//") { l = String(l[l.startIndex..<r.lowerBound]) }
        guard let c = l.firstIndex(of: ":") else { return nil }
        let k = l[l.startIndex..<c].trimmingCharacters(in: .whitespaces)
        let v = l[l.index(after: c)...].trimmingCharacters(in: .whitespaces)
        if k.isEmpty { return nil }
        return (k, v)
    }

    func value(_ b: Block, _ key: String) -> String? {
        var i = b.header + 1
        while i < b.end {
            if let (k, v) = IniFile.parse(lines[i]), k.lowercased() == key.lowercased() { return v }
            i += 1
        }
        return nil
    }

    func maniaBlock(keys: Int) -> Block? {
        for b in blocks() where b.name.lowercased() == "mania" {
            if let v = value(b, "Keys"), Int(v) == keys { return b }
        }
        return nil
    }

    func general(_ key: String) -> String? {
        for b in blocks() where b.name.lowercased() == "general" {
            if let v = value(b, key) { return v }
        }
        return nil
    }

    /// Altera (ou cria) `key` na seção [Mania] com `Keys: k`.
    func setMania(keys: Int, key: String, value: String) {
        if maniaBlock(keys: keys) == nil {
            if let last = lines.last, !last.trimmingCharacters(in: .whitespaces).isEmpty { lines.append("") }
            lines.append("[Mania]")
            lines.append("Keys: \(keys)")
            lines.append("")
        }
        guard let b = maniaBlock(keys: keys) else { return }
        var i = b.header + 1
        while i < b.end {
            if let (k, _) = IniFile.parse(lines[i]), k.lowercased() == key.lowercased() {
                lines[i] = "\(key): \(value)"
                return
            }
            i += 1
        }
        lines.insert("\(key): \(value)", at: b.header + 1)
    }

    var text: String { lines.joined(separator: "\n") }
}

// MARK: - Configuração mania lida do skin.ini

struct ManiaConfig {
    var keys: Int
    var columnStart: Double?        // unidades osu (640x480); nil = centralizado
    var columnWidth: [Double]
    var columnLineWidth: [Double]
    var hitPosition: Double         // unidades osu (altura 480)
    var upsideDown: Bool = false    // UpsideDown: 1 no skin.ini (upscroll)
}

// MARK: - Skin

final class Skin {
    let name: String
    let dir: URL
    private(set) var ini: IniFile
    private var cache: [String: UIImage] = [:]
    private var missing = Set<String>()

    var iniURL: URL { dir.appendingPathComponent("skin.ini") }

    init(dir: URL) {
        self.dir = dir
        self.name = dir.lastPathComponent
        var text = ""
        if let d = try? Data(contentsOf: dir.appendingPathComponent("skin.ini")) {
            text = String(data: d, encoding: .utf8) ?? String(data: d, encoding: .isoLatin1) ?? ""
        }
        self.ini = IniFile(text: text)
    }

    static func installedNames() -> [String] {
        let items = (try? FileManager.default.contentsOfDirectory(at: Paths.skins, includingPropertiesForKeys: [.isDirectoryKey])) ?? []
        return items.filter { (try? $0.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true }
            .map { $0.lastPathComponent }
            .sorted()
    }

    static func loadActive() -> Skin {
        var name = Settings.shared.activeSkin
        if !Skin.installedNames().contains(name) { name = "Default"; Settings.shared.activeSkin = name }
        return Skin(dir: Paths.skins.appendingPathComponent(name, isDirectory: true))
    }

    func saveIni() {
        try? ini.text.write(to: iniURL, atomically: true, encoding: .utf8)
    }

    func replaceIni(_ text: String) {
        ini = IniFile(text: text)
        cache.removeAll()
        missing.removeAll()
    }

    // MARK: Config

    private func parseList(_ s: String) -> [Double] {
        s.split(separator: ",").compactMap { Double($0.trimmingCharacters(in: .whitespaces)) }
    }

    func config(keys k: Int) -> ManiaConfig {
        var cfg = ManiaConfig(keys: k, columnStart: nil,
                              columnWidth: Array(repeating: 30, count: k),
                              columnLineWidth: Array(repeating: 2, count: k + 1),
                              hitPosition: 402)
        guard let b = ini.maniaBlock(keys: k) else { return cfg }
        if let v = ini.value(b, "ColumnStart"), let d = Double(v) { cfg.columnStart = d }
        if let v = ini.value(b, "HitPosition"), let d = Double(v) { cfg.hitPosition = d }
        if let v = ini.value(b, "UpsideDown") { cfg.upsideDown = (v == "1" || v.lowercased() == "true") }
        if let v = ini.value(b, "ColumnWidth") {
            let a = parseList(v)
            for i in 0..<k {
                if i < a.count { cfg.columnWidth[i] = max(5, a[i]) }
                else if let l = a.last { cfg.columnWidth[i] = max(5, l) }
            }
        }
        if let v = ini.value(b, "ColumnLineWidth") {
            let a = parseList(v)
            for i in 0...k {
                if i < a.count { cfg.columnLineWidth[i] = max(0, a[i]) }
                else if let l = a.last { cfg.columnLineWidth[i] = max(0, l) }
            }
        }
        return cfg
    }

    func maniaString(keys: Int, _ key: String) -> String? {
        guard let b = ini.maniaBlock(keys: keys) else { return nil }
        return ini.value(b, key)
    }

    // MARK: Imagens

    func image(_ raw: String?) -> UIImage? {
        guard let raw = raw else { return nil }
        var name = raw.trimmingCharacters(in: .whitespaces).replacingOccurrences(of: "\\", with: "/")
        if name.isEmpty { return nil }
        let lower = name.lowercased()
        if lower.hasSuffix(".png") || lower.hasSuffix(".jpg") { name = (name as NSString).deletingPathExtension }
        if let c = cache[name] { return c }
        if missing.contains(name) { return nil }
        let candidates: [(String, CGFloat)] = [("\(name)@2x.png", 2), ("\(name).png", 1), ("\(name)@2x.jpg", 2), ("\(name).jpg", 1)]
        for (file, scale) in candidates {
            let u = dir.appendingPathComponent(file)
            if let d = try? Data(contentsOf: u), let img = UIImage(data: d, scale: scale) {
                cache[name] = img
                return img
            }
        }
        missing.insert(name)
        return nil
    }

    // MARK: Nomes padrão (como no osu!)

    /// "1", "2" ou "S" conforme a coluna.
    func columnType(col: Int, keys k: Int) -> String {
        if k % 2 == 1 && col == k / 2 { return "S" }
        let m = min(col, k - 1 - col)
        return m % 2 == 0 ? "1" : "2"
    }

    /// suffix: "" (nota), "H" (cabeça LN), "L" (corpo LN), "T" (cauda LN)
    func noteImage(col: Int, keys k: Int, suffix: String) -> UIImage? {
        let t = columnType(col: col, keys: k)
        if let s = maniaString(keys: k, "NoteImage\(col)\(suffix)"), let img = image(s) { return img }
        if let img = image("mania-note\(t)\(suffix)") { return img }
        if suffix == "H" || suffix == "T" { return noteImage(col: col, keys: k, suffix: "") }
        return nil
    }

    func keyImage(col: Int, keys k: Int, pressed: Bool) -> UIImage? {
        let t = columnType(col: col, keys: k)
        let suf = pressed ? "D" : ""
        if let s = maniaString(keys: k, "KeyImage\(col)\(suf)"), let img = image(s) { return img }
        return image("mania-key\(t)\(suf)")
    }

    func stageImage(_ key: String, default def: String, keys k: Int) -> UIImage? {
        if let s = maniaString(keys: k, key), let img = image(s) { return img }
        return image(def)
    }

    func judgementImage(_ j: Judgement) -> UIImage? {
        switch j {
        case .max: return image("mania-hit300g") ?? image("mania-hit300")
        case .j300: return image("mania-hit300")
        case .j200: return image("mania-hit200")
        case .j100: return image("mania-hit100")
        case .j50: return image("mania-hit50")
        case .miss: return image("mania-hit0")
        }
    }
}
