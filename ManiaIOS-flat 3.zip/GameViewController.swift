import UIKit
import AVFoundation

final class GameViewController: UIViewController {
    private let map: Beatmap
    private let mods: Mods
    private let engine: GameEngine
    private var gameView: GameView!
    private var player: AVAudioPlayer?
    private var link: CADisplayLink?

    private let leadIn = 2000.0
    private var startUptime = 0.0     // uptime em que o tempo de jogo == 0
    private var paused = false
    private var pausedAt = 0.0
    private var finishing = false

    private var rate: Double { mods.rate }
    private var offsetMs: Double { Settings.shared.audioOffset }

    init(map: Beatmap, mods: Mods) {
        self.map = map
        self.mods = mods
        self.engine = GameEngine(map: map, mods: mods)
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .fullScreen
    }
    required init?(coder: NSCoder) { fatalError() }

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .all }

    // MARK: Relógio

    private func time(at uptime: TimeInterval) -> Double {
        (uptime - startUptime) * 1000 * rate - offsetMs
    }
    private func currentTime() -> Double {
        if paused { return time(at: pausedAt) }
        return time(at: ProcessInfo.processInfo.systemUptime)
    }

    // MARK: Ciclo de vida

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        let skin = Skin.loadActive()
        skin.preload(keys: map.keys)
        gameView = GameView(skin: skin, keys: map.keys)
        gameView.translatesAutoresizingMaskIntoConstraints = false
        gameView.engine = engine
        gameView.mods = mods
        gameView.scrollSpeed = Settings.shared.scrollSpeed
        gameView.nowProvider = { [weak self] in self?.currentTime() ?? 0 }
        gameView.onPress = { [weak self] c, ts in
            guard let self = self, !self.paused else { return }
            self.engine.press(c, now: self.time(at: ts))
        }
        gameView.onRelease = { [weak self] c, ts in
            guard let self = self, !self.paused else { return }
            self.engine.release(c, now: self.time(at: ts))
        }
        if Settings.shared.useBeatmapBG, let u = map.backgroundURL, let img = UIImage(contentsOfFile: u.path) {
            gameView.bgImage = img
        } else if let img = UIImage(contentsOfFile: Paths.background.path) {
            gameView.bgImage = img
        }
        view.addSubview(gameView)
        NSLayoutConstraint.activate([
            gameView.topAnchor.constraint(equalTo: view.topAnchor),
            gameView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            gameView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            gameView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])

        let pauseBtn = UIButton(type: .system)
        pauseBtn.setTitle("  II  ", for: .normal)
        pauseBtn.titleLabel?.font = .boldSystemFont(ofSize: 18)
        pauseBtn.tintColor = UIColor.white.withAlphaComponent(0.8)
        pauseBtn.translatesAutoresizingMaskIntoConstraints = false
        pauseBtn.addTarget(self, action: #selector(pauseTapped), for: .touchUpInside)
        view.addSubview(pauseBtn)
        NSLayoutConstraint.activate([
            pauseBtn.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 6),
            pauseBtn.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 6),
            pauseBtn.widthAnchor.constraint(equalToConstant: 52),
            pauseBtn.heightAnchor.constraint(equalToConstant: 40),
        ])

        NotificationCenter.default.addObserver(self, selector: #selector(appWillResign),
                                               name: UIApplication.willResignActiveNotification, object: nil)
        startSong()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        UIApplication.shared.isIdleTimerDisabled = true
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        UIApplication.shared.isIdleTimerDisabled = false
    }
    deinit {
        link?.invalidate()
        NotificationCenter.default.removeObserver(self)
    }

    private func startSong() {
        try? AVAudioSession.sharedInstance().setCategory(.playback)
        try? AVAudioSession.sharedInstance().setActive(true)
        player = try? AVAudioPlayer(contentsOf: map.audioURL)
        player?.enableRate = true
        player?.rate = Float(rate)
        player?.prepareToPlay()
        let delay = leadIn / 1000 / rate
        startUptime = ProcessInfo.processInfo.systemUptime + delay
        if let p = player { p.play(atTime: p.deviceCurrentTime + delay) }

        let l = CADisplayLink(target: self, selector: #selector(tick))
        l.add(to: .main, forMode: .common)
        link = l
    }

    @objc private func tick() {
        if paused || finishing { return }
        let now = currentTime()
        engine.update(now: now)
        gameView.setNeedsDisplay()
        if engine.isFinished(now) { finish() }
    }

    // MARK: Pausa

    @objc private func appWillResign() { pauseTapped() }

    @objc private func pauseTapped() {
        guard !paused, !finishing, currentTime() > 0, presentedViewController == nil else { return }
        gameView.releaseAllTouches()
        paused = true
        pausedAt = ProcessInfo.processInfo.systemUptime
        player?.pause()
        link?.isPaused = true

        let a = UIAlertController(title: "Pausado", message: nil, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "Continuar", style: .default) { [weak self] _ in self?.resume() })
        a.addAction(UIAlertAction(title: "Reiniciar", style: .default) { [weak self] _ in self?.restart() })
        a.addAction(UIAlertAction(title: "Sair", style: .destructive) { [weak self] _ in self?.quit() })
        present(a, animated: true)
    }

    private func resume() {
        startUptime += ProcessInfo.processInfo.systemUptime - pausedAt
        paused = false
        player?.play()
        link?.isPaused = false
    }

    private func stopAll() {
        link?.invalidate(); link = nil
        player?.stop()
    }

    private func restart() {
        stopAll()
        let presenter = presentingViewController
        let vc = GameViewController(map: map, mods: mods)
        presenter?.dismiss(animated: false) { presenter?.present(vc, animated: false) }
    }

    private func quit() {
        stopAll()
        dismiss(animated: true)
    }

    // MARK: Fim

    private func finish() {
        finishing = true
        stopAll()
        let r = ResultsViewController(engine: engine, map: map, mods: mods)
        r.onRetry = { [weak self] in
            guard let self = self else { return }
            let presenter = self.presentingViewController
            let vc = GameViewController(map: self.map, mods: self.mods)
            presenter?.dismiss(animated: false) { presenter?.present(vc, animated: false) }
        }
        r.onClose = { [weak self] in self?.dismiss(animated: true) }
        present(r, animated: true)
    }
}

// MARK: - Resultados

final class ResultsViewController: UIViewController {
    private let engine: GameEngine
    private let map: Beatmap
    private let mods: Mods
    var onRetry: (() -> Void)?
    var onClose: (() -> Void)?

    init(engine: GameEngine, map: Beatmap, mods: Mods) {
        self.engine = engine; self.map = map; self.mods = mods
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .fullScreen
    }
    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(white: 0.06, alpha: 1)

        let e = engine
        let key = "best_" + map.file.path
        let prev = UserDefaults.standard.integer(forKey: key)
        let newBest = !e.failed && !mods.contains(.auto) && e.score > prev
        if newBest { UserDefaults.standard.set(e.score, forKey: key) }

        func label(_ s: String, _ size: CGFloat, _ weight: UIFont.Weight = .regular, _ color: UIColor = .white) -> UILabel {
            let l = UILabel()
            l.text = s
            l.font = .systemFont(ofSize: size, weight: weight)
            l.textColor = color
            l.textAlignment = .center
            l.numberOfLines = 0
            return l
        }
        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 8
        stack.alignment = .fill
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)

        stack.addArrangedSubview(label(e.failed ? "FALHOU" : "CONCLUÍDO", 16, .semibold, e.failed ? .systemRed : .systemGreen))
        stack.addArrangedSubview(label(e.grade, 84, .heavy, e.failed ? .systemRed : .systemYellow))
        stack.addArrangedSubview(label("\(map.artist) – \(map.title) [\(map.version)]", 15, .medium, UIColor(white: 0.8, alpha: 1)))
        stack.addArrangedSubview(label(String(format: "%07d", e.score) + (newBest ? "  ★ novo recorde" : ""), 32, .bold))
        stack.addArrangedSubview(label(String(format: "%.2f%%   •   combo máx %dx", e.accuracy * 100, e.maxCombo), 17))
        let names = ["MAX", "300", "200", "100", "50", "MISS"]
        var line = ""
        for i in 0..<6 { line += "\(names[i]) \(e.counts[i])" + (i % 3 == 2 ? "\n" : "     ") }
        stack.addArrangedSubview(label(line.trimmingCharacters(in: .whitespacesAndNewlines), 15, .regular, UIColor(white: 0.75, alpha: 1)))
        stack.addArrangedSubview(label("Mods: " + mods.acronyms, 14, .regular, UIColor(white: 0.6, alpha: 1)))

        let retry = UIButton(type: .system)
        retry.setTitle("Tentar de novo", for: .normal)
        retry.addTarget(self, action: #selector(retryTapped), for: .touchUpInside)
        let back = UIButton(type: .system)
        back.setTitle("Voltar", for: .normal)
        back.addTarget(self, action: #selector(closeTapped), for: .touchUpInside)
        for b in [retry, back] {
            b.titleLabel?.font = .systemFont(ofSize: 18, weight: .semibold)
            b.backgroundColor = UIColor(white: 1, alpha: 0.1)
            b.layer.cornerRadius = 10
            b.heightAnchor.constraint(equalToConstant: 48).isActive = true
        }
        let spacer = UIView(); spacer.heightAnchor.constraint(equalToConstant: 12).isActive = true
        stack.addArrangedSubview(spacer)
        stack.addArrangedSubview(retry)
        stack.addArrangedSubview(back)

        // Tudo dentro de um scroll para caber também em paisagem
        let scroll = UIScrollView()
        scroll.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scroll)
        stack.removeFromSuperview()
        scroll.addSubview(stack)
        NSLayoutConstraint.activate([
            scroll.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scroll.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            stack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor, constant: 20),
            stack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -20),
            stack.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor, constant: 40),
            stack.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor, constant: -40),
            scroll.contentLayoutGuide.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor),
        ])
    }

    @objc private func retryTapped() { onRetry?() }
    @objc private func closeTapped() { onClose?() }
}

extension NSLayoutConstraint {
    func withPriority(_ p: UILayoutPriority) -> NSLayoutConstraint {
        priority = p
        return self
    }
}
