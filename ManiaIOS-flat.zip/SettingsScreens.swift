import UIKit

// MARK: - Configurações gerais (rolagem, offset, fundo)

final class SettingsViewController: FormViewController {
    override func viewDidLoad() {
        title = "Configurações"
        super.viewDidLoad()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        reload()
    }

    override func build() -> [FormSection] {
        let s = Settings.shared
        return [
            FormSection(title: "Gameplay", footer: "Velocidade de rolagem: maior = notas mais rápidas. Offset positivo atrasa o relógio do jogo (use se estiver acertando cedo demais).", rows: [
                .slider(title: "Velocidade de rolagem", min: 1, max: 40, step: 1, unit: "", get: { s.scrollSpeed }, set: { s.scrollSpeed = $0 }),
                .slider(title: "Offset de áudio", min: -200, max: 200, step: 1, unit: " ms", get: { s.audioOffset }, set: { s.audioOffset = $0 }),
                .toggle(title: "Imagens de julgamento da skin", get: { s.showJudgementImages }, set: { s.showJudgementImages = $0 }),
            ]),
            FormSection(title: "Fundo", footer: "O fundo personalizado aparece no menu e, durante o jogo, quando o beatmap não tem imagem (ou se você desligar o fundo do beatmap).", rows: [
                .toggle(title: "Usar fundo do beatmap no jogo", get: { s.useBeatmapBG }, set: { s.useBeatmapBG = $0 }),
                .slider(title: "Escurecer fundo no jogo", min: 0, max: 100, step: 5, unit: "%", get: { s.backgroundDim * 100 }, set: { s.backgroundDim = $0 / 100 }),
                .button(title: "Escolher da galeria…", destructive: false, action: { [weak self] in
                    guard let self = self else { return }
                    ImportUI.pickBackgroundFromPhotos(from: self) { [weak self] in self?.bgChanged() }
                }),
                .button(title: "Escolher de Arquivos…", destructive: false, action: { [weak self] in
                    guard let self = self else { return }
                    ImportUI.pickBackgroundFromFiles(from: self) { [weak self] in self?.bgChanged() }
                }),
                .button(title: "Remover fundo personalizado", destructive: true, action: { [weak self] in
                    BackgroundStore.remove(); self?.bgChanged()
                }),
            ]),
            FormSection(title: "Skins e mapas", footer: nil, rows: [
                .button(title: "Skins…", destructive: false, action: { [weak self] in
                    self?.navigationController?.pushViewController(SkinsViewController(), animated: true)
                }),
                .button(title: "Importar .osz / .osk…", destructive: false, action: { [weak self] in
                    guard let self = self else { return }
                    ImportUI.importArchives(from: self) {}
                }),
            ]),
        ]
    }

    private func bgChanged() {
        NotificationCenter.default.post(name: .backgroundChanged, object: nil)
        reload()
    }
}

extension Notification.Name {
    static let backgroundChanged = Notification.Name("backgroundChanged")
}

// MARK: - Mods

final class ModsViewController: FormViewController {
    var onChange: (() -> Void)?

    override func viewDidLoad() {
        title = "Mods"
        super.viewDidLoad()
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Limpar", style: .plain, target: self, action: #selector(clear))
    }

    @objc private func clear() {
        Settings.shared.mods = []
        onChange?()
        reload()
    }

    override func build() -> [FormSection] {
        var rows: [FormRow] = []
        for (mod, ac, desc) in Mods.all {
            rows.append(.toggle(title: "\(ac) — \(desc)", get: { Settings.shared.mods.contains(mod) }, set: { [weak self] on in
                var m = Settings.shared.mods
                if on {
                    m.insert(mod)
                    // exclusões mútuas
                    if mod == .easy { m.remove(.hardRock) }
                    if mod == .hardRock { m.remove(.easy) }
                    if mod == .halfTime { m.remove(.doubleTime) }
                    if mod == .doubleTime { m.remove(.halfTime) }
                    if mod == .mirror { m.remove(.random) }
                    if mod == .random { m.remove(.mirror) }
                    if mod == .hidden { m.remove(.fadeIn) }
                    if mod == .fadeIn { m.remove(.hidden) }
                    if mod == .noFail { m.remove([.suddenDeath, .perfect]) }
                    if mod == .suddenDeath || mod == .perfect { m.remove(.noFail) }
                } else { m.remove(mod) }
                Settings.shared.mods = m
                self?.onChange?()
                self?.reload()
            }))
        }
        return [FormSection(title: "Mods ativos: " + Settings.shared.mods.acronyms,
                            footer: "Jogar com mods (exceto NF/EZ/HT…) é só para diversão: o recorde só é salvo sem Auto.",
                            rows: rows)]
    }
}

// MARK: - Skins

final class SkinsViewController: FormViewController {
    override func viewDidLoad() {
        title = "Skins"
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        reload()
    }

    override func build() -> [FormSection] {
        let active = Settings.shared.activeSkin
        var rows: [FormRow] = []
        for name in Skin.installedNames() {
            rows.append(.button(title: (name == active ? "✓  " : "      ") + name, destructive: false, action: { [weak self] in
                self?.openSkin(name)
            }))
        }
        return [
            FormSection(title: "Skins instaladas", footer: "Toque numa skin para ativar, ajustar skin.ini ou apagar.", rows: rows),
            FormSection(title: nil, footer: "Você também pode colocar pastas de skin direto em Arquivos › ManiaIOS › Skins.", rows: [
                .button(title: "Importar skin (.osk)…", destructive: false, action: { [weak self] in
                    guard let self = self else { return }
                    ImportUI.importArchives(from: self) { [weak self] in self?.reload() }
                }),
            ]),
        ]
    }

    private func openSkin(_ name: String) {
        let sheet = UIAlertController(title: name, message: nil, preferredStyle: .actionSheet)
        sheet.addAction(UIAlertAction(title: "Usar esta skin", style: .default) { [weak self] _ in
            Settings.shared.activeSkin = name
            self?.reload()
        })
        sheet.addAction(UIAlertAction(title: "Ajustes de gameplay / skin.ini", style: .default) { [weak self] _ in
            Settings.shared.activeSkin = name
            self?.navigationController?.pushViewController(GameplayLayoutViewController(), animated: true)
        })
        if name != "Default" {
            sheet.addAction(UIAlertAction(title: "Apagar", style: .destructive) { [weak self] _ in
                try? FileManager.default.removeItem(at: Paths.skins.appendingPathComponent(name))
                if Settings.shared.activeSkin == name { Settings.shared.activeSkin = "Default" }
                self?.reload()
            })
        }
        sheet.addAction(UIAlertAction(title: "Cancelar", style: .cancel))
        sheet.popoverPresentationController?.sourceView = view
        sheet.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        present(sheet, animated: true)
    }
}

// MARK: - Ajustes de gameplay (tamanho, hit position) + skin.ini

final class GameplayLayoutViewController: FormViewController {
    private var keyCount = 4
    private var skin = Skin.loadActive()
    private let preview = PreviewHost()

    override func viewDidLoad() {
        title = "Layout & skin.ini"
        super.viewDidLoad()
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Editar .ini", style: .plain, target: self, action: #selector(editIni))
        preview.frame = CGRect(x: 0, y: 0, width: view.bounds.width, height: 260)
        preview.autoresizingMask = [.flexibleWidth]
        tableView.tableHeaderView = preview
        refreshPreview()
    }

    private func refreshPreview() {
        skin = Skin.loadActive()
        preview.show(skin: skin, keys: keyCount)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        refreshPreview()
        reload()
    }

    @objc private func editIni() {
        let vc = IniEditorViewController(skin: skin)
        vc.onSaved = { [weak self] in self?.refreshPreview(); self?.reload() }
        navigationController?.pushViewController(vc, animated: true)
    }

    private func num(_ key: String, fallback: Double) -> Double {
        if let v = skin.maniaString(keys: keyCount, key), let d = Double(v.split(separator: ",").first.map(String.init) ?? "") { return d }
        return fallback
    }

    /// Reescreve ColumnWidth no skin.ini com um valor uniforme.
    private func writeColumnWidth(_ w: Double) {
        let list = Array(repeating: String(Int(w)), count: keyCount).joined(separator: ",")
        skin.ini.setMania(keys: keyCount, key: "ColumnWidth", value: list)
        skin.saveIni()
        refreshPreview()
    }

    private func writeHitPosition(_ h: Double) {
        skin.ini.setMania(keys: keyCount, key: "HitPosition", value: String(Int(h)))
        skin.saveIni()
        refreshPreview()
    }

    override func build() -> [FormSection] {
        let s = Settings.shared
        let cfg = skin.config(keys: keyCount)
        let avgW = cfg.columnWidth.reduce(0, +) / Double(max(1, keyCount))
        return [
            FormSection(title: "Prévia", footer: nil, rows: [
                .segment(titles: (4...7).map { "\($0)K" }, get: { [weak self] in (self?.keyCount ?? 4) - 4 }, set: { [weak self] i in
                    self?.keyCount = i + 4
                    self?.refreshPreview()
                    self?.reload()
                }),
            ]),
            FormSection(title: "Ajustes do app (por cima da skin)", footer: "Estes valores são aplicados em qualquer skin sem mexer no skin.ini. Largura em %, 100 = igual ao skin.ini.", rows: [
                .slider(title: "Largura das colunas", min: 50, max: 300, step: 5, unit: "%", get: { s.columnWidthPct }, set: { [weak self] in s.columnWidthPct = $0; self?.preview.relayout() }),
                .slider(title: "Altura das notas", min: 40, max: 250, step: 5, unit: "%", get: { s.noteHeightPct }, set: { [weak self] in s.noteHeightPct = $0; self?.preview.relayout() }),
                .slider(title: "Mover linha de acerto (+ = baixo)", min: -120, max: 60, step: 1, unit: "", get: { s.hitPositionOffset }, set: { [weak self] in s.hitPositionOffset = $0; self?.preview.relayout() }),
                .slider(title: "Mover palco horizontalmente", min: -200, max: 200, step: 5, unit: " pt", get: { s.stageXOffset }, set: { [weak self] in s.stageXOffset = $0; self?.preview.relayout() }),
                .toggle(title: "Usar HitPosition do skin.ini", get: { s.useSkinHitPosition }, set: { [weak self] in s.useSkinHitPosition = $0; self?.preview.relayout() }),
                .button(title: "Restaurar ajustes do app", destructive: true, action: { [weak self] in
                    s.columnWidthPct = 160; s.noteHeightPct = 100; s.hitPositionOffset = 0; s.stageXOffset = 0; s.useSkinHitPosition = true
                    self?.preview.relayout(); self?.reload()
                }),
            ]),
            FormSection(title: "skin.ini — \(keyCount)K (grava no arquivo)", footer: "Edita a seção [Mania] com Keys: \(keyCount) da skin “\(skin.name)”. ColumnWidth uniforme; para larguras diferentes por coluna use “Editar .ini”.", rows: [
                .slider(title: "ColumnWidth", min: 10, max: 80, step: 1, unit: "", get: { avgW }, set: { [weak self] in self?.writeColumnWidth($0) }),
                .slider(title: "HitPosition", min: 240, max: 480, step: 1, unit: "", get: { [weak self] in self?.num("HitPosition", fallback: 402) ?? 402 }, set: { [weak self] in self?.writeHitPosition($0) }),
            ]),
        ]
    }
}

// MARK: - Prévia do palco

final class PreviewHost: UIView {
    private var gv: GameView?

    func show(skin: Skin, keys: Int) {
        gv?.removeFromSuperview()
        let v = GameView(skin: skin, keys: keys)
        v.frame = bounds
        v.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        v.isUserInteractionEnabled = false
        v.scrollSpeed = Settings.shared.scrollSpeed
        v.bgImage = BackgroundStore.current()
        var notes: [DrawNote] = []
        let rng: [Double] = [0.9, 1.4, 0.4, 1.9, 0.7, 1.1, 1.6]
        for c in 0..<keys {
            let t = rng[c % rng.count] * 380
            notes.append(DrawNote(column: c, time: t, endTime: c % 3 == 1 ? t + 450 : nil, holding: false))
        }
        v.previewNotes = notes
        v.pressedPreview = (0..<keys).map { $0 == 1 }
        v.nowProvider = { 0 }
        addSubview(v)
        gv = v
        v.relayout()
    }

    func relayout() { gv?.relayout() }
}

// MARK: - Editor de skin.ini

final class IniEditorViewController: UIViewController {
    private let skin: Skin
    private let tv = UITextView()
    var onSaved: (() -> Void)?

    init(skin: Skin) {
        self.skin = skin
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "skin.ini — " + skin.name
        view.backgroundColor = .systemBackground
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(save))
        tv.font = .monospacedSystemFont(ofSize: 13, weight: .regular)
        tv.autocapitalizationType = .none
        tv.autocorrectionType = .no
        tv.smartDashesType = .no
        tv.smartQuotesType = .no
        tv.text = skin.ini.text
        tv.alwaysBounceVertical = true
        tv.keyboardDismissMode = .interactive
        tv.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tv)
        NSLayoutConstraint.activate([
            tv.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tv.bottomAnchor.constraint(equalTo: view.keyboardLayoutGuide.topAnchor),
            tv.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            tv.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
        ])
    }

    @objc private func save() {
        skin.replaceIni(tv.text)
        skin.saveIni()
        view.endEditing(true)
        onSaved?()
        showAlert("Salvo", "skin.ini gravado.") { [weak self] in self?.navigationController?.popViewController(animated: true) }
    }
}
