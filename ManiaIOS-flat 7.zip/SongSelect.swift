import UIKit

final class SongSelectViewController: UITableViewController {
    private var sets: [BeatmapSet] = []
    private let modsButton = UIBarButtonItem()

    init() { super.init(style: .insetGrouped) }
    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Músicas"
        modsButton.target = self
        modsButton.action = #selector(openMods)
        navigationItem.rightBarButtonItems = [
            UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(importTapped)),
            modsButton,
        ]
        refreshModsTitle()
        reloadSets()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        refreshModsTitle()
        tableView.reloadData()
    }

    private func reloadSets() {
        sets = Library.sets()
        tableView.reloadData()
    }

    private func refreshModsTitle() {
        let m = Settings.shared.mods
        modsButton.title = m == [] ? "Mods" : "Mods (\(m.acronyms))"
    }

    @objc private func openMods() {
        let vc = ModsViewController()
        vc.onChange = { [weak self] in self?.refreshModsTitle() }
        navigationController?.pushViewController(vc, animated: true)
    }

    @objc private func importTapped() {
        ImportUI.importArchives(from: self) { [weak self] in self?.reloadSets() }
    }

    override func numberOfSections(in tableView: UITableView) -> Int { max(1, sets.count) }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        sets.isEmpty ? 1 : sets[section].diffs.count
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        sets.isEmpty ? nil : "\(sets[section].artist) – \(sets[section].title)"
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let c = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        if sets.isEmpty {
            c.textLabel?.text = "Nenhum mapa. Toque em + para importar um .osz (osu!mania)."
            c.textLabel?.numberOfLines = 0
            c.selectionStyle = .none
            return c
        }
        let m = sets[indexPath.section].diffs[indexPath.row]
        c.textLabel?.text = "[\(m.keys)K] \(m.version)"
        let secs = Int(m.lengthMs / 1000)
        let best = UserDefaults.standard.integer(forKey: "best_" + m.file.path)
        c.detailTextLabel?.text = String(format: "%d:%02d  •  %d notas  •  OD %.1f", secs / 60, secs % 60, m.objects.count, m.od)
            + (best > 0 ? String(format: "  •  recorde %07d", best) : "")
        c.detailTextLabel?.textColor = .secondaryLabel
        c.accessoryType = .disclosureIndicator
        return c
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard !sets.isEmpty else { return }
        let m = sets[indexPath.section].diffs[indexPath.row]
        present(GameViewController(map: m, mods: Settings.shared.mods), animated: true)
    }

    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        guard !sets.isEmpty else { return nil }
        let del = UIContextualAction(style: .destructive, title: "Apagar set") { [weak self] _, _, done in
            guard let self = self else { return }
            try? FileManager.default.removeItem(at: self.sets[indexPath.section].dir)
            self.reloadSets()
            done(true)
        }
        return UISwipeActionsConfiguration(actions: [del])
    }
}
